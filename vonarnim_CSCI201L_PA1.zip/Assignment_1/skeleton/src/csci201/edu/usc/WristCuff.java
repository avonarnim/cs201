package csci201.edu.usc;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class WristCuff {	
	FastList<Shelter> shelters;
	String path_origin;
	/**
	 * Loads shelters specified in path (JSON file)
	 */
	public WristCuff(String path) throws IOException {
		shelters = new FastList<Shelter>();
		path_origin = path;
//		System.out.println("This is the path");
//		System.out.println(path);
//		System.out.println(System.getProperty("user.dir"));

		Gson gson = new Gson();
		try {
			Reader reader = new FileReader(path);
			Shelter[] shelts = gson.fromJson(reader,  Shelter[].class);
			for (int i = 0; i < shelts.length; i++) {
				shelters.insert(shelts[i]);
			}
//			for (int j = shelters.levelHeads.size(); j > 0; j--) {
//				System.out.println("printing level " + j);
//				System.out.println(shelters.toString(j));
//			}
		} catch (IOException e) {
			throw e;
		}
	}
	
	/**
	 * Finds an available shelter that matches one of the provided Chiral Frequencies
	 */
	public Shelter findShelter(List<Integer> chiralFrequencies) {
		for (int i = 0; i < chiralFrequencies.size(); i++) {
			Shelter destination = shelters.contains(chiralFrequencies.get(i));
			// allows for multiple same-frequency searches
			if (destination == null) {
				System.out.println("No shelters with chiral frequency " + chiralFrequencies.get(i) + "\n");
			}
			while (destination != null) {
				// if a matching frequency is found...
				System.out.println("\n=== Matching time shelter found! ===");
				System.out.println("Shelter information:");
				System.out.print(destination.toString());
				// if shelter is experiencing timefall, delete the shelter
				if (destination.timefall == true) {
					System.out.println("\n=== Target shelter Chiral signal unstable, Chiral jump unavailable. ===");
					System.out.println("=== Removing target shelter from the list of shelters and saving updated ===");
					shelters.delete(destination);
					try {
						save();
					} catch (FileNotFoundException e) {
						System.out.println("Problem with finding the file.");
					}
				} else {
					// shelter w/ right frequency and timefall found
					return destination;
				}
				// checks for other shelters with the same frequency
				destination = shelters.contains(chiralFrequencies.get(i));
			}
		}
//		for (int j = shelters.levelHeads.size(); j > 0; j--) {
//			System.out.println("printing level " + j);
//			System.out.println(shelters.toString(j));
//		}
		return null;
	}
	
		
	/**
	 * Saves the updated list of shelters to disk
	 */
	public void save() throws FileNotFoundException {	// for each object that's not a dummy, print data
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		try (FileWriter writer = new FileWriter(path_origin)){
			shelters.printToJSON(gson, writer);
			writer.flush();
			writer.close();
			// gson.toJson(shelters, writer);
		}
		catch (FileNotFoundException e) {
			throw e;
		}
		catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}
}
