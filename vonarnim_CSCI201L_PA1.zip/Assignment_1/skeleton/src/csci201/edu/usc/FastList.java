
package csci201.edu.usc;
import java.util.Random;

import com.google.gson.Gson;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.lang.Math;
import java.util.ArrayList;

public class FastList<AnyType extends IntegerComparable>
{
	//each node has between one and eight next references
	public static final int MAX_LEVEL = 7;
	ArrayList<Node> levelHeads = new ArrayList<Node>();
	
	public FastList() {
		Shelter dummyShelter = new Shelter();
		dummyShelter.chiralFrequency = Integer.MIN_VALUE;
		dummyShelter.name = "dummy";
		Node dummyNode = new Node(MAX_LEVEL, dummyShelter);
		for (int i = 0; i < MAX_LEVEL; i++) {
			levelHeads.add(dummyNode);
		}
	}

 /**
	*  Returns the string contents of the list
	*  The method traverses the level 0 references
	*/
	public String toString()
	{
		StringBuffer overall = new StringBuffer("");
		Node temp = levelHeads.get(0).next[0];
		while (temp != null) {
			overall.append(temp.data.toString());
			temp = temp.next[0];
		}
		return overall.toString();
	}

/**
	*  Returns the string contents of the list at a given level
	*  The method traverses nodes at given level
	*/
	public String toString(int level)
	{
		StringBuffer overall = new StringBuffer("");
		Node temp = levelHeads.get(level-1).next[level-1];
		while (temp != null ) {
			overall.append(temp.data.toString());
			temp = temp.next[level-1];
		}
		return overall.toString();
	}
	
/**
 * Prints FastList to file as JSON
 * @throws IOException 
 */
	public void printToJSON(Gson gsonObj, FileWriter file) throws IOException {
		
		file.write("[\n");
		Node temp = levelHeads.get(0).next[0];
		while (temp != null) {
			gsonObj.toJson(temp.data, file);
			temp = temp.next[0];
			if (temp != null) {
				file.write(',');
			}
		}
		file.write("\n]");
		return;
	}


 /**
	*  Returns true if the given value is stored in the list, otherwise false.
	*  The search begins at the topmost reference of the header
	*/
	public AnyType contains(int toSearch)
	{
		Node<AnyType> temp_forward = levelHeads.get(levelHeads.size()-1);
		Node<AnyType> temp_reverse = levelHeads.get(levelHeads.size()-1);
		for (int i = levelHeads.size()-1; i >= 0; i--) {
			temp_forward = temp_reverse;
			while (((IntegerComparable) temp_forward.data).compareTo(toSearch) < 0 || isDummy((AnyType) temp_forward.data)) {
				temp_reverse = temp_forward;
				if (temp_forward.next[i] != null) {
					temp_forward = temp_forward.next[i];
				} else {
					break;
				}
			}
			int compareResult = ((IntegerComparable) temp_forward.data).compareTo(toSearch);
			if (compareResult == 0) {
				if (!isDummy((AnyType) temp_forward.data)) {
					System.out.println("Level " + i + " - Chiral frequency match found @ " + temp_forward.data.getCompareValue() + "!");
					return (AnyType) temp_forward.data;
				}
			} else if (compareResult < 0) {
				if (!isDummy((AnyType) temp_forward.data)) {
				System.out.println("Level " + i + " - Chiral frequency lower bound found @ " + temp_forward.data.getCompareValue());
				}
			} else if (compareResult > 0) {
				if (!isDummy((AnyType) temp_forward.data)) {
				System.out.println("Level " + i + " - Chiral frequency upper bound found @ " + temp_forward.data.getCompareValue());
				}
			}
		}
		return null;
	}

 /**
	*  Returns true if the given value is stored in the list, otherwise false.
	*  The search begins at the topmost reference of the header
	*/
	public AnyType contains(AnyType toSearch)
	{
		Node<AnyType> temp_forward = levelHeads.get(levelHeads.size()-1);
		Node<AnyType> temp_reverse = levelHeads.get(levelHeads.size()-1);
		for (int i = levelHeads.size()-1; i >= 0; i--) {
			temp_forward = temp_reverse;
			while (((IntegerComparable) temp_forward.data).compareTo(toSearch) < 0 || isDummy((AnyType) temp_forward.data)) {
				temp_reverse = temp_forward;
				if (temp_forward.next != null) {
					temp_forward = temp_forward.next[i];
				} else {
					break;
				}
			}
			if (((IntegerComparable) temp_forward.data).compareTo(toSearch) == 0) {
				if (!isDummy((AnyType) temp_forward.data)) {
					return (AnyType) temp_forward.data;
				}
			}
		}
		return null;
	}

 /**
	*  Inserts a given value into the list at random level
	*  In order to insert a new node into the list we must maintain an array
	*  of nodes whose next references must be updated.
	*/
	public void insert(AnyType toInsert)
	{
		int seed = (int) Math.pow(2, MAX_LEVEL-1);
		Random rand = new Random();
		int randomResult = rand.nextInt(seed);
		int level_raw = (randomResult)*2+1;
		int level_adjusted = MAX_LEVEL - 1 -(int) (Math.log(level_raw)/Math.log(2));
		insert(toInsert, level_adjusted);
	}

 /**
	*  Inserts a given value into the list at a given level
	*  The level must not exceed MAX_LEVEL.
	*/
	public void insert(AnyType toInsert, int level)
	{
		Node n = new Node(level, toInsert);
		
		Node temp_forward = levelHeads.get(level);
		Node temp_reverse = levelHeads.get(level);
		for (int i = level; i >= 0; i--) {
			temp_forward = temp_reverse;
			while (temp_forward != null) {
				if ((((IntegerComparable) temp_forward.data).compareTo(toInsert) < 0) || isDummy((AnyType) temp_forward.data)) {
					temp_reverse = temp_forward;
					temp_forward = temp_forward.next[i];
				} else {
					break;
				}
			}
			Node transpose_next = temp_reverse.next[i];
			temp_reverse.next[i] = n;
			n.next[i] = transpose_next;
		}
	}

 /**
	*  Deletes a node that contains the given value.
	*  In order to delete a node we must maintain an array
	*  of nodes whose next references must be updated.
	*/
	public void delete(AnyType toDelete)
	{
		ArrayList<Node> predecessors = new ArrayList<Node>();
		Node<AnyType> temp_forward = levelHeads.get(levelHeads.size()-1);
		Node<AnyType> temp_reverse = levelHeads.get(levelHeads.size()-1);
		Node<AnyType> found = null;
		for (int i = levelHeads.size()-1; i >= 0; i--) {
//			System.out.println("level " + i);
			temp_forward = temp_reverse;
			while (((IntegerComparable) temp_forward.data).compareTo(toDelete) < 0 || isDummy((AnyType) temp_forward.data)) {
				if (temp_forward.next[i] != null) {
					temp_reverse = temp_forward;
					temp_forward = temp_forward.next[i];
				} else {
					break;
				}
			}
			if (((IntegerComparable) temp_forward.data).compareTo(toDelete) == 0) {
				if (!isDummy((AnyType) temp_forward.data)) {
//					System.out.println("adding predecessor");
//					System.out.println(temp_reverse.data.toString());
					predecessors.add(temp_reverse);
					found = temp_forward;
				}
			}
		}
//		System.out.println("Attained all predecessors");
//		System.out.println("Size: " + predecessors.size());
		for (int i = 0; i < predecessors.size(); i++) {
			// error checking necessary if found not converted to null?
//			System.out.println("Index: " + (predecessors.size()-1-i));
//			System.out.println("Predecessor");
//			System.out.println(predecessors.get(i).data.toString());
//			System.out.println("Deleting shelter: ");
//			System.out.println(found.data.toString());
//			System.out.println("Post shelter: ");
//			System.out.println(found.next.length);
//			System.out.println(found.next[predecessors.size()-1-i]);
//			if (found.next[predecessors.size()-1-i] == null) {
//				System.out.println("Null");
//			} else {
//				System.out.println("Trying to print");
//				System.out.println(found.next[predecessors.size()-1-i].data.toString());
//			}
			if (found.next.length > predecessors.size()-1-i) {
				predecessors.get(i).next[predecessors.size()-1-i] = found.next[predecessors.size()-1-i];
			} else {
				predecessors.get(i).next[predecessors.size()-1-i] = null;
			}
//			System.out.println("Reassigned to:");
//			if (predecessors.get(i).next[predecessors.size()-1-i] == null) {
//				System.out.println("Null");
//			} else {
//				System.out.println(predecessors.get(i).next[predecessors.size()-1-i].data.toString());
//			}
		}
	}
	
	public boolean isDummy(AnyType testSubject) {
		Shelter dummy = new Shelter();
		dummy.chiralFrequency = Integer.MIN_VALUE;
		dummy.name = "dummy";		
		
		if ((boolean) dummy.equals(testSubject)) {
			return true;
		} else {
			return false;
		}
	}
	
	public static class Node <AnyType> {
		public AnyType data;
		public Node[] next;
		
		public Node(int randLevel, AnyType data)
		{
			next = new Node[randLevel+1];
			this.data = data;
		}
	}
}
