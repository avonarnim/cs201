package csci201.edu.usc;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
	/**
	 * Use user-input to create a WristCuff object.
	 */
	public static WristCuff getWristCuff() throws IOException {
		Scanner sc = new Scanner(System.in);
		WristCuff cuffInstance = null;
		try {
			System.out.print("Please provide timefall shelter data source: ");
			String filename = sc.next();
			cuffInstance = new WristCuff(filename);
		}
		catch (IOException e) {
			System.out.println(e.getMessage());
			throw e;
		}
		return cuffInstance;
	}
	
	/**
	 * Use user-input to create a list of supported Chiral Frequencies
	 */
	public static List<Integer> getChiralFrequencies() throws IOException {

		System.out.print("\n\nPlease provide supported Chiral frequencies: ");
		ArrayList<Integer> frequencies = new ArrayList<Integer>();
		
		Scanner sc = new Scanner(System.in);

		// convert string entry to array of acceptable Chiral frequencies
		if (sc.hasNextLine()) {
			String userInput = sc.nextLine();
			String[] tokens = userInput.split(", ");
			for (String token : tokens) {
				frequencies.add(Integer.valueOf(token));
			}
		}
		return frequencies;
	}
	
	public static void main(String[] args) {
		System.out.println("Welcome to Bridges Link.\n");
		
		WristCuff gadget;
		try {
			gadget = getWristCuff();
		} catch (IOException e) {
			System.out.println("=== Data not accepted ===");
			return;
		}

		System.out.println("=== Data accepted ===");
		
		ArrayList<Integer> acceptedFrequencies;
		try {
			acceptedFrequencies = new ArrayList<Integer>(getChiralFrequencies());
		} catch (IOException e) {
			System.out.println("\nError when getting chiral frequencies");
			return;
		}
		
		System.out.println("\n=== Commencing timefall shelter search ===");
		Shelter winner = gadget.findShelter(acceptedFrequencies);
		if (winner == null) {
			System.out.println("\n=== No shelter available. You are DOOMED. ===");
		} else {
			System.out.println("\n=== Commencing Chiral jump, see you on the beach. ===");
		}
		
		return;
	}

}
