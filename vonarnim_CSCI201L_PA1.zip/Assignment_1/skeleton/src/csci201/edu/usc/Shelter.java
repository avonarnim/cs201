package csci201.edu.usc;

public class Shelter extends IntegerComparable {
	public int chiralFrequency = 0;
	public boolean timefall = true;
	public String guid = "";
	public String name = "";
	public String phone = "";
	public String address = "";
	
//	public Shelter(int frequency, String shelterName) {
//		chiralFrequency = frequency;
//		name = shelterName;
//	}
//	
//	public Shelter(int frequency, boolean viable, String id, String shelterName, String number, String addy) {
//		chiralFrequency = frequency;
//		timefall = viable;
//		guid = id;
//		name = shelterName;
//		phone = number;
//		address = addy;		
//	}
	
	/**
	 * String representation of a shelter
	 */
	public String toString() {
		StringBuffer description = new StringBuffer();
		description.append("- Chiral frequency: [chiralFrequency]\n");
		description.append("- Timefall: [timefall]\n");
		description.append("- GUID: [guid]\n");
		description.append("- Name: [name]\n");
		description.append("- Phone: [phone]\n");
		description.append("- Address: [address]\n");
		description.replace(description.indexOf("[chiralFrequency]"),description.indexOf("[chiralFrequency]")+17, Integer.toString(chiralFrequency));
		description.replace(description.indexOf("[timefall]"),description.indexOf("[timefall]")+10, Boolean.toString(timefall));
		description.replace(description.indexOf("[guid]"),description.indexOf("[guid]")+6, guid);
		description.replace(description.indexOf("[name]"),description.indexOf("[name]")+6, name);
		description.replace(description.indexOf("[phone]"),description.indexOf("[phone]")+7, phone);
		description.replace(description.indexOf("[address]"),description.indexOf("[address]")+9, address);
		
		return description.toString();
	}

	/**
	 * Returns integer value to compare on
	 */
	@Override
	public int getCompareValue() {
		return this.chiralFrequency;
	}
	
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (obj.getClass() != this.getClass()) {
			return false;
		}
		Shelter comparison = (Shelter) obj;
		if (this.chiralFrequency != comparison.chiralFrequency || 
			this.timefall != comparison.timefall ||
			this.guid != comparison.guid ||
			this.address != comparison.address ||
			this.phone != comparison.phone ||
			this.name != comparison.name) {
			return false;
		} else {
			return true;
		}
	}

}