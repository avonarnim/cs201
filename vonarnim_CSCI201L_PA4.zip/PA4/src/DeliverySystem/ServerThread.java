package DeliverySystem;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class ServerThread implements Runnable
{
	private ObjectInputStream is;
	private ObjectOutputStream os;
	private HeadquarterServer hs;

	public ServerThread(HeadquarterServer hs, ObjectInputStream in, ObjectOutputStream out)
	{
		try {
			this.hs = hs;
			is = in;
			os = out;
						
		} catch (Exception e) {}
	}

	public void sendMessage(Object message)
	{
		try {
			os.writeObject(message);
			os.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void run()
	{
		hs.addAvailableDriver(this);
		while (true) {
			try {
				String line = (String) is.readObject();
				hs.addAvailableDriver(this);
				if (line.equals("done")) {
					hs.increaseNumIfDone();
					Thread.yield();
				} else if (line.contains("All orders completed!")) {
					break;
				}
			} catch (IOException | ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
	}
}
