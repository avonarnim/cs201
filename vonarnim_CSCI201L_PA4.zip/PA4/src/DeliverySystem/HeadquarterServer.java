package DeliverySystem;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HeadquarterServer extends Thread
{
	private Location HQLocation = new Location(0, 0);
	private int drivers = 0;
	private int numOrders = 0;
	private int numDone = 0;
	private int sentOrders = 0;

	private ArrayBlockingQueue<ServerThread> availableClients;
	private ArrayBlockingQueue<ServerThread> serverThreads;
	private HashMap<Integer, ArrayList<Order>> timeToOrder;
	public DeliveryInformation waitingDelivery;
		
	public HeadquarterServer()
	{
		Scanner sc = new Scanner(System.in);
		String response;
		double latitude;
		double longitude;
		BufferedReader reader;
		ArrayList<String> rawOrders = new ArrayList<String>();

		while (true) {
			System.out.println("What is the name of the schedule file?");
			response = sc.nextLine();
			System.out.println();
			try {
				reader = new BufferedReader(new FileReader(response));
				String line = reader.readLine();
				while (line != null) {
					rawOrders.add(line);
					line = reader.readLine();
				}
				numOrders = rawOrders.size();
				break;
			} catch (FileNotFoundException e) {
				System.out.print("That file does not exist. ");
				continue;
			} catch (IOException e) {
				System.out.print("That file is not properly formatted. ");
				continue;
			}
		}
		
        try {
            System.out.println("What is your latitude?");
            response = sc.nextLine();
            latitude = Double.parseDouble(response);
            System.out.println();
            
            System.out.println("What is your longitude?");
            response = sc.nextLine();
            longitude = Double.parseDouble(response);
            System.out.println();
            
            HQLocation = new Location(latitude, longitude);
            
			System.out.println("How many drivers will be in service today?");
            response = sc.nextLine();
            drivers = Integer.parseInt(response);
            System.out.println();
            
        } catch (NumberFormatException nfe) {
            System.out.println("The given input " + response + " is not a number.\n");
            System.out.println("Please try again.");
            return;
        }
		
		System.out.println("Listening on port 3456. Waiting for drivers...\n");
		
		try {
			ServerSocket ss = new ServerSocket(3456);
			serverThreads = new ArrayBlockingQueue<ServerThread> (drivers);
			availableClients = new ArrayBlockingQueue<ServerThread>(drivers);

			while (serverThreads.size() < drivers) {

				Socket s = ss.accept();

				String address = s.getInetAddress().toString();
				System.out.println("Connection from " + address.substring(1));

				ServerThread st = new ServerThread(this, new ObjectInputStream(s.getInputStream()), new ObjectOutputStream(s.getOutputStream()));

				serverThreads.put(st);
				int remaining = drivers-serverThreads.size();

				st.sendMessage(remaining);
				if (remaining > 1) {
					System.out.println("Waiting for " + remaining + " more drivers...\n");
				} else if (remaining == 1) {
					System.out.println("Waiting for " + remaining + " more driver...\n");
				}
			}
			System.out.println("Starting service.");
			Iterator itValues = serverThreads.iterator();
			for (int i = 0; i < serverThreads.size()-1; i++) {
				((ServerThread) itValues.next()).sendMessage(0);	// Telling each driver that service is starting
			}
			itValues = serverThreads.iterator();
			ExecutorService executors = Executors.newCachedThreadPool();

			for (int i = 0; i < serverThreads.size(); i++) {
				executors.execute((ServerThread) itValues.next());
			}
			
		} catch (Exception e) {}
						
		timeToOrder = new HashMap<Integer, ArrayList<Order>>();
		waitingDelivery = new DeliveryInformation(new ArrayList<String>(), new ArrayList<String>(), 0, this, HQLocation);
		for (String line : rawOrders) {
			String readyTimeString = line.substring(0, line.indexOf(", "));
			int readyTime = Integer.parseInt(readyTimeString);
			line = line.substring(line.indexOf(", ")+2);
			String restaurant = line.substring(0, line.indexOf(", "));
			line = line.substring(line.indexOf(", "));
			String item = line.substring(2);

			if (timeToOrder.get(readyTime) == null) {
				timeToOrder.put(readyTime, new ArrayList<Order>());
			}
			Location location = YelpAPIParser.getLocation(restaurant, HQLocation);
			timeToOrder.get(readyTime).add(new Order(restaurant, item, location, 0));
		}
		
		this.start();
		
		sc.close();
	}
	
	public void run() {
		
		ExecutorService executors = Executors.newCachedThreadPool();
		for (HashMap.Entry<Integer, ArrayList<Order>> i : timeToOrder.entrySet()) {
			ArrayList<String> rests = new ArrayList<String>();
			ArrayList<String> items = new ArrayList<String>();
			for (Order o : i.getValue()) {
				rests.add(o.getRestaurantName());
				items.add(o.getItemName());
			}
			executors.execute(new DeliveryInformation(rests, items, i.getKey(), this, HQLocation));
		}

		executors.shutdown();
		while (!executors.isTerminated() || sentOrders < numOrders) {
			if (!availableClients.isEmpty()) {
				if (waitingDelivery.size() == 0) {
					try {
						synchronized (this) {
							wait();
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					continue;
				}
				availableClients.remove().sendMessage(waitingDelivery);
				sentOrders += waitingDelivery.size();
				waitingDelivery.emptyOut();
			} else {
				try {
					synchronized (this) {
						wait();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (sentOrders == numOrders) {
				waitingDelivery.stop();
			}
		}
		
		while (numDone < drivers) {
			Thread.yield();
		}
		for (ServerThread st : availableClients) {
			st.sendMessage(null);
			availableClients.remove();
		}
		
		System.out.println("\nAll orders completed!");
		return;
	}
	
	public void increaseNumIfDone() {
		if (sentOrders == numOrders) {
			numDone++;
		}
		return;
	}
	
	public void addToWaitingDelivery(DeliveryInformation di) {
		waitingDelivery = waitingDelivery.merge(di);
		try {
			synchronized(this) {
				notify();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return;
}
	
	public void addAvailableDriver(ServerThread serverThread) {
		availableClients.add(serverThread);
		try {
			synchronized(this) {
				notify();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return;
	}
	
	public static void main(String [] args) throws IOException {
		
		new HeadquarterServer();
		return;
	}

}