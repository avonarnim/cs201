package DeliverySystem;

public class Order {

    private final String restaurantName;
    private final String itemName;
    private final Location location;
    private double distance;
    private int scheduleTime;
    private HeadquarterServer headquarters;

    public Order(String restaurantName, String itemName, Location location, double distance) {
        this.restaurantName = restaurantName;
        this.itemName = itemName;
        this.location = location;
        this.distance = distance;
    }

    public String getRestaurantName() {
        return restaurantName;
    }

    public String getItemName() {
        return itemName;
    }

    public Location getLocation() {
        return location;
    }

    public double getDistance() {
        return distance;
    }

    public void recalcDistance(Location newLocation) {
        distance = DistanceCalc.getDistance(location, newLocation);
    }
    
//	public void setWaitTime(int schedjdTime, HeadquarterServer hq) {
//		scheduleTime = schedjdTime;
//		headquarters = hq;
//		return;
//	}
//
//	public void run() {
//		try {
//			Thread.sleep(scheduleTime*1000);
//			headquarters.addToWaitingOrders(this);
//			System.out.println("ran and added");
//			synchronized (this) {
//				this.wait();	// should wait until it's delivered, then be signaled and terminate.
//				System.out.println("waiting");
//			}
//			System.out.println("terminating");
//			
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//		return;
//	}

}
