package DeliverySystem;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class DeliveryInformation implements Serializable, Runnable {

    private static final long serialVersionUID = 383927069613799417L;

    private List<String> restaurants = new ArrayList<String>();
    private List<String> items = new ArrayList<String>();

    private final Location location;
    private int scheduleTime;
    private transient HeadquarterServer headquarters;
    private transient boolean isNotDone = true;

    public DeliveryInformation(List<String> restaurants, List<String> items, int schedjTime, HeadquarterServer hq, Location location) {
        this.restaurants = restaurants;
        this.location = location;
        this.items = items;
        this.scheduleTime = schedjTime;
        this.headquarters = hq;
    }

    public List<String> getRestaurants() {
        return restaurants;
    }

    public List<String> getItems() {
        return items;
    }

    public Location getLocation() {
        return location;
    }
    
    public int size() {
    	return items.size();
    }
    
    public synchronized DeliveryInformation merge(DeliveryInformation di) {
    	if (this.size() == 0) {
    		this.stop();
    		return di;
    	} else {
        	restaurants.addAll(di.getRestaurants());
        	items.addAll(di.getItems());
        	di.stop();
        	return this;
    	}
    }
    
    public void emptyOut() {
    	restaurants.clear();
    	items.clear();
    	return;
    }
    
    public synchronized void stop() {
    	isNotDone = false;
    	return;
    }
	
	public void run() {
		try {
			Thread.sleep(scheduleTime*1000);
			headquarters.addToWaitingDelivery(this);
			while (isNotDone) {
				Thread.yield();
			}
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return;
	}
}
