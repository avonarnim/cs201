import React from "react";
import ReactDom from "react-dom";
import PropTypes from "prop-types";
import "../styles/home.scss";
import { Modal } from "bootstrap";
import Home from "../pages/Home";

export default class BasicModal extends React.Component{
    constructor(props) {
        super(props);
        this.props = props;
        this.state = {
            showModal: false
          };
    }

    render(){
        if (!this.props.showModal){
            return null;
        }else{
            this.state.showModal = true;
        }
        const showClassName = this.state.showModal ? "modals" : 'modals display-none';

        return (
            <div className={showClassName}>
                <div className="modal-main">
                    {this.props.children}
                </div>
                
            </div>
        );
        
        
    }
    
}
