import React, { Component } from "react";
import PropTypes from "prop-types";
import { Link } from "react-router-dom";


import "../styles/orders.scss";
import tapeIcon from "../resources/tape.png";


class OrderNote extends Component {
    static propTypes = {
        order: PropTypes.object.isRequired,
        onClick: PropTypes.func.isRequired
    };

    constructor(props) {
        super(props);
        this.state = {
            isLoaded: false,
            orderInfo: null,
            hostName: null,
            hostId: null
        };
    }

    async componentDidMount() {
        const { order } = this.props;
        console.log("ORDER: " + JSON.stringify(order));

        const groupResponse = await fetch('http://localhost:8080/get-group?groupId=' + order.groupId);
        const group = await groupResponse.json();
        this.setState({ hostName: group.hostName, hostId: group.hostId, isLoaded: true });

        // let fakeItems = [
        //     { name: "item1", quantity: 1, price: 1.5 },
        //     { name: "item2", quantity: 2, price: null },
        // ];
        // const fakeOrderInfo = { status: "completed", pickupLocation: "USC", host: "hostname", items: fakeItems }
        // this.setState({ orderInfo: fakeOrderInfo, isLoaded: true });
        // Add in backend (maybe not necessary):
        // const response = await fetch('/api/orders/' + orderId);
        // const body = await response.json();
        // this.setState({ orderInfo: body, isLoaded: true });
    }

    populateList = (items) => {
        let table = [];
        let header = [];
        header.push(<th>Item</th>);
        header.push(<th>Quantity</th>);
        // header.push(<th>Est Price</th>);
        table.push(<tr className='order-note-list-header'>{header}</tr>);
        for (const item of items) {
            let children = [];
            children.push(<td>{item.name}</td>);
            children.push(<td>{item.quantity}</td>);
            // if (item.estimatedPrice != null) {
            //     children.push(<td>{item.quantity * item.price}</td>);
            // }
            // else {
            //     children.push(<td>{"?"}</td>);
            // }
            table.push(<tr>{children}</tr>);
        }

        return table;
    }


    render() {
        const { order, onClick } = this.props;
        const { isLoaded, hostName, hostId } = this.state;

        if (!isLoaded) {
            return <div>Loading...</div>;
        }


        return (
            <div className='order-note-wrapper'>
                <img src={tapeIcon} className='order-note-tape' />
                <div className='order-note' onClick={onClick}>
                    <div className='order-note-header'
                        style={hostId === order.userId ? { display: "none" } : { display: "block" }}
                    >Order #{order.id}<br></br>Hosted by: {hostName}</div>
                    <div className='order-note-header'
                        style={hostId === order.userId ? { display: "block" } : { display: "none" }}>
                        Order #{order.id}<br></br>*You are hosting this order*</div>
                    <table className='order-note-table'>
                        {this.populateList(order.items)}
                    </table>
                </div>
            </div >
        );
    }
}

export default OrderNote;