import React, { Component } from "react";
import PropTypes from "prop-types";
import { Link } from "react-router-dom";


import "../styles/orders.scss";
import tapeIcon from "../resources/tape.png";


class HostedGroupNote extends Component {
    static propTypes = {
        group: PropTypes.object.isRequired,
        onClick: PropTypes.func.isRequired
    };

    constructor(props) {
        super(props);
        this.state = {
            isLoaded: false,
            groupInfo: null
        };
    }

    async componentDidMount() {
        const { order } = this.props;
        // let fakeItems = [
        //     { name: "item1", quantity: 1, price: 1.5 },
        //     { name: "item2", quantity: 2, price: null },
        // ];
        // const fakeOrderInfo = { status: "completed", pickupLocation: "USC", host: "hostname", items: fakeItems }
        // this.setState({ orderInfo: fakeOrderInfo, isLoaded: true });
        // Add in backend (maybe not necessary):
        // const response = await fetch('/api/orders/' + orderId);
        // const body = await response.json();
        // this.setState({ orderInfo: body, isLoaded: true });
    }

    populateList = (items) => {
        let table = [];
        let header = [];
        header.push(<th>Item</th>);
        header.push(<th>Quantity</th>);
        header.push(<th>Est Price</th>);
        table.push(<tr className='order-note-list-header'>{header}</tr>);
        for (const item of items) {
            let children = [];
            children.push(<td>{item.name}</td>);
            children.push(<td>{item.quantity}</td>);
            if (item.price != null) {
                children.push(<td>{item.quantity * item.price}</td>);
            }
            else {
                children.push(<td>{"?"}</td>);
            }
            table.push(<tr>{children}</tr>);
        }

        return table;
    }


    render() {
        const { group, onClick } = this.props;

        // const { isLoaded, orderInfo } = this.state;

        // if (!isLoaded) {
        //     return <div>Loading...</div>;
        // }


        return (
            <div className='order-note-wrapper'>
                <img src={tapeIcon} className='order-note-tape' />
                <div className='order-note' onClick={onClick}>
                    <div className='order-note-header'>Order #{group.groupId}<br></br>*You are hosting this order*</div>
                    <div className='group-note-body'>Order Status: {group.status}</div>
                    <div className='group-note-body'>Number of pending orders: {group.pendingOrders.length}</div>
                    <div className='group-note-body'>Number of approved orders: {group.approvedOrders.length}</div>
                </div>
            </div >
        );
    }
}

export default HostedGroupNote;