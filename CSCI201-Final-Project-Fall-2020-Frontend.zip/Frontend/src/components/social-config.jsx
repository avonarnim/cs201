//This holds the configurations for Login Modal
   
  const google = {
    client_id: "YOUR_CLIENT_ID.apps.googleusercontent.com",
    scope: "profile email"
  };
  
   
  export const googleConfig = google;