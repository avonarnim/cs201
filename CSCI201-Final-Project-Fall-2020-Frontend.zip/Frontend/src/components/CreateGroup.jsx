import React, { Component } from "react";
import PropTypes from "prop-types";
import FuzzySearch from "react-fuzzy";

import "../styles/orders.scss";

import { connect } from "react-redux";

import cancelIcon from "../resources/cancel.png";
import nextArrow from "../resources/right-arrow.png";
import backArrow from "../resources/left-arrow.png";

import classNames from "classnames";

class CreateGroup extends Component {
    constructor(props) {
        super(props);
        this.state = {
            groupName: null,
            isPublic: null,
            pickUpLocation: null,
            pickUpTime: null,
            description: null,
            addedItems: [],
            quantities: [],
            hostOrder: [],
            step: 0,
            isLoaded: false,
            listName: null,
            store: null
        }
        this.handleSelectedItem = this.handleSelectedItem.bind(this);
        this.handleSelectedGroup = this.handleSelectedGroup.bind(this);
        this.handleSubmitGroupDetails = this.handleSubmitGroupDetails.bind(this);
        this.handleChangeGroupName = this.handleChangeGroupName.bind(this);
        this.handleChangeGroupDescription = this.handleChangeGroupDescription.bind(this);
        this.handleChangePickUpLocation = this.handleChangePickUpLocation.bind(this);
        this.handleChangePickUpTime = this.handleChangePickUpTime.bind(this);
        this.handleChangePublic = this.handleChangePublic.bind(this);
        this.handleChangeListName = this.handleChangeListName.bind(this)
        this.handleChangeStore = this.handleChangeStore.bind(this);
    }

    async componentDidMount() {
        const response = await fetch('http://localhost:8080/inventory');
        const body = await response.json();
        this.setState({ inventory: body, isLoaded: true });
    }



    static propTypes = {
        handleCloseModal: PropTypes.func.isRequired,
        handleCreateNewGroup: PropTypes.func.isRequired
    };

    handleSelectedItem(event) {
        console.log(event);
        let { addedItems, quantities } = this.state;
        let idx = addedItems.findIndex(item => (item.name == event.name));
        if (idx == -1) addedItems.push({ ...event });
        // if (idx == -1) addedItems.push({ ...event, quantity: 1 });
        // else addedItems[idx].quantity++;
        if (quantities[event.name] == null) {
            quantities[event.name] = 1;
        }
        else {
            quantities[event.name]++;
        }

        this.setState({ selected: event, addedItems: addedItems, quantities: quantities });
    };

    getOrderTotal() {
        const { addedItems, quantities } = this.state;
        let total = 0;
        for (const item of addedItems) total += (item.price * quantities[item.name]);
        console.log(total);
        return total;
    };

    populateItemsList = (items) => {
        const itemsList = items.map((item) =>
            <li>
                {item.name}, ${item.price},
                    <input id="number" type="number" value={this.state.quantities[item.name]}
                    onChange={e => {
                        let { quantities } = this.state;
                        if (e.target.value < 0) e.target.value = 0;
                        quantities[item.name] = e.target.value;
                        this.setState({ quantities: quantities });
                        this.value = quantities[item.name];

                        // console.log(e.target.value);
                        // this.onChangeQuantity(e.target.value);
                        // // shallow save?
                        // item.quantity = e.target.value;
                        // const idx = items.findIndex((it => it.name === item.name));
                        // items[idx].quantity = e.target.value;
                        // e.target.setAttribute('value', e.target.value);
                    }}></input>
            </li >

        );
        return itemsList;
    }

    handleSelectedGroup = (event) => {
        console.log("selected " + JSON.stringify(event))
        this.setState({ currentGroup: event });
    }

    handleChangeGroupName = (event) => {
        this.setState({ groupName: event.target.value });
    }

    handleChangeGroupDescription = (event) => {
        this.setState({ description: event.target.value });
    }

    handleChangePickUpLocation = (event) => {
        this.setState({ pickUpLocation: event.target.value });
    }

    handleChangePickUpTime = (event) => {
        this.setState({ pickUpTime: event.target.value });
    }

    handleChangeListName = (event) => {
        this.setState({ listName: event.target.value });
    }

    handleChangeStore = (event) => {
        this.setState({ store: event.target.value });
    }

    handleSubmitGroupDetails = async () => {
        const { groupName, description, pickUpTime, pickUpLocation, isPublic } = this.state;
        if (!groupName || !description || !pickUpLocation || !pickUpTime || isPublic === null) {
            alert("Please enter all fields");
            return;
        }

        // const response = await fetch('http://localhost:8080/get-private-group?code=' + inviteCodeInput);
        // try {
        //     const body = await response.json();
        //     this.setState({ currentGroup: body });
        // } catch (err) {
        //     this.setState({ currentGroup: -1 });
        // }
    }

    handleChangePublic = (event) => {
        if (event.target.value == "public") {
            this.setState({ isPublic: true });
        }
        else {
            this.setState({ isPublic: false });
        }

    }


    getCurrentScreen = () => {
        const { step, inventory, addedItems, isPublic } = this.state;

        if (step === 0) {
            // Choose group screen
            return (<div className="enter-group-details-div">
                <div className="group-details-form">
                    <input className="group-details-input" type="text" placeholder="Enter group name"
                        value={this.state.groupName} onChange={e => {
                            this.handleChangeGroupName(e);
                        }
                        }></input>
                    <br></br>
                    <input className="group-details-input" type="text" placeholder="Enter group description"
                        value={this.state.description} onChange={e => {
                            this.handleChangeGroupDescription(e);
                        }
                        }></input>
                    <br></br>
                    <input className="group-details-input" type="text" placeholder="Enter store"
                        value={this.state.store} onChange={e => {
                            this.handleChangeStore(e);
                        }
                        }></input>
                    <br></br>
                    <input className="group-details-input" type="text" placeholder="Enter pickup location"
                        value={this.state.pickUpLocation} onChange={e => {
                            this.handleChangePickUpLocation(e);
                        }
                        }></input>
                    <br></br>
                    <input className="group-details-input" type="text" placeholder="Enter order time"
                        value={this.state.pickUpTime} onChange={e => {
                            this.handleChangePickUpTime(e);
                        }
                        }></input>
                    <br></br>
                    <input type="radio" id="public" name="public" value="public"
                        checked={isPublic === true ? "checked" : ""}
                        onChange={e => {
                            this.handleChangePublic(e);
                        }
                        }
                    ></input>
                    <label for="public">Public</label><br></br>
                    <input type="radio" id="private" name="public" value="private"
                        checked={isPublic === false ? "checked" : ""}
                        onChange={e => {
                            this.handleChangePublic(e);
                        }
                        }></input>
                    <label for="private">Private</label><br></br>
                </div>
            </div>);
        }
        else if (step == 1) {
            // Choose items screen
            return (
                <div className="select-items-div">
                    <input className="list-name-input" type="text" placeholder="Enter list name"
                        value={this.state.listName} onChange={e => {
                            this.handleChangeListName(e);
                        }
                        }></input>
                    <br></br>
                    <FuzzySearch
                        className="searchbar"
                        list={inventory}
                        keys={['name']}
                        width={430}
                        onSelect={this.handleSelectedItem}
                        placeholder="Add your own order items"
                        resultsTemplate={(props, state, styles, clickHandler) => {
                            return state.results.map((val, i) => {
                                const style = state.selectedIndex === i ? styles.selectedResultStyle : styles.resultsStyle;
                                return (
                                    <div
                                        key={i}
                                        style={style}
                                        onClick={() => clickHandler(i)}
                                    >
                                        {val.name}
                                        <span style={{ float: 'right', opacity: 0.5 }}>${val.price}</span>
                                    </div>

                                );
                            });
                        }}
                    />
                    <ul className="added-items-list">
                        {this.populateItemsList(addedItems)}
                    </ul>
                    <div className="order-total">Order Total: ${this.getOrderTotal()}</div>
                </div>
            )
        }
        else if (step == 2) {
            const { addedItems, quantities, groupName, description, pickUpLocation, pickUpTime, isPublic, listName, store } = this.state;
            const { handleCreateNewGroup } = this.props;
            let addedItemsAndQuantities = [];
            for (const item of addedItems) {
                if (quantities[item.name] != 0) addedItemsAndQuantities.push({ name: item.name, quantity: quantities[item.name] });
            }
            return (<div className='step-2-div'>
                <button className='submit-order-btn'
                    onClick={() => handleCreateNewGroup(
                        groupName,
                        isPublic,
                        description,
                        pickUpLocation,
                        pickUpTime,
                        addedItemsAndQuantities,
                        listName,
                        store
                    )}
                >Create Group</button>
            </div >);
        }
    }

    render() {
        const { handleCloseModal } = this.props;
        let { step, groupName, description, pickUpLocation, pickUpTime, store, isPublic } = this.state;

        return (
            <div className=''>
                <img
                    src={cancelIcon}
                    alt="cancel"
                    onClick={e => {
                        handleCloseModal();
                    }}
                    className='cancel-icon'
                />
                <div className=''>
                    <div className='order-top-info'>Create new order group:</div>
                </div>
                {this.getCurrentScreen()}
                <img
                    src={backArrow}
                    style={step === 0 ? { display: 'none' } : { display: 'block' }}
                    alt="back"
                    onClick={e => {
                        step--;
                        this.setState({ step: step });
                    }}
                    className='back-arrow-icon'
                />
                <img
                    src={nextArrow}
                    style={step === 2 ? { display: 'none' } : { display: 'block' }}
                    alt="next"
                    onClick={e => {
                        if (step == 0) {
                            if (!groupName || !description || !pickUpLocation || !pickUpTime
                                || isPublic === null || !store) {
                                alert("Please enter all fields");
                            }
                            else {
                                step++;
                                this.setState({ step: step });
                            }
                        }
                        else {
                            step++;
                            this.setState({ step: step });
                        }
                    }}
                    className='next-arrow-icon'
                />
                <div style={{ display: "none" }}>Icons made by <a href="https://www.flaticon.com/authors/lyolya" title="Lyolya">Lyolya</a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a></div>
                <div style={{ display: "none" }}>Icons made by <a href="https://www.flaticon.com/authors/lyolya" title="Lyolya">Lyolya</a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a></div>

            </div >
        );
    }
}


export default CreateGroup;
