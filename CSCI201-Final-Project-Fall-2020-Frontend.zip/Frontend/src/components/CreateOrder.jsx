import React, { Component } from "react";
import PropTypes from "prop-types";
import FuzzySearch from "react-fuzzy";

import "../styles/orders.scss";

import { connect } from "react-redux";

import cancelIcon from "../resources/cancel.png";
import nextArrow from "../resources/right-arrow.png";
import backArrow from "../resources/left-arrow.png";

import classNames from "classnames";

class CreateOrder extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selected: null,
            addedItems: [],
            step: 0,
            quantities: {},
            orderTotal: 0,
            inviteCodeInput: '',
            currentGroup: null,
            inventory: [],
            publicGroups: [],
        }
        this.handleSelectedItem = this.handleSelectedItem.bind(this);
        this.handleSelectedGroup = this.handleSelectedGroup.bind(this);
        this.handleSubmitInviteCode = this.handleSubmitInviteCode.bind(this);
        this.handleChangeInviteCodeInput = this.handleChangeInviteCodeInput.bind(this);
        this.handleChangeListName = this.handleChangeListName.bind(this);
    }

    async componentDidMount() {
        let response = await fetch('http://localhost:8080/inventory');
        const inventory = await response.json();
        response = await fetch('http://localhost:8080/get-public-groups');
        const publicGroups = await response.json();

        this.setState({
            inventory: inventory,
            publicGroups: publicGroups,
            isLoaded: true
        });
    }



    static propTypes = {
        handleCloseModal: PropTypes.func.isRequired,
        handleSubmitNewOrder: PropTypes.func.isRequired,
        loggedIn: PropTypes.bool.isRequired
    };

    handleSelectedItem(event) {
        console.log(event);
        let { addedItems, quantities } = this.state;
        let idx = addedItems.findIndex(item => (item.name == event.name));
        if (idx == -1) addedItems.push({ ...event });
        // if (idx == -1) addedItems.push({ ...event, quantity: 1 });
        // else addedItems[idx].quantity++;
        if (quantities[event.name] == null) {
            quantities[event.name] = 1;
        }
        else {
            quantities[event.name]++;
        }

        this.setState({ selected: event, addedItems: addedItems, quantities: quantities });
    }

    getOrderTotal() {
        const { addedItems, quantities } = this.state;
        let total = 0;
        for (const item of addedItems) total += (item.price * quantities[item.name]);
        console.log(total);
        return total;
    }

    populateItemsList = (items) => {
        const itemsList = items.map((item) =>
            <li>
                {item.name}, ${item.price},
                    <input id="number" type="number" value={this.state.quantities[item.name]}
                    onChange={e => {
                        let { quantities } = this.state;
                        if (e.target.value < 0) e.target.value = 0;
                        quantities[item.name] = e.target.value;
                        this.setState({ quantities: quantities });
                        this.value = quantities[item.name];

                        // console.log(e.target.value);
                        // this.onChangeQuantity(e.target.value);
                        // // shallow save?
                        // item.quantity = e.target.value;
                        // const idx = items.findIndex((it => it.name === item.name));
                        // items[idx].quantity = e.target.value;
                        // e.target.setAttribute('value', e.target.value);
                    }}></input>
            </li >

        );
        return itemsList;
    }

    handleSelectedGroup = (event) => {
        console.log("selected " + JSON.stringify(event))
        this.setState({ currentGroup: event });
    }

    handleChangeInviteCodeInput = (event) => {
        this.setState({ inviteCodeInput: event.target.value });
    }

    handleSubmitInviteCode = async () => {
        const { inviteCodeInput, publicGroupsList, privateGroupsList } = this.state;
        console.log("checking " + inviteCodeInput);

        const response = await fetch('http://localhost:8080/get-private-group?code=' + inviteCodeInput);
        try {
            const body = await response.json();
            this.setState({ currentGroup: body });
        } catch (err) {
            this.setState({ currentGroup: -1 });
        }
    }

    handleChangeListName = (event) => {
        this.setState({ listName: event.target.value });
    }

    displayCurrentGroup() {
        const { currentGroup } = this.state;
        if (currentGroup == -1) {
            return (<div>Invite code not found</div>);
        }
        else if (currentGroup == null) return;

        return (<div> Selected group: <br></br> Host {currentGroup.hostName}
            <br></br>Pickup Location {currentGroup.pickUpLocation} <br></br>
        Pickup Time {currentGroup.pickUpTime}
        </div >);

    }

    getCurrentScreen = () => {
        const { step, inventory, addedItems, publicGroups } = this.state;

        if (step === 0) {
            // Choose group screen
            console.log(publicGroups);
            return (<div className="select-group-div">
                <div className="select-group-div-text">Search for public groups to join, or enter invite code for specific public/private group</div>

                <FuzzySearch
                    className="searchbar"
                    list={publicGroups}
                    keys={['hostName']}
                    width={430}
                    onSelect={this.handleSelectedGroup}
                    placeholder="Search for groups by host name"
                    resultsTemplate={(props, state, styles, clickHandler) => {
                        return state.results.map((val, i) => {
                            const style = state.selectedIndex === i ? styles.selectedResultStyle : styles.resultsStyle;
                            return (
                                <div
                                    key={i}
                                    style={style}
                                    onClick={() => clickHandler(i)}
                                >
                                    {val.hostName}
                                    <span style={{ float: 'right', opacity: 0.8 }}>Pickup Location: {val.pickUpLocation}</span>
                                </div>

                            );
                        });
                    }}
                />
                <div className="invite-code-form">
                    <input className="invite-code-input" type="text" placeholder="Enter invite code"
                        value={this.state.inviteCodeInput} onChange={e => {
                            this.handleChangeInviteCodeInput(e);
                        }
                        }></input>
                    <button onClick={this.handleSubmitInviteCode}>Submit</button>

                </div>
                <div className="current-group-text">{this.displayCurrentGroup()}</div>
            </div>);
        }
        else if (step == 1) {
            // Choose items screen
            return (
                <div className="select-items-div">
                    <input className="list-name-input" type="text" placeholder="Enter list name"
                        value={this.state.listName} onChange={e => {
                            this.handleChangeListName(e);
                        }
                        }></input>
                    <br></br>
                    <FuzzySearch
                        className="searchbar"
                        list={inventory}
                        keys={['name']}
                        width={430}
                        onSelect={this.handleSelectedItem}
                        placeholder="Search for items"
                        resultsTemplate={(props, state, styles, clickHandler) => {
                            return state.results.map((val, i) => {
                                const style = state.selectedIndex === i ? styles.selectedResultStyle : styles.resultsStyle;
                                return (
                                    <div
                                        key={i}
                                        style={style}
                                        onClick={() => clickHandler(i)}
                                    >
                                        {val.name}
                                        <span style={{ float: 'right', opacity: 0.5 }}>${val.price}</span>
                                    </div>

                                );
                            });
                        }}
                    />
                    <ul className="added-items-list">
                        {this.populateItemsList(addedItems)}
                    </ul>
                    <div className="order-total">Order Total: ${this.getOrderTotal()}</div>
                </div>
            )
        }
        else if (step == 2) {
            const { loggedIn } = this.props;
            console.log("loggedIn? " + loggedIn);
            if (!loggedIn) {
                return (<div className='step-2-div'>
                    Log in to create order!
                </div>)
            }
            const { addedItems, quantities, currentGroup, listName } = this.state;
            const { handleSubmitNewOrder } = this.props;
            let addedItemsAndQuantities = [];
            for (const item of addedItems) {
                if (quantities[item.name] != 0) addedItemsAndQuantities.push({ name: item.name, quantity: quantities[item.name] });
            }
            return (<div className='step-2-div'>
                <button className='submit-order-btn'
                    onClick={() => handleSubmitNewOrder(currentGroup, addedItemsAndQuantities, listName, this.getOrderTotal())}
                >Submit Order Request</button>
                <div>Upon submitting, your order will be pending host approval.</div>
            </div >);
        }
    }

    render = () => {
        const { handleCloseModal } = this.props;
        let { step, currentGroup } = this.state;

        return (
            <div className=''>
                <img
                    src={cancelIcon}
                    alt="cancel"
                    onClick={e => {
                        handleCloseModal();
                    }}
                    className='cancel-icon'
                />
                <div className=''>
                    <div className='order-top-info'>Create new order request:</div>
                </div>
                {this.getCurrentScreen()}
                <img
                    src={backArrow}
                    style={step === 0 ? { display: 'none' } : { display: 'block' }}
                    alt="back"
                    onClick={e => {
                        step--;
                        this.setState({ step: step });
                    }}
                    className='back-arrow-icon'
                />
                <img
                    src={nextArrow}
                    style={step === 2 ? { display: 'none' } : { display: 'block' }}
                    alt="next"
                    onClick={e => {
                        if (step == 0) {
                            if (currentGroup == -1 || currentGroup == null) {
                                alert("Please select a valid group");
                            }
                            else {
                                step++;
                                this.setState({ step: step });
                            }
                        }
                        else {
                            step++;
                            this.setState({ step: step });
                        }
                    }}
                    className='next-arrow-icon'
                />
                <div style={{ display: "none" }}>Icons made by <a href="https://www.flaticon.com/authors/lyolya" title="Lyolya">Lyolya</a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a></div>
                <div style={{ display: "none" }}>Icons made by <a href="https://www.flaticon.com/authors/lyolya" title="Lyolya">Lyolya</a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a></div>

            </div >
        );
    }
}


export default CreateOrder;