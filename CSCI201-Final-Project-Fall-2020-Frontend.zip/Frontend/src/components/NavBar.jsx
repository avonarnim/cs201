import React, { Component } from "react";
import PropTypes from "prop-types";
import { Link } from "react-router-dom";


import "../styles/home.scss";
import logo from "../resources/logo.png";
import home from "../resources/home.png";
import profile from "../resources/profile.png";
import shoppingCart from "../resources/shopping-cart.png";
import {GoogleLogin} from 'react-google-login';

class NavBar extends Component {
    // static propTypes = {
    //     // buttonLabels: PropTypes.arrayOf(PropTypes.string).isRequired,
    //     active: PropTypes.string.isRequired,
    //     onClick: PropTypes.func.isRequired,
    // };

    constructor(props) {
        super(props);
        this.state = { active: 'Home',
                       loggedIn: false };
    }

    onClick = (newActive) => {
        console.log("NEW ACTIVE: " + newActive);
        this.setState({
            active: newActive,
        });
    };

    setLoginValues(response){
        this.setState({
            loggedIn: true
        });
        
      }

    logout(){
        this.setState({
            loggedIn: false
        });
    }

    render() {
        const { active } = this.state;
        const responseGoogle = (response) => {
            this.setLoginValues(response);
          }
          const failure = (error) =>{
            this.logout();
          }

        const displayGroups =  this.state.loggedIn
        ? <Link to="/groups">
                <div className={active === 'Hosted Groups' ? 'selected-navbar-btn' : 'unselected-navbar-btn'}>
                    <div className='navbar-item-text-groups'
                        onClick={() => {
                            { this.onClick('Hosted Groups') }
                        }}>
                        hosted groups
                    </div>
                </div>
            </Link>
        :<div></div>
        
        return (
            <div className='navbar-wrapper'>
                <img src={logo} className='logo' />
                <div className='navbar-div'>

                    <Link to="/">
                        <div className={active === 'Home' ? 'selected-navbar-btn' : 'unselected-navbar-btn'}>
                            <img src={home}
                                className='navbar-item-icon'
                                onClick={() => {
                                    { this.onClick('Home') }
                                }} />
                            <div className='navbar-item-text-home'
                                onClick={() => {
                                    { this.onClick('Home') }
                                }} >
                                home
                            </div>
                        </div>

                    </Link>
                    <Link to="/loginpage">
                        <div className={active === 'Profile' ? 'selected-navbar-btn' : 'unselected-navbar-btn'}>
                            <img src={profile}
                                className='navbar-item-icon'
                                onClick={() => {
                                    { this.onClick('Profile') }
                                }} />
                            <div className='navbar-item-text-profile'
                                onClick={() => {
                                    { this.onClick('Profile') }
                                }}>
                                profile
                            </div>
                        </div>
                    </Link>
                    
                    <Link to="/orders">
                        <div className={active === 'Orders' ? 'selected-navbar-btn' : 'unselected-navbar-btn'}>
                            <img src={shoppingCart}
                                className='navbar-item-icon'
                                onClick={() => {
                                    { this.onClick('Orders') }
                                }} />
                            <div className='navbar-item-text-orders'
                                onClick={() => {
                                    { this.onClick('Orders') }
                                }}>
                                orders
                            </div>
                        </div>
                    </Link>
                    {displayGroups}
                </div >
                <div style={{ display: "none" }}>Icons made by <a href="https://www.flaticon.com/free-icon/shopping-cart_609496?term=cart&page=1&position=20" title="Vitaly Gorbachev">Vitaly Gorbachev</a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a></div>

                <GoogleLogin
                        clientId="993957174043-aoaec0k30nh2vkk2u7sl1101im82kakt.apps.googleusercontent.com"
                        buttonText="Login"
                        onSuccess={responseGoogle}
                        onFailure={failure}
                        cookiePolicy={'single_host_origin'}
                        isSignedIn={true}
                        disabled={true}
                        className="invisible"
                        />

            </div >

        );
    }
}

export default NavBar;