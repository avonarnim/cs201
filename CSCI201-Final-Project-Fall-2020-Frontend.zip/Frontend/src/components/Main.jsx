import React from 'react';
import { Switch, Route } from 'react-router-dom';

import Home from '../pages/Home';
import OrdersPage from '../pages/OrdersPage';
import ProfilePage from '../pages/ProfilePage';
import HostedGroupsPage from '../pages/HostedGroupsPage';

const Main = () => {
    return (
        <Switch> {/* The Switch decides which component to show based on the current URL.*/}
            <Route exact path='/CSCI201-Final-Project-Fall-2020' component={Home}></Route>
            <Route exact path='/' component={Home} ></Route>
            <Route exact path='/loginpage' component={ProfilePage}></Route>
            <Route exact path='/orders' component={OrdersPage}></Route>
            <Route exact path='/groups' component={HostedGroupsPage}></Route>
        </Switch>
    );
}

export default Main;