import React, { Component } from "react";
import PropTypes from "prop-types";

import "../styles/orders.scss";

import { connect } from "react-redux";

import cancelIcon from "../resources/cancel.png";

import classNames from "classnames";

class OrderDetails extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isLoaded: false,
            orderInfo: null
        };
    }

    async componentDidMount() {
        const { orderId } = this.props;

        const savedListIdResponse = await fetch(`http://localhost:8080/get-saved-list-id?orderId=${orderId}`);
        const savedListId = await savedListIdResponse.text();
        const itemsResponse = await fetch(`http://localhost:8080/getSavedList?orderId=${savedListId}`);
        const items = await itemsResponse.json();

        const groupIdResponse = await fetch('http://localhost:8080/get-group-id?orderId=' + orderId);
        const groupId = await groupIdResponse.json();

        const groupResponse = await fetch('http://localhost:8080/get-group?groupId=' + groupId);
        const group = await groupResponse.json();

        const estCostResponse = await fetch('http://localhost:8080/get-estimated-cost?orderId=' + orderId);
        const estCost = await estCostResponse.text();
        // this.setState({ hostName: group.hostName, isLoaded: true });

        const approvalResponse = await fetch('http://localhost:8080/get-approved-status?orderId=' + orderId);
        const approved = await approvalResponse.text();

        const orderInfo = { approved: approved, host: group.hostName, pickupLocation: group.pickUpLocation, pickupTime: group.pickUpTime, items: items, status: group.status, estCost: estCost }
        // Add in backend:
        // const response = await fetch('/api/orders/' + orderId);
        // const body = await response.json();
        this.setState({ orderInfo: orderInfo, isLoaded: true });
    }

    static propTypes = {
        orderId: PropTypes.number.isRequired,
        handleCloseModal: PropTypes.func.isRequired,
        handleCancelOrder: PropTypes.func.isRequired,
        mockOrder: PropTypes.object,
    };

    populateList = (items) => {
        let table = [];
        let header = [];
        header.push(<th>Item</th>);
        header.push(<th>Quantity</th>);
        // header.push(<th>Est Price</th>);
        table.push(<tr className='order-note-list-header'>{header}</tr>);
        for (const item of items) {
            let children = [];
            children.push(<td>{item.name}</td>);
            children.push(<td>{item.quantity}</td>);
            // if (item.price != null) {
            //     children.push(<td>{item.quantity * item.price}</td>);
            // }
            // else {
            //     children.push(<td>{"?"}</td>);
            // }
            table.push(<tr>{children}</tr>);
        }

        return table;
    }

    render() {
        const { orderId, handleCloseModal, handleCancelOrder } = this.props;
        const { isLoaded, orderInfo } = this.state;

        if (!isLoaded) {
            return <div>Loading...</div>;
        }


        return (
            <div className=''>
                <img
                    src={cancelIcon}
                    alt="cancel"
                    onClick={e => {
                        handleCloseModal();
                    }}
                    className='cancel-icon'
                />
                <div className=''>
                    <div className='order-top-info'>Order #{orderId}<br></br>Hosted by: {orderInfo.host}</div>
                    <div className='order-bottom-info'>
                        <div className=''>Order Status: {orderInfo.status}<br></br>
                        Approved? {orderInfo.approved}
                            <br></br>
                        Pickup Location: {orderInfo.pickupLocation}
                        </div>
                        {/* <button
                            className='cancel-order-btn'
                            style={orderInfo.status == 'completed' ? { display: 'none' } : { display: 'block' }}
                            onClick={e => {
                                handleCancelOrder(orderId);
                            }}>
                            Cancel Order
                        </button> */}

                    </div>
                    <div className=''>Your current order:</div>
                    <table className='order-note-table order-details-items-table'>
                        {this.populateList(orderInfo.items)}
                    </table>
                    <div
                        style={orderInfo.estCost == 0 ? { display: "none" } : { display: "block" }}
                    >Total estimated cost: ${orderInfo.estCost}</div>
                </div>
            </div >
        );
    }
}


export default OrderDetails;
