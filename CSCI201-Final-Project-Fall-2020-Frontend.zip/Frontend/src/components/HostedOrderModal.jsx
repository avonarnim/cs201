import React, { Component } from "react";
import PropTypes from "prop-types";

import "../styles/orders.scss";

import { connect } from "react-redux";

import cancelIcon from "../resources/cancel.png";
import dropdownIcon from "../resources/dropdown.png";
import dropdownOpenIcon from "../resources/dropdown-open.png";
import checkmark from "../resources/check.png";
import reject from "../resources/close.png"

import classNames from "classnames";

class HostedOrderModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isLoaded: false,
            groupInfo: null,
            infoShowing: [],
            status: null,
        };
        this.openOrder = this.openOrder.bind(this);
        this.closeOrder = this.closeOrder.bind(this);
        this.populatePendingOrders = this.populatePendingOrders.bind(this);
        this.handleUpdateStatus = this.handleUpdateStatus.bind(this);
    }

    async componentDidMount() {
        const { groupId } = this.props;

        const groupResponse = await fetch('http://localhost:8080/get-group?groupId=' + groupId);
        const group = await groupResponse.json();

        console.log(JSON.stringify(group));
        console.log(JSON.stringify(group.approvedOrders));
        console.log(group.status)

        const groupInfo = {
            id: groupId,
            pickupLocation: group.pickUpLocation,
            pickupTime: group.pickUpTime,
            host: group.hostName,
            acceptedOrders: group.approvedOrders,
            pendingOrders: group.pendingOrders,
        }
        this.setState({ groupInfo: groupInfo, isLoaded: true, status: group.status });
        // Add in backend (have to update):
        // const response = await fetch('/api/orders/' + orderId);
        // const body = await response.json();
        // this.setState({ orderInfo: body, isLoaded: true });
    }

    static propTypes = {
        groupId: PropTypes.number.isRequired,
        handleCloseModal: PropTypes.func.isRequired,
        // handleUpdateGroup: PropTypes.func.isRequired,
        handleRejectOrder: PropTypes.func.isRequired,
        handleAcceptOrder: PropTypes.func.isRequired,
        handleUpdateStatusRequest: PropTypes.func.isRequired
    };

    populateList = (items) => {
        let table = [];
        let header = [];
        header.push(<th>Item</th>);
        header.push(<th>Quantity</th>);
        // header.push(<th>Est Price</th>);
        table.push(<tr className='order-note-list-header'>{header}</tr>);
        for (const item of items) {
            let children = [];
            children.push(<td>{item.name}</td>);
            children.push(<td>{item.quantity}</td>);
            // if (item.price != null) {
            //     children.push(<td>{item.quantity * item.price}</td>);
            // }
            // else {
            //     children.push(<td>{"?"}</td>);
            // }
            table.push(<tr>{children}</tr>);
        }

        return table;
    }

    openOrder = (order) => {
        console.log("opening " + order);
        let { infoShowing } = this.state;
        infoShowing.push(order.id);
        this.setState({ infoShowing: infoShowing });
    }

    closeOrder = (order) => {
        console.log("closing " + order);
        let { infoShowing } = this.state;
        infoShowing.splice(infoShowing.findIndex((item) => (item == order.id)), 1);
        this.setState({ infoShowing: infoShowing });
    }

    populatePendingOrders = (orders) => {
        const { infoShowing, groupInfo } = this.state;
        const { handleAcceptOrder, handleRejectOrder } = this.props;
        console.log(infoShowing);
        const ordersList = orders.map((order) =>
            <div>
                <div className='hosted-order-modal-order-name'
                    onClick={e => {
                        infoShowing.includes(order.id) ? this.closeOrder(order) : this.openOrder(order);
                    }}>
                    Order #{order.id} from {order.userName}

                    <img
                        src={dropdownIcon}
                        alt="display-order"
                        className='dropdown-icon'
                        style={infoShowing.includes(order.id) ? { display: "none" } : { display: "block" }}
                    />
                    <img
                        src={dropdownOpenIcon}
                        alt="collapse-order"
                        className='dropdown-icon'
                        style={infoShowing.includes(order.id) ? { display: "block" } : { display: "none" }}
                    />
                    <img
                        src={reject}
                        alt="reject order"
                        onClick={e => {
                            groupInfo.pendingOrders.splice(groupInfo.pendingOrders.findIndex((item) => (item.id == order.id)), 1);
                            this.setState({ groupInfo: groupInfo });
                            // remove once backend is in, do thru routing

                            handleRejectOrder(order);
                            this.closeOrder(order)
                        }}
                        className='dropdown-icon'

                    />
                    <img
                        src={checkmark}
                        alt="accept order"
                        onClick={e => {
                            groupInfo.pendingOrders.splice(groupInfo.pendingOrders.findIndex((item) => (item.id == order.id)), 1);
                            groupInfo.acceptedOrders.push(order);
                            this.setState({ groupInfo: groupInfo });

                            handleAcceptOrder(order);
                            this.openOrder(order)
                        }}
                        className='dropdown-icon'

                    />
                </div >
                <div className='hosted-order-modal-order-items'
                    style={infoShowing.includes(order.id) ? { height: "100px" } : { height: 0 }}
                >{this.populateList(order.orders)}</div>
            </div>


        );
        return ordersList;
    }

    populateAcceptedOrders = (orders) => {
        const { infoShowing } = this.state;
        console.log(infoShowing);
        const ordersList = orders.map((order) =>
            <div>
                <div className='hosted-order-modal-order-name'
                    onClick={e => {
                        (infoShowing.includes(order.id) ? this.closeOrder(order) : this.openOrder(order));
                    }}>
                    Order #{order.id} from {order.userName}

                    <img
                        src={dropdownIcon}
                        alt="display-order"
                        className='dropdown-icon'
                        style={infoShowing.includes(order.id) ? { display: "none" } : { display: "block" }}
                    />
                    <img
                        src={dropdownOpenIcon}
                        alt="collapse-order"
                        className='dropdown-icon'
                        style={infoShowing.includes(order.id) ? { display: "block" } : { display: "none" }}
                    />
                </div >
                <div className='hosted-order-modal-order-items'
                    style={infoShowing.includes(order.id) ? { height: "100px" } : { height: 0 }}
                >{this.populateList(order.orders)}</div>
            </div>


        );
        return ordersList;
    }

    populatePaidForOrders = (orders) => {
        const { handlePaidForOrder } = this.props;
        const { infoShowing, groupInfo } = this.state;

        console.log(infoShowing);
        const ordersList = orders.map((order) => {
            if (order.paidFor == true) {
                return (<div>
                    <div className='hosted-order-modal-order-name'
                        onClick={e => {
                            (infoShowing.includes(order.id) ? this.closeOrder(order) : this.openOrder(order));
                        }}>
                        Order #{order.id} from {order.userName}

                        <img
                            src={dropdownIcon}
                            alt="display-order"
                            className='dropdown-icon'
                            style={infoShowing.includes(order.id) ? { display: "none" } : { display: "block" }}
                        />
                        <img
                            src={dropdownOpenIcon}
                            alt="collapse-order"
                            className='dropdown-icon'
                            style={infoShowing.includes(order.id) ? { display: "block" } : { display: "none" }}
                        />
                    </div >
                    <div className='hosted-order-modal-order-items'
                        style={infoShowing.includes(order.id) ? { height: "100px" } : { height: 0 }}
                    >{this.populateList(order.orders)}</div>
                </div>)
            }
        });
        return ordersList;
    }

    handleClickUnpaidOrder = async (order) => {
        const { groupId, handlePaidForOrder } = this.props;
        await handlePaidForOrder(order);
        this.closeOrder(order);


        const groupResponse = await fetch('http://localhost:8080/get-group?groupId=' + groupId);
        const group = await groupResponse.json();

        console.log(JSON.stringify(group));
        console.log(JSON.stringify(group.approvedOrders));
        console.log(group.status)

        const groupInfo = {
            id: groupId,
            pickupLocation: group.pickUpLocation,
            pickupTime: group.pickUpTime,
            host: group.hostName,
            acceptedOrders: group.approvedOrders,
            pendingOrders: group.pendingOrders,
        }
        this.setState({ groupInfo: groupInfo, isLoaded: true, status: group.status });

    }

    populateUnpaidForOrders = (orders) => {
        const { handlePaidForOrder } = this.props;
        const { infoShowing, groupInfo } = this.state;

        console.log(infoShowing);
        const ordersList = orders.map((order) => {
            console.log(order);
            if (order.paidFor == false) {
                return (<div>
                    <div className='hosted-order-modal-order-name'
                        onClick={e => {
                            (infoShowing.includes(order.id) ? this.closeOrder(order) : this.openOrder(order));
                        }}>
                        Order #{order.id} from {order.userName}

                        <img
                            src={dropdownIcon}
                            alt="display-order"
                            className='dropdown-icon'
                            style={infoShowing.includes(order.id) ? { display: "none" } : { display: "block" }}
                        />
                        <img
                            src={dropdownOpenIcon}
                            alt="collapse-order"
                            className='dropdown-icon'
                            style={infoShowing.includes(order.id) ? { display: "block" } : { display: "none" }}
                        />
                        <img
                            src={checkmark}
                            alt="order was paid for"
                            onClick={e => {
                                this.handleClickUnpaidOrder(order);
                            }}
                            className='dropdown-icon'

                        />
                        <div className='paid-for-text'>Paid for:</div>
                    </div >
                    <div className='hosted-order-modal-order-items'
                        style={infoShowing.includes(order.id) ? { height: "100px" } : { height: 0 }}
                    >{this.populateList(order.orders)}</div>
                </div>)
            }
        });
        return ordersList;
    }

    handleUpdateStatus = (event) => {
        this.setState({ status: event.target.value });
        const { handleUpdateStatusRequest, groupId } = this.props;
        handleUpdateStatusRequest(groupId, event.target.value);
    }

    render() {
        const { groupId, handleCloseModal, handleCancelOrder } = this.props;
        const { isLoaded, groupInfo, status } = this.state;
        console.log("Status: " + status);

        if (!isLoaded) {
            return <div>Loading...</div>;
        }


        return (
            <div className=''>
                <img
                    src={cancelIcon}
                    alt="cancel"
                    onClick={e => {
                        handleCloseModal();
                    }}
                    className='cancel-icon'
                />

                <div className='order-top-info'>Order #{groupId}<br></br>Hosted by: {groupInfo.host}</div>
                <div>Order Status: </div>
                <input type="radio"
                    id="not-placed"
                    name="status"
                    value="not placed"
                    checked={status === "not placed" ? "checked" : ""}
                    onChange={e => {
                        this.handleUpdateStatus(e);
                    }
                    }
                ></input>
                <label for="not-placed">Not Placed</label><br></br>
                <input type="radio" id="placed" name="status" value="placed"
                    checked={status === "placed" ? "checked" : ""}
                    onChange={e => {
                        this.handleUpdateStatus(e);
                    }
                    }></input>
                <label for="placed">Placed</label><br></br>
                <input type="radio" id="ready-for-pickup" name="status" value="ready for pickup"
                    checked={status === "ready for pickup" ? "checked" : ""}
                    onChange={e => {
                        this.handleUpdateStatus(e);
                    }
                    }></input>
                <label for="ready-for-pickup">Ready for Pick Up</label><br></br>
                <input type="radio" id="fully-completed" name="status" value="fully completed"
                    checked={status === "fully completed" ? "checked" : ""}
                    onChange={e => {
                        this.handleUpdateStatus(e);
                    }
                    }></input>
                <label for="fully-completed">Fully Completed</label><br></br>
                <div
                    style={status === "fully completed" ? { display: "none" } : { display: "block" }}
                    className='hosted-group-orders-div-wrapper'>
                    Pending Orders:
                    <div className='hosted-group-orders-div'>

                        {this.populatePendingOrders(groupInfo.pendingOrders)}
                    </div>
                    Accepted Orders:
                    <div className='hosted-group-orders-div'>

                        {this.populateAcceptedOrders(groupInfo.acceptedOrders)}
                    </div>
                </div >
                <div
                    style={status === "fully completed" ? { display: "block" } : { display: "none" }}
                    className='hosted-group-orders-div-wrapper'>
                    Unpaid Orders:
                    <div className='hosted-group-orders-div'>
                        {this.populateUnpaidForOrders(groupInfo.acceptedOrders)}
                    </div>
                    Paid Orders:
                    <div className='hosted-group-orders-div'>
                        {this.populatePaidForOrders(groupInfo.acceptedOrders)}
                    </div>

                </div >
                <div style={{ display: "none" }}>Icons made by <a href="https://www.flaticon.com/authors/freepik" title="Freepik">Freepik</a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a></div>
                <div style={{ display: "none" }}>Icons made by <a href="https://www.flaticon.com/authors/freepik" title="Freepik">Freepik</a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a></div>
                <div style={{ display: "none" }}>Icons made by <a href="https://www.flaticon.com/authors/freepik" title="Freepik">Freepik</a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a></div>

            </div >
        );
    }
}

export default HostedOrderModal;
