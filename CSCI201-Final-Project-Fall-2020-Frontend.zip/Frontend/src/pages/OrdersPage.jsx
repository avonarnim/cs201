import React, { Component } from "react";
import Modal from 'react-modal';
import PropTypes from "prop-types";

import OrderNote from "../components/OrderNote.jsx";
import OrderDetails from "../components/OrderDetails.jsx";
import CreateOrder from "../components/CreateOrder.jsx"
import HostedOrderModal from "../components/HostedOrderModal.jsx";
import HostedGroupNote from "../components/HostedGroupNote.jsx";
import { GoogleLogin, GoogleLogout } from 'react-google-login';



import "../styles/orders.scss";


class OrdersPage extends Component {
    //   static propTypes = {
    //     // make prop for function that populates div, passed in by main
    //     buttonLabels: PropTypes.arrayOf(PropTypes.string).isRequired,
    //     active: PropTypes.string.isRequired,
    //     onClick: PropTypes.func.isRequired,
    //   };

    constructor(props) {
        super(props);
        // this.state = { active: props.active };
        this.state = {
            showInfoModal: false,
            showCreateModal: false,
            showHostedOrderModal: false,
            activeOrder: -1,
            isLoaded: false,
            orders: [],
            nextId: 6,
            currentUserId: null,
            name: null,
            email: null,
            loggedIn: false
        };
        this.handleCloseInfoModal = this.handleCloseInfoModal.bind(this);
        this.handleOpenInfoModal = this.handleOpenInfoModal.bind(this);
        this.handleCloseCreateModal = this.handleCloseCreateModal.bind(this);
        this.handleOpenCreateModal = this.handleOpenCreateModal.bind(this);
        this.handleSubmitNewOrder = this.handleSubmitNewOrder.bind(this);
        this.handleCloseHostedOrderModal = this.handleCloseHostedOrderModal.bind(this);
        this.handleOpenHostedOrderModal = this.handleOpenHostedOrderModal.bind(this);
    }

    async componentDidMount() {

        // Add in backend:
        // const response = await fetch('/api/orders/' + orderId);
        // const body = await response.json();
        // this.setState({ orderInfo: body, isLoaded: true });
        let { isLoaded, currentUserId } = this.state;
        this.setState({ isLoaded: true });
    }

    handleCloseInfoModal() {
        this.setState({ showInfoModal: false, activeOrder: -1 });
        // update backend if need to update anything
    }

    handleOpenInfoModal(id) {
        this.setState({ showInfoModal: true, activeOrder: id });
    }

    handleCloseCreateModal() {
        this.setState({ showCreateModal: false });
        // update backend if need to update anything
    }

    handleOpenCreateModal() {
        this.setState({ showCreateModal: true });
    }

    handleCloseHostedOrderModal() {
        this.setState({ showHostedOrderModal: false, activeOrder: -1 });
        // update backend if need to update anything
    }

    handleOpenHostedOrderModal(id) {
        this.setState({ showHostedOrderModal: true, activeOrder: id });
    }

    async handleSubmitNewOrder(group, items, listName, cost) {
        this.handleCloseCreateModal();
        // // mock
        // let { orders, nextId } = this.state;
        // const order = { "host": group.host, "items": items, "id": nextId, "status": "pending" };
        // orders.push(order);
        // nextId++;
        // this.setState({ orders: orders, nextId: nextId });

        // api post request 

        const { currentUserId } = this.state;
        const listIdResponse = await fetch(`http://localhost:8080/setSavedList?userId=${currentUserId}&listName=${listName}`,
            {
                // credentials: 'include',
                method: "POST",
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(items)
            });
        const listId = await listIdResponse.text();
        await fetch(`http://localhost:8080/insert-new-member-order?groupId=${group.groupId}&maxCost=${parseInt(cost)}&savedListId=${listId}&userId=${currentUserId}`,
            { method: "POST" });
        const ordersResponse = await fetch(`http://localhost:8080/user-current-orders?userId=${currentUserId}`);
        const orders = await ordersResponse.json();
        const updatedOrders = [];
        for (const order of orders) {
            const savedListIdResponse = await fetch(`http://localhost:8080/get-saved-list-id?orderId=${parseInt(order.id)}`);
            const savedListId = await savedListIdResponse.text();
            const itemsResponse = await fetch(`http://localhost:8080/getSavedList?orderId=${savedListId}`);
            const items = await itemsResponse.json();
            updatedOrders.push({ ...order, items: items })
        }

        this.setState({ orders: updatedOrders });
    }


    handleCancelOrder = async (id) => {
        alert("Order #" + id + " canceled");
        this.setState({ showInfoModal: false });
        // pseudo removal, replace w backend deletion
        let { orders } = this.state;
        orders.splice(orders.findIndex((order) => order.id === id), 1);
        this.setState({ orders: orders });
        // await this.props.dispatch(editAdmin(id, newprofile));
        // await this.props.dispatch(getAdmins());
    };

    populateOrderNotes = (orders) => {
        const orderNotes = orders.map((order) =>
            <OrderNote order={order} onClick={(e) => {
                this.handleOpenInfoModal(order.id);
            }} />
        );
        return orderNotes;
    }

    handleRejectOrder(order) {
        console.log("order rejected");
    }

    handleAcceptOrder(order) {
        console.log("order accepted");
    }

    setLoginValues(response) {
        console.log(response.profileObj.name);
        console.log(response.profileObj.email);
        console.log(response.profileObj.googleId);
        this.setState({
            loggedIn: true,
            name: response.profileObj.name,
            email: response.profileObj.email,
            currentUserId: response.profileObj.googleId
        });
    }

    async getCurrentUser() {
        const { email, name, currentUserId } = this.state;

        // await fetch(`http://localhost:8080/storeNewUser?userId=${currentUserId}&name=${name}&email=${email}`);
        const response = await fetch("http://localhost:8080/user-name?userId=" + currentUserId);
        try {
            const body = await response.text();
            console.log(body);
            if (!body) {
                console.log("body null");
                throw "error";
            }
        } catch (err) {
            // if no id found, need to create user
            await fetch(`http://localhost:8080/storeNewUser?userId=${currentUserId}&name=${name}&email=${email}`)
            const newResponse = await fetch("http://localhost:8080/user-name?userId=" + currentUserId);
            const body = await newResponse.text();
        }
    }

    logout() {
        this.setState({
            loggedIn: false,
            name: '',
            email: ''
        });
    }


    render() {

        const responseGoogle = async (response) => {
            this.setLoginValues(response);
            this.getCurrentUser();
            const { currentUserId } = this.state;

            const ordersResponse = await fetch(`http://localhost:8080/user-current-orders?userId=${currentUserId}`);
            const orders = await ordersResponse.json();
            const updatedOrders = [];
            for (const order of orders) {
                const savedListIdResponse = await fetch(`http://localhost:8080/get-saved-list-id?orderId=${parseInt(order.id)}`);
                const savedListId = await savedListIdResponse.text();
                const itemsResponse = await fetch(`http://localhost:8080/getSavedList?orderId=${savedListId}`);
                const items = await itemsResponse.json();
                updatedOrders.push({ ...order, items: items })
            }

            this.setState({ orders: updatedOrders, isLoaded: true });
        }
        const failure = (error) => {
            console.log(error);
            this.logout();
        }

        const groupId = 1;
        let fakeItems = [
            { name: "item1", quantity: 1, price: 1.5 },
            { name: "item2", quantity: 2, price: null },
            { name: "item3", quantity: 2, price: 4 },
        ];
        const fakeOrderInfo = { user: "user1", items: fakeItems }
        const fakeOrderInfo2 = { user: "user2", items: fakeItems }
        const fakeOrdersList = [
            { ...fakeOrderInfo, id: 1 },
            { ...fakeOrderInfo2, id: 2 },
        ]
        const fakeOrderInfo3 = { user: "user3", items: fakeItems }
        const fakeOrderInfo4 = { user: "user4", items: fakeItems }
        const fakePendingOrdersList = [
            { ...fakeOrderInfo3, id: 3 },
            { ...fakeOrderInfo4, id: 4 },
        ]
        const groupInfo = {
            id: groupId,
            pickupLocation: "USC",
            pickupTime: "December 1 2020 10AM",
            host: "hostname",
            acceptedOrders: fakeOrdersList,
            pendingOrders: fakePendingOrdersList
        }

        const { activeOrder, orders, isLoaded } = this.state;
        if (!isLoaded) {
            console.log("not loaded :(")
        }

        console.log(JSON.stringify(orders));
        return (
            <div className='orderspage' >

                <div className='orders-page-header'>
                    Your Orders
                </div>
                <div className='notes-div'>
                    <div className='new-order-text'
                        onClick={(e) => {
                            this.handleOpenCreateModal();
                        }}>
                        Create New Order
                        <div className='new-order-btn'>
                            +
                        </div>
                    </div>
                    {this.populateOrderNotes(orders)}

                    <Modal
                        isOpen={this.state.showInfoModal}
                        contentLabel="Minimal Modal Example"
                        ariaHideApp={false}
                        className="order-details-modal"
                        onRequestClose={this.handleCloseInfoModal}
                    >
                        <OrderDetails orderId={activeOrder}
                            handleCloseModal={this.handleCloseInfoModal}
                            handleCancelOrder={this.handleCancelOrder}
                        />
                    </Modal>

                    <Modal
                        isOpen={this.state.showCreateModal}
                        contentLabel="Minimal Modal Example"
                        ariaHideApp={false}
                        className="order-details-modal"
                        onRequestClose={this.handleCloseCreateModal}
                    >
                        <CreateOrder
                            handleCloseModal={this.handleCloseCreateModal}
                            handleSubmitNewOrder={this.handleSubmitNewOrder}
                            loggedIn={this.state.loggedIn}
                        />
                    </Modal>

                    <Modal
                        isOpen={this.state.showHostedOrderModal}
                        contentLabel="Minimal Modal Example"
                        ariaHideApp={false}
                        className="hosted-order-modal"
                        onRequestClose={this.handleCloseCreateModal}
                    >
                        <HostedOrderModal
                            groupId={1}
                            handleCloseModal={this.handleCloseCreateModal}
                            handleUpdateGroup={this.handleSubmitNewOrder}
                            handleRejectOrder={this.handleRejectOrder}
                            handleAcceptOrder={this.handleAcceptOrder}

                        />
                    </Modal>

                </div>
                <GoogleLogin
                    clientId="993957174043-aoaec0k30nh2vkk2u7sl1101im82kakt.apps.googleusercontent.com"
                    buttonText="Login"
                    onSuccess={responseGoogle}
                    onFailure={failure}
                    cookiePolicy={'single_host_origin'}
                    isSignedIn={true}
                    disabled={true}
                    className="invisible"
                />

                <div style={{ display: "none" }}>Adhesive tape piece by Juan Pablo Bravo from the Noun Project</div>
            </div >
        );
    }
}

export default OrdersPage;