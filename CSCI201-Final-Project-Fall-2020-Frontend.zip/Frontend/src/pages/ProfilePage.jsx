import React, { Component } from "react";
import ReactModalLogin from "react-modal-login";
import { googleConfig } from "../components/social-config.jsx";
import {InputGroup, FormControl, Form, FormGroup, Button, ButtonGroup,ToggleButton, Col, Row} from 'react-bootstrap';
import {GoogleLogin, GoogleLogout} from 'react-google-login';
import "../styles/home.scss";
import axios from 'axios';
//For more info->
//https://www.npmjs.com/package/react-modal-login

class ProfilePage extends Component {
  constructor(props) {
    super(props);

    this.state = {
      active: "Login",
      showModal: false,
      loggedIn: false,
      loading: false,
      error: null,
      initialTab: null,
      name: '',
      email: '',
      googleId: ''
    };

  }
  onClick = (newActive) => {
    console.log(newActive);
    this.setState({
        active: newActive,
    });
  };

  openModal(initialTab) {
    this.setState({
      initialTab: initialTab
    }, () => {
      this.setState({
        showModal: true,
      })
    });
  }

  onLoginSuccess(method, response) {

    this.closeModal();
    this.setState({
      loggedIn: method,
      loading: false
    })
  }

  onLoginFail(method, response) {

    this.setState({
      loading: false,
      error: response
    })
  }

  startLoading() {
    this.setState({
      loading: true
    })
  }

  finishLoading() {
    this.setState({
      loading: false
    })
  }

  afterTabsChange() {
    this.setState({
      error: null,
      recoverPasswordSuccess: false,
    });
  }

  closeModal() {
    this.setState({
      showModal: false,
      error: null
    });
  }

  displayButtons(){
    return(
      <div>
          <button
            className="RML-btn"
            onClick={() => this.openModal('login')}
          >
            Login
          </button>

          <button
            className="RML-btn"
            onClick={() => this.openModal('register')}
          >
            Register
          </button>
        </div>
    );
  }

  displayEmptyLines(){
    return(
        <div>
            <br/><br/><br/><br/><br/><br/><br/><br/>
            <br/><br/><br/><br/><br/><br/><br/><br/>
        </div>
    );
}

  loggedInProfile(){
    return(
      <div className="profile-info">
        <h2>Hello, {this.state.name}</h2>
        <Form>
        <Form.Group as={Row}>
            <Form.Label column sm={2}/>
            <Form.Label column sm={4}>
              Email:
            </Form.Label>
            <Form.Label column sm={2}>
              {this.state.email}
            </Form.Label>
            <Form.Label column sm={2}/>
          </Form.Group>

          <Form.Group as={Row}>
            <Form.Label column sm={2}/>
            <Form.Label column sm={2}>
            </Form.Label>
            <Form.Label column sm={5}>
            
            </Form.Label>
            <Form.Label column sm={2}/>
          </Form.Group>
          
        </Form>
      </div>
    );
  }

  
  setLoginValues(response){
      
    this.setState({
      loggedIn: true,
      name: response.profileObj.name,
      email: response.profileObj.email,
      googleId:"a"
    });
    //IF NEW USER ADD TO data.user TABLE
    axios.post("http://localhost:8080/storeNewUser",{
        id:this.state.googleId,
        name:this.state.name,
        email: this.state.email
      
    }).then(response=>console.log(response)).catch(error=>console.log(error));

    
  
  }

  logout(){
    this.setState({
      loggedIn: false,
      name: '',
      email: '',
      googleId:''
    });
  }



  render() {

    const responseGoogle = (response) => {
      this.setLoginValues(response);
      console.log(response);
    }
    const failure = (error) =>{
      console.log(error);
    }

    const logout = (e) => {
      this.logout();
    }

    const loggedIn = this.state.loggedIn
      ? this.loggedInProfile()
      : <div>
          <p>You are signed out</p>
      </div>;

    const displayLogoutButton = this.state.loggedIn
      ? <GoogleLogout
      clientId="993957174043-aoaec0k30nh2vkk2u7sl1101im82kakt.apps.googleusercontent.com"
      buttonText="Logout"
      onLogoutSuccess={logout}>
      </GoogleLogout>
      : <div></div>;

    const displayLoginButton = !this.state.loggedIn 
    ? <GoogleLogin
    clientId="993957174043-aoaec0k30nh2vkk2u7sl1101im82kakt.apps.googleusercontent.com"
    buttonText="Login"
    onSuccess={responseGoogle}
    onFailure={failure}
    cookiePolicy={'single_host_origin'}
    isSignedIn={true}
  /> : <div></div>;
    const isLoading = this.state.loading;



    return (
      <div className="profile-page">
        <div className="login-center">
          {displayLoginButton}
          {loggedIn}
          {displayLogoutButton}
        </div>
        
        {this.displayEmptyLines()}
      </div>
    )
  }
}

export default ProfilePage;