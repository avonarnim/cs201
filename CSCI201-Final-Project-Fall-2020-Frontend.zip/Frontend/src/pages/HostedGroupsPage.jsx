import React, { Component } from "react";
import Modal from 'react-modal';
import PropTypes from "prop-types";

import OrderNote from "../components/OrderNote.jsx";
import OrderDetails from "../components/OrderDetails.jsx";
import CreateGroup from "../components/CreateGroup.jsx"
import HostedOrderModal from "../components/HostedOrderModal.jsx";
import HostedGroupNote from "../components/HostedGroupNote.jsx";
import { GoogleLogin, GoogleLogout } from 'react-google-login';



import "../styles/orders.scss";


class HostedGroupsPage extends Component {
    //   static propTypes = {
    //     // make prop for function that populates div, passed in by main
    //     buttonLabels: PropTypes.arrayOf(PropTypes.string).isRequired,
    //     active: PropTypes.string.isRequired,
    //     onClick: PropTypes.func.isRequired,
    //   };

    constructor(props) {
        super(props);
        // this.state = { active: props.active };
        this.state = {
            showCreateModal: false,
            showHostedOrderModal: false,
            activeOrder: -1,
            isLoaded: false,
            groups: [],
            nextId: 6,
            loggedIn: false,
            currentUserId: null,
            name: null,
            email: null,
            activeGroup: -1,
        };

        this.handleCloseCreateModal = this.handleCloseCreateModal.bind(this);
        this.handleOpenCreateModal = this.handleOpenCreateModal.bind(this);
        this.handleCreateNewGroup = this.handleCreateNewGroup.bind(this);
        this.handleCloseHostedOrderModal = this.handleCloseHostedOrderModal.bind(this);
        this.handleOpenHostedOrderModal = this.handleOpenHostedOrderModal.bind(this);
        this.setLoginValues = this.setLoginValues.bind(this);
        this.getCurrentUser = this.getCurrentUser.bind(this);
        this.handleUpdateStatusRequest = this.handleUpdateStatusRequest.bind(this);
        this.handlePaidForOrder = this.handlePaidForOrder.bind(this);
    }

    async componentDidMount() {

        // const listIdResponse = await fetch(`http://localhost:8080/setSavedList?userId=123&listName=myList`,
        //     {
        //         method: "POST",
        //         headers: {
        //             'Content-Type': 'application/json'
        //         },
        //         body: JSON.stringify(items)
        //     });
        // const listId = await listIdResponse.text();

        // const { orderId } = this.props;
        // let fakeItems = [
        //     { name: "item1", quantity: 1, price: 1.5 },
        //     { name: "item2", quantity: 2, price: null },
        //     { name: "item3", quantity: 2, price: 4 },
        // ];
        // const fakeOrderInfo = { status: "completed", pickupLocation: "USC", host: "hostname", items: fakeItems }
        // const fakeOrderInfo2 = { status: "inprogress", pickupLocation: "USC", host: "hostname", items: fakeItems }
        // const fakeOrdersList = [
        //     { ...fakeOrderInfo2, id: 1 },
        //     { ...fakeOrderInfo, id: 2 },
        //     { ...fakeOrderInfo, id: 3 },
        //     { ...fakeOrderInfo, id: 4 },
        //     { ...fakeOrderInfo, id: 5 }
        // ]
        // this.setState({ orders: fakeOrdersList, isLoaded: true });
        // Add in backend:
        // const response = await fetch('/api/orders/' + orderId);
        // const body = await response.json();
        // this.setState({ orderInfo: body, isLoaded: true });
        this.setState({ isLoaded: true });

    }

    handleCloseCreateModal() {
        this.setState({ showCreateModal: false });
        // update backend if need to update anything
    }

    handleOpenCreateModal() {
        this.setState({ showCreateModal: true });
    }

    handleCloseHostedOrderModal() {
        this.setState({ showHostedOrderModal: false, activeGroup: -1 });
        // update backend if need to update anything
    }

    handleOpenHostedOrderModal(id) {
        this.setState({ showHostedOrderModal: true, activeGroup: id });
    }

    async handleCreateNewGroup(groupName, isPublic, description, pickUpLocation, pickUpTime, items, listName, store) {
        let { currentUserId } = this.state;
        this.handleCloseCreateModal();
        const listIdResponse = await fetch(`http://localhost:8080/setSavedList?userId=${currentUserId}&listName=${listName}`,
            {
                method: "POST",
                // credentials: 'include',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(items)
            });
        const listId = await listIdResponse.text();
        await fetch(`http://localhost:8080/insert-new-order-group?name=${groupName}&description=${description}&location=${pickUpLocation}&store=${store}&orderTime=${pickUpTime}&savedList=${listId}&public=${isPublic}&hostId=${currentUserId}`);
        const response = await fetch(`http://localhost:8080/current-hosted-groups?userId=${currentUserId}`);
        const groups = await response.json();
        this.setState({ groups: groups });
    }

    handleCancelOrder = async (id) => {
        alert("Order #" + id + " canceled");
        this.setState({ showInfoModal: false });
        // pseudo removal, replace w backend deletion
        let { orders } = this.state;
        orders.splice(orders.findIndex((order) => order.id === id), 1);
        this.setState({ orders: orders });
        // await this.props.dispatch(editAdmin(id, newprofile));
        // await this.props.dispatch(getAdmins());
    };

    populateOrderNotes = (groups) => {
        const ids = [];
        const orderNotes = groups.map((group) => {
            if (!ids.includes(group.groupId)) {
                ids.push(group.groupId);
                return (<HostedGroupNote group={group} onClick={(e) => {
                    this.handleOpenHostedOrderModal(group.groupId);
                }} />)
            }
        }
        );
        return orderNotes;
    }

    handleRejectOrder(order) {
        console.log("order rejected");
    }

    async handleAcceptOrder(order) {
        await fetch(`http://localhost:8080/update-approval?orderId=${order.id}&approval=true`,
            { method: "POST" })
    }

    async handleUpdateStatusRequest(groupId, status) {
        const { currentUserId } = this.state;
        await fetch(`http://localhost:8080/update-group-status?groupId=${groupId}&newStatus=${status}`);
        const response = await fetch(`http://localhost:8080/current-hosted-groups?userId=${currentUserId}`);
        const groups = await response.json();
        this.setState({ groups: groups });
    }

    async handlePaidForOrder(order) {
        const { currentUserId } = this.state;
        await fetch(`http://localhost:8080/update-paid-for?orderId=${order.id}&paid=true`,
            { method: "POST" });
        const response = await fetch(`http://localhost:8080/current-hosted-groups?userId=${currentUserId}`);
        const groups = await response.json();
        this.setState({ groups: groups });
    }

    setLoginValues(response) {
        console.log(response.profileObj.name);
        console.log(response.profileObj.email);
        console.log(response.profileObj.googleId);
        this.setState({
            loggedIn: true,
            name: response.profileObj.name,
            email: response.profileObj.email,
            currentUserId: response.profileObj.googleId
        });
    }

    logout() {
        this.setState({
            loggedIn: false,
            name: '',
            email: ''
        });
    }

    async getCurrentUser() {
        const { email, name, currentUserId } = this.state;

        // await fetch(`http://localhost:8080/storeNewUser?userId=${currentUserId}&name=${name}&email=${email}`);
        const response = await fetch("http://localhost:8080/user-name?userId=" + currentUserId);
        try {
            const body = await response.text();
            console.log(body);
            if (!body) {
                console.log("body null");
                throw "error";
            }
        } catch (err) {
            // if no id found, need to create user
            await fetch(`http://localhost:8080/storeNewUser?userId=${currentUserId}&name=${name}&email=${email}`)
            const newResponse = await fetch("http://localhost:8080/user-name?userId=" + currentUserId);
            const body = await newResponse.text();
        }

        const groupsResponse = await fetch(`http://localhost:8080/current-hosted-groups?userId=${currentUserId}`)
        const groups = await groupsResponse.json();
        this.setState({ groups: groups });
        console.log(JSON.stringify(groups));
    }

    render() {

        const responseGoogle = (response) => {
            this.setLoginValues(response);
            this.getCurrentUser();
        }
        const failure = (error) => {
            console.log(error);
            this.logout();
        }


        const { activeGroup, orders, groups } = this.state;
        return (
            <div className='orderspage' >

                <div className='orders-page-header'>
                    Your Hosted Groups
                </div>
                <div className='notes-div'>
                    <div className='new-order-text'
                        onClick={(e) => {
                            this.handleOpenCreateModal();
                        }}>
                        Create New Group
                        <div className='new-order-btn'>
                            +
                        </div>
                    </div>
                    {this.populateOrderNotes(groups)}


                    <Modal
                        isOpen={this.state.showHostedOrderModal}
                        // isOpen={true}
                        contentLabel="Minimal Modal Example"
                        ariaHideApp={false}
                        className="hosted-order-modal"
                        onRequestClose={this.handleCloseHostedOrderModal}
                    >
                        <HostedOrderModal
                            groupId={activeGroup}
                            handleCloseModal={this.handleCloseHostedOrderModal}
                            handleUpdateGroup={this.handleSubmitNewOrder}
                            handleRejectOrder={this.handleRejectOrder}
                            handleAcceptOrder={this.handleAcceptOrder}
                            handleUpdateStatusRequest={this.handleUpdateStatusRequest}
                            handlePaidForOrder={this.handlePaidForOrder}

                        />
                    </Modal>

                    <Modal
                        isOpen={this.state.showCreateModal}
                        contentLabel="Minimal Modal Example"
                        ariaHideApp={false}
                        className="create-group-modal"
                        onRequestClose={this.handleCloseCreateModal}
                    >
                        <CreateGroup
                            handleCloseModal={this.handleCloseCreateModal}
                            handleSubmitNewOrder={this.handleSubmitNewOrder}
                            handleCreateNewGroup={this.handleCreateNewGroup}

                        />
                    </Modal>

                </div>
                <GoogleLogin
                    clientId="993957174043-aoaec0k30nh2vkk2u7sl1101im82kakt.apps.googleusercontent.com"
                    buttonText="Login"
                    onSuccess={responseGoogle}
                    onFailure={failure}
                    cookiePolicy={'single_host_origin'}
                    isSignedIn={true}
                    disabled={true}
                    className="invisible"
                />
                <div style={{ display: "none" }}>Adhesive tape piece by Juan Pablo Bravo from the Noun Project</div>
            </div >
        );
    }
}

export default HostedGroupsPage;