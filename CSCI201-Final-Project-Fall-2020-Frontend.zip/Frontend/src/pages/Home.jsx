import React, { Component, useState } from "react";
import "../styles/home.scss";
import 'bootstrap/dist/css/bootstrap.css';
import Modal from "react-modal"
import { FormControl, Form,  Button, Col, Row, Alert, Popover, OverlayTrigger} from 'react-bootstrap';
import {GoogleLogin} from 'react-google-login';
import fd from "../resources/food-delivery.jpg";
import axios from "axios"
import { Typeahead } from 'react-bootstrap-typeahead';
var qs = require('qs');
class Home extends Component {
    static propTypes = {
        // make prop for function that populates div, passed in by main
        // buttonLabels: PropTypes.arrayOf(PropTypes.string).isRequired,
        // active: PropTypes.string.isRequired,
        // onClick: PropTypes.func.isRequired,
    };

    constructor(props) {
        super(props);
        this.state = {
            active: 'Home',
            showModal: false,
            loggedIn: false,
            loading: false,
            error: null,
            recoverPasswordSuccess: null,
            orders: [],
            searchResults: [],
            name:'',
            email:'',
            googleId:'',
            searchResultPrivate:'',
            searchResultPublic:'',
            currentModal: '',
            orderName:'',
            orderPrice:'',
            orderAmt:'',
            balanceResponse:[],
            balanceIdResponse:[],
            currentOrdersResponse:[],
            currentJoinedGroupsResponse:[],
            currentHostedGroupsResponse:[],
            currentOrdersTotalResponse:0,
            suggestions:[],
            inventory:[],
            checkedOrders:false,
            checkedBalances:false,
            checkedGroups:false
          };
          this.public = React.createRef();
          this.groupName = React.createRef();
          this.storeName = React.createRef();
          this.pol = React.createRef();
          this.description=React.createRef();
          this.ordertime = React.createRef();
          this.orderlistname = React.createRef();
          this.createInfoPanels = this.createInfoPanels.bind(this)
        
    }
    
    onClick = (newActive) => {
        console.log(newActive);
        this.setState({
            active: newActive,
        });
    };



    openModal(modal){
        
        this.setState({
            showModal: true,
        });
        this.currentModal = modal;
        
      }
    
    
    startLoading() {
    this.setState({
        loading: true
    })
    }
    
    finishLoading() {
    this.setState({
        loading: false
    })
    }
    
    
    closeModal(){
    this.setState({
        showModal: false,
        error: null,
        orders: []
    });
    }
    setSearchResultPublic(searchResult){
        this.setState({
            searchResultPublic : searchResult
        });
        
    }
    setSearchResultPrivate(searchResult){
        this.setState({
            searchResultPrivate : searchResult
        });
    }
    setOrderName(name){
        this.setState({
            orderName : name
        });
    }
    setOrderPrice(name){
        this.setState({
            orderPrice : name
        });
    }
    setOrderAmt(name){
        this.setState({
            orderAmt : name
        });
    }

    getSearchResults(bool){
        //CALL TO DB
        var sr = [];
        if (bool){
            // Private group search
            console.log(this.state.searchResultPrivate);
            if (this.state.searchResultPrivate.trim()!=""){
                sr = [
                    {
                        id: 1234,
                        name: 'Shopping Private',
                        isPrivate: true,
                        plannedStore: 'Wallmart',
                        pickUpLocation: 'Honda Center',
                        status: 'Single',
                        scheduledTime: '10:15',
                        hostId: 1
                    },
                    {
                        id: null,
                        name: '',
                        isPrivate: false,
                        plannedStore: '',
                        pickUpLocation: '',
                        status: '',
                        scheduledTime: '',
                        hostId: ''
                    }
                ];
            }
            
        }else{
            console.log(this.state.searchResultPublic);
            if (this.state.searchResultPrivate.trim()!=""){
                sr = [
                    {
                        id: 1234,
                        name: 'Shopping Public',
                        isPrivate: false,
                        plannedStore: 'Target',
                        pickUpLocation: 'Honda Center',
                        status: 'Single',
                        scheduledTime: '10:15',
                        hostId: 1
                    },
                    {
                        id: null,
                        name: '',
                        isPrivate: false,
                        plannedStore: '',
                        pickUpLocation: '',
                        status: '',
                        scheduledTime: '',
                        hostId: ''
                    }
                ];
            }
            
        }
        
        this.setState({
            searchResults: sr
        });
    }

    responseGoogle = (response) => {
        // this.setLoginValues(response);
        // console.log(response);
        this.setState({
            loggedIn:true
        });
      }
    sendGroupRequest(groupId){
        console.log(groupId);
    }

    displaySearchResults(){
        const requestJoin = this.state.loggedIn 
        ? <Button variant="success" onClick={e => this.sendGroupRequest(e.currentTarget.parentNode.getAttribute("id"))}> Request to Join</Button>
        : <GoogleLogin
        clientId="993957174043-aoaec0k30nh2vkk2u7sl1101im82kakt.apps.googleusercontent.com"
        buttonText="Login"
        onSuccess={this.responseGoogle}
        cookiePolicy={'single_host_origin'}
        icon={false}
        />
        
        return(
            <div className='search-results-container'>
            {
                this.state.searchResults.map((group, index) => (
                    <div key={group.id} className='search-results-div'>
                        <Form >
                            <Form.Group as={Row}>
                                <Form.Label column sm={1}/>
                                <Form.Label column sm={3}>
                                    {group.name}
                                </Form.Label>
                                <Form.Label column sm={3}>
                                    Time: {group.scheduledTime}
                                </Form.Label>
                                <Form.Label column sm={2}>
                                    {group.plannedStore}
                                </Form.Label>
                                <Col sm={1}>
                                    <div id={group.id}>
                                        {requestJoin}
                                    </div>
                                    
                                </Col>
                            </Form.Group>
                        </Form>
                    </div>
                ))
                }
            </div>
        );
    }
    createBalanceTable(){
        if (Object.keys(this.state.balanceIdResponse).length== 0){
            return (<div></div>);
        }else{
            return(
                <div>
                    <div className="balances">
                        <div className="balance-panels" id="balance-panels-name">
                            <p>Friend</p>
                        </div>
                        <div className="balance-panels" id="balance-panels-owe">
                            <p>Net Owe</p>
                        </div>
                    </div>
                    {
                        this.state.balanceIdResponse.map((user, index) => (
                            <div className="balances" key={index}>
                                <div className="balance-panels" id="balance-panels-name">
                                    <p>{user.name}</p>
                                </div>
                                <div className="balance-panels" id="balance-panels-owe">
                                    <p>{user.owe}</p>
                                </div>
                            </div>
                        ))
                    }
                    
                </div>
                
            );
        }
    }
    addUserToBalance(data, value){
        var dict = this.state.balanceIdResponse;
        dict.push({
            name:data,
            owe:value
        });
        this.setState({
            balanceIdResponse: dict
        });

    }
    updateBalancedIdResponse(data){
        this.setState({
            checkedBalances:true
         })
        // console.log(data);
        var dict = [];
        Object.entries(data).map(([key, value]) =>{
            axios.get("http://localhost:8080/user-name", 
                { 
                params:{
                    userId: key
                }
                }).then((response) => response.data)
                .then((data) =>
                    this.addUserToBalance(data, value)
                )
                .catch(error=>console.log(error));
        });
        // console.log(this.state.balanceIdResponse);
    }

    createBalancesModal(){
        if (Object.keys(this.state.balanceIdResponse).length== 0){
            
            
        }

        return(
            <div>
                <div>
                    <h2>Balances</h2>
                </div>
                <div className="balances-net">
                {
                    this.state.balanceResponse.map((item, index)=>
                    
                    <div key={index}>
                        <div><span>Total: ${item.Total}</span></div>
                        <br/>
                    </div>)
                }
                    

                </div>
                {this.createBalanceTable()}
                
                
            </div>
            
        );
    }

    createCurrentOrdersModal(){
        return(
            <div className="current-orders-modal">
                <h2>Current Orders</h2>
                <div className="orders-format">
                            <div className="orders-format-info">
                                Item Name
                            </div>
                            <div className="orders-format-info">
                                Order Quantity
                            </div>
                            <br></br>
                        </div>
                <div>
                    {
                        this.state.currentOrdersResponse.map((item, index)=>
                        

                        <div key={index} className="orders-format">
                            <div className="orders-format-info">
                                {item.name}
                            </div>
                            <div className="orders-format-info">
                                {item.quantity}
                            </div>
                            <br></br>
                        </div>)
                    }
                    <br></br>
                    <p>Total Cost:  {this.state.currentOrdersTotalResponse}</p>
                   
                </div>
            </div>
        );
    }
    createCurrentGroupsModal(){
        return(
            <div>
                <h2>Current Groups</h2>
                <div className="group-container">
                    <div className="group-container-column">
                        <div><strong>Hosted</strong></div>
                        <div>
                        {
                        this.state.currentHostedGroupsResponse.map((item, index)=>
    
                        <div key={index}>
                            <p>{item}</p>
                        </div>
                        )}
                        </div>
                    </div>
                    
                    <div className="group-container-column">
                        <div><strong>Joined</strong></div>
                        <div>
                        {
                        this.state.currentJoinedGroupsResponse.map((item, index)=>
    
                        <div key={index}>
                            <p>{item}</p>
                        </div>
                        )
                        }
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    addToJoinedGroups(data){
        this.setState({
            checkedGroups:true
        })
        var temp = [];
        Object.entries(data).map(([key, value]) =>{
            temp.push(value.groupName)
        });
        //console.log(temp);
        this.setState(
            {
                currentJoinedGroupsResponse: temp
            }
        );
    }
    addToHostedGroups(data){
        this.setState({
            checkedGroups:true
        })
        var temp = [];
        Object.entries(data).map(([key, value]) =>{
            temp.push(value.groupName);
        });
        this.setState({currentHostedGroupsResponse: temp});
        //console.log(this.state.currentHostedGroupsResponse);

    }
    updateOrdersResponse(data){
        this.setState({
            checkedOrders:true
        })
        if (data!=null && data.length>0){
            this.setState({
                currentOrdersResponse: data[0].orders,
                currentOrdersTotalResponse:data[0].estimatedCost
            })
        }
    }
    updateBalanceResponse(data){
        this.setState({
            checkedBalances:true
        })
        if (data!=null){
            this.setState({
                balanceResponse:[data]
            })
            
        }
    }
    createInfoPanels(){
        if (this.state.loggedIn){
           

            const totalGroups = this.state.currentHostedGroupsResponse.length + this.state.currentJoinedGroupsResponse.length;
            
            return(
                <div id="info-panel-signed-in">
                    <div className="info-panels" onClick={e => this.openModal("groups")}>
                        <p className="info-panels-title">Current Groups</p>
                        <br></br>
                        <p className="current-panels">You are a part of {totalGroups} group(s).</p>
                    </div>
                    <div className="info-panels" onClick={e => this.openModal("orders")}>
                        <p className="info-panels-title">Current Orders</p>
                        <br></br>
                        <p className="current-panels">You have {this.state.currentOrdersResponse.length} orders.</p>
                    </div>
                    <div className="info-panels" onClick={e => this.openModal("balances")}>
                        <p className="info-panels-title" >Balances</p>
                        {
                            this.state.balanceResponse.map((item, index)=>
                            
                            <div key={index}>
                                <div><span>Owed</span><span className="info-panels-balances-amt">${item.Owed}</span></div>
                                <br/>
                                <div><span>Owe</span><span className="info-panels-balances-amt">${item.Owe}</span></div>
                                <br/>
                                <div><span>Total</span><span className="info-panels-balances-amt">${item.Total}</span></div>
                                <br/>
                            </div>)
                        }
                    </div>
                </div>
            );
        }
        return <div></div>;
    }

    createNewOrder(n, a){
        var new_orders = this.state.orders;
        new_orders.push({
            name: n,
            quantity:a
        });
        this.setState({
            orders: new_orders
        })
        
        
    }
    async addOrderToDB(){
        const oln= this.orderlistname.current.value;
        console.log(oln);
        var temp = [];
        Object.entries(this.state.orders).map(([key, value]) =>{
            temp.push({
                name:value.name[0],
                quantity:value.quantity
            });
        });
        console.log(temp);
        const listname = oln.trim().split(' ').join('%20');
        const url = "http://localhost:8080/setSavedList?userId=" + this.state.googleId + "&listName=" + listname;
        const listIdResponse = await fetch(url, {
            method: "POST",
            headers:{
                'Content-Type' : 'application/json'
            },
            body: JSON.stringify(temp)
        })
        const listId = await listIdResponse.text();
        console.log(listId);
        const groupName = this.groupName.current.value.trim();
        const description =this.description.current.value.trim();
        const pickUpLocation = this.pol.current.value.trim();
        const store = this.storeName.current.value.trim();
        const pickUpTime = this.ordertime.current.value.trim();
        const isPublic = this.public.current.checked;
        await fetch(`http://localhost:8080/insert-new-order-group?name=${groupName}&description=${description}&location=${pickUpLocation}&store=${store}&orderTime=${pickUpTime}&savedList=${listId}&public=${isPublic}&hostId=${this.state.googleId}`);


    }
    async createNewGroup(){
        if (this.state.orders.length!=0){
            const listId = this.addOrderToDB();
            
        }
        
        
    }

    getItemPrice(name){
        var price = 0;
        Object.entries(this.state.inventory).map(([key, value]) =>{
            if (value.name==name){
                price = value.price;
            }
        });
        return price;
    }

    setUpInventory(data){
        var temp = [];
        var temp2= [];
        Object.entries(data).map(([key, value]) =>{
            temp.push({
                name:value.name,
                price:value.price
            })
        });
        this.setState({
            inventory:temp
        });
        Object.entries(data).map(([key, value]) =>{
            temp2.push(value.name)
        });
        this.setState({
            suggestions:temp2
        });
        console.log(this.state.suggestions);
    }
    componentDidMount(){
        axios.get("http://localhost:8080/inventory")
        .then((response) => this.setUpInventory(response.data))
        .catch(error=>console.log(error));
        this.setState({
            checkedOrders:false,
            checkedBalances:false,
            checkedGroups:false
        })

    }

    createGroup(){
        if(this.state.loggedIn){
            const { activeOrder, orders } = this.state;
              
            return(
                <div>
                    <Form >
                    <Form.Group as={Row}>
                            <Form.Label column sm={3}>
                            </Form.Label>
                            <Col sm={8}>
                                <Form.Check
                                type="radio"
                                label="Private"
                                name="formHorizontalRadios"
                                id="private-radio"
                                />
                                <Form.Check
                                type="radio"
                                label="Public"
                                name="formHorizontalRadios"
                                id="public-radio"
                                required
                                ref={this.public}
                                />
                            </Col>
                        </Form.Group>
                        <fieldset></fieldset>
                        <Form.Group as={Row}>
                            <Form.Label column sm={3}>
                            Group Name
                            </Form.Label>
                            <Col sm={8}>
                            <Form.Control className="inlineFormInputName2" placeholder="Group" id="group-name" required ref={this.groupName}/>
                            </Col>
                        </Form.Group>
                        <fieldset></fieldset>
                        
                        <Form.Group as={Row} >
                            <Form.Label column sm={3}>
                            Store Name
                            </Form.Label>
                            <Col sm={8}>
                            <Form.Control className="inlineFormInputName2" placeholder="Store" id="store-name" required ref={this.storeName}/>
                            </Col>
                        </Form.Group>
                        <fieldset></fieldset>
                        <Form.Group as={Row} >
                            <Form.Label column sm={3}>
                            Location
                            </Form.Label>
                            <Col sm={8}>
                            <Form.Control className="inlineFormInputName2" placeholder="Pick up Location" id="pol-name" required ref={this.pol}/>
                            </Col>
                        </Form.Group>
                        <fieldset></fieldset>
                        <Form.Group as={Row}>
                            <Form.Label column sm={3}>
                            Description
                            </Form.Label>
                            <Col sm={8}>
                            <Form.Control className="inlineFormInputName2" placeholder="Order Group Description" id="desc" required ref={this.description}/>
                            </Col>
                        </Form.Group>
                        <Form.Group as={Row}>
                            <Form.Label column sm={3}>
                            Order Time
                            </Form.Label>
                            <Col sm={8}>
                            <Form.Control className="inlineFormInputName2" placeholder="Order Time, i.e 11:30P.M, on Tuesday.." id="ot" required ref={this.ordertime}/>
                            </Col>
                        </Form.Group>
                        <fieldset></fieldset>
                        <div className="create-group-order-list">
                        <Typeahead
                            placeholder={"Item to add"}
                            onChange={(selected) => {
                                this.setState({orderName:selected})
                            }}
                            options={this.state.suggestions}
                            id="typeahead"
                            />
                            <FormControl id="create-group-order-price" placeholder="Price" value={this.getItemPrice(this.state.orderName)}/>
                            <FormControl id="create-group-order-amt" placeholder="Amt" onChange={e=>this.setOrderAmt(e.target.value)}/> 
                            <Button id="create-group-order-button" variant="outline-secondary" onClick={e=>this.createNewOrder(this.state.orderName, this.state.orderAmt)}>Add Order</Button>
                        </div>
                        <Form.Text className="text-muted">
                            Must include at least 1 order
                        </Form.Text>
                        <div className="order-list-new">
                                {
                                this.state.orders.map((order, index) => (
                                    <div key={index}>
                                        <p >{order.quantity}x {order.name}, ${this.getItemPrice(order.name)} each </p>
                                    </div>
                                ))
                                }
                        </div>
                        <Form.Group as={Row}>
                            <Form.Label column sm={3}>
                            List Name
                            </Form.Label>
                            <Col sm={8}>
                            <Form.Control className="inlineFormInputName2" placeholder="Name of list of orders from above" id="list-name" required ref={this.orderlistname}/>
                            </Col>
                        </Form.Group>
                        <fieldset></fieldset>
                        
                        

                        <Form.Group as={Row}>
                            <Col sm={{ span: 10, offset: 2 }}>
                                <Button variant="success" onClick={e=>this.createNewGroup()} >Create Group</Button>
                            </Col>
                        </Form.Group>
                    </Form>
                </div>
            );
        }
    }

    displayCreateButton(){
        if (this.state.loggedIn){
            return (
                <div id="create-group-button">
                    <Button variant="success" onClick={e => this.openModal("create")}>Create Group</Button>
                </div>
            );
        }
    }

    displayNewUserInfo(){
        return(
            <div>
                <h2>
                    Learn about our Posty
                </h2>
                <div className="new-user-info">
                    Mission Statement:
                    <br></br>
                    <br></br>
                    The idea behind Posty comes from a gap in the current providers of delivered groceries. There was an inability to create group orders. As a result, any group of people in close proximity have to place separate orders for a common food supply. This represents an inconvenience for consumers and places extra financial burden on users. Especially considering that the COVID-19 pandemic is at its highest in the U.S., it is encouraged to limit unnecessary interactions and provide a safe service for grocery shopping communication.
                </div>
                <div className="new-user-info">
                    What's next?
                    <br></br>
                    <br></br>
                    The hope is for Posty to expand into restaurants and the delivery system. We wish to allow event organizers to coordinate large catering orders and families to figure out dining plans together.
                    <br></br>
                    <div id="fd-div">
                        <img src={fd} id="fd"/> 
                    </div>       
                </div>
            </div>
        )
    }

    setLoginValues(response){
        console.log(response.profileObj.name);
        console.log(response.profileObj.email);
        console.log(response.profileObj.googleId);
        this.setState({
          loggedIn: true,
          name: response.profileObj.name,
          email: response.profileObj.email,
          googleId:response.profileObj.googleId
        });
      }

    logout(){
    this.setState({
        loggedIn: false,
        name: '',
        email: '',
        balanceResponse:[],
        currentOrdersResponse:[],
        currentOrdersTotalResponse:0
    });
    }

    displayEmptyLines(){
        return(
            <div>
                <br/><br/><br/><br/><br/><br/><br/><br/>
                <br/><br/><br/><br/><br/><br/><br/><br/>
            </div>
        );
    }

    displayUserHelpInfo(){
        return (
            <div>
                <Alert variant={'success'}>
                    <Alert.Heading>What am I looking at?</Alert.Heading>
                    Given above is a summary of your most recent orders and current balances. Click on the panels to expand the information. Empty panels only mean that you have yet to begin transactions. To get started, go to the hosted groups tab at the top right to create a group. To join a group, go to the orders tab and create a new order for a specified group.
                </Alert>
                <br></br>
                <Alert variant={'success'}>
                    <Alert.Heading>Managing all the groups I am a part of</Alert.Heading>
                        To look at the groups you are a host in, go the the hosted groups tab. As the host, you have permissions to allow or deny certain order requests from other users.
                </Alert>
                <br></br>
                <Alert variant={'success'}>
                    <Alert.Heading>Creating Orders</Alert.Heading>
                    Once you join a group after searching under the orders tab, you are able to submit orders. Keep in mind that the host of the group is the only one who can directly add to the list. Other non-hosts must submit an order request that the host can either approve or refuse.
                </Alert>
            </div>
              
          );
    }


    render() {
        const responseGoogle = async (response) => {
            this.setLoginValues(response);
            const br = await fetch(`http://localhost:8080/balances-summary?userId=${this.state.googleId}`);
            const br_resp = await br.json();
            // console.log(br_resp);
            this.updateBalanceResponse(br_resp);

            const or = await fetch(`http://localhost:8080/user-current-orders?userId=${this.state.googleId}`);
            const or_resp = await or.json();
            // console.log(or_resp);
            this.updateOrdersResponse(or_resp);

            const jgr = await fetch(`http://localhost:8080/current-joined-groups?userId=${this.state.googleId}`);
            const hgr = await fetch(`http://localhost:8080/current-hosted-groups?userId=${this.state.googleId}`);
            const jgr_data = await jgr.json();
            const hgr_data = await hgr.json();
            if (jgr_data.length!=0){
                this.addToJoinedGroups(jgr_data);
            }
            if (hgr_data.length!=0){
                this.addToJoinedGroups(hgr_data);
            }
            const ab = await fetch(`http://localhost:8080/all-balances?userId=${this.state.googleId}`);
            const ab_resp = await ab.json();
            if (ab_resp.length!=0){
                this.updateBalancedIdResponse(ab_resp);
            }
            
          }
          const failure = (error) =>{
            console.log(error);
            this.logout();
          }
        
        const loggedIn = this.state.loggedIn
        ? <div>
            <p>You are signed in with: {this.state.loggedIn}</p>
            </div>
        : <div>
            <p>You are signed out</p>
        </div>;

        const newUserInfo = !this.state.loggedIn
        ?  this.displayNewUserInfo()
        :  this.displayEmptyLines()

        var modalInfo,infoPanels = <div></div>;

        const userHelpInfo = !this.state.loggedIn
        ? <div></div>
        : this.displayUserHelpInfo();

        // Also need to check if value in searchbar
        if(this.currentModal=="balances"){
            modalInfo = this.createBalancesModal();
        }else if(this.currentModal=="groups"){
            modalInfo = this.createCurrentGroupsModal();
        }else if(this.currentModal=="orders"){
            modalInfo = this.createCurrentOrdersModal();
        }else if (this.currentModal=="create"){
            modalInfo = this.createGroup();
        }
        //InfoPanels depending on if user is logged in
        if (!this.state.loggedIn){
            infoPanels = <div id ="info-panel-signed-out">
                            Sign in to begin making orders with your friends!
                        </div>
        }else{
            infoPanels = this.createInfoPanels();
        }
        

        return (


            <div className='home'>
                <div className='home-welcome'>
                    Hi! Welcome to Posty!
                </div>
                <div className='info-wrapper'>
                    <div className='info-container'>
                        {infoPanels}
                        
                        <Modal
                        isOpen={this.state.showModal}
                        contentLabel="Info Panel"
                        ariaHideApp={false}
                        className="modal-main"
                        disableAutoFocus={true}
                        
                        >
                            <div>
                                <button onClick={e => this.closeModal()} id="modal-close-button">
                                    Close
                                </button>
                                {modalInfo}
                            </div>
                        </Modal>
                        
                        {/* {this.displayCreateButton()} */}
                        <br></br>
                        {userHelpInfo}

                        <GoogleLogin
                        clientId="993957174043-aoaec0k30nh2vkk2u7sl1101im82kakt.apps.googleusercontent.com"
                        buttonText="Login"
                        onSuccess={responseGoogle}
                        onFailure={failure}
                        cookiePolicy={'single_host_origin'}
                        isSignedIn={true}
                        disabled={true}
                        className="invisible"
                        />

                        {newUserInfo}

                        

                    </div>
                </div>
                

            </div>
        );
    }
}

export default Home;