import logo from './logo.svg';
import './App.css';
import Main from "./components/Main.jsx";
import NavBar from "./components/NavBar.jsx";
import { Link } from "react-router-dom";
import React, { Component } from "react";
import PropTypes from "prop-types";


class App extends Component {

  render() {

    return (
      <div>
        <NavBar />
        <Main />
      </div>

    );
  }
}


export default App;
