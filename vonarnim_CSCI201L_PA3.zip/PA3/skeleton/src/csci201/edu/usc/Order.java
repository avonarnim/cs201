package csci201.edu.usc;

public class Order extends Thread {

	public int time;
	private String location;
	private String title;
	public Restaurant rest;
	private long sleepTime;

	public Order(int readyTime, String loc, String item, Restaurant restaurant) {
		this.time = readyTime;
		this.location = loc;
		this.title = item;
		this.rest = restaurant;
	}

	public String toString() {
		return title + "\n";
	}

	public void startingDelivery() {
		System.out.print("[" + Util.getTimestampDiff() + "]");
		System.out.println(" Starting delivery of " + title + " from " + location + "!");
	}

	public void finishingDelivery() {

		System.out.print("[" + Util.getTimestampDiff() + "]");
		System.out.println(" Finishing delivery of " + title + " from " + location + "!");
	}
	
	public void setDriveTime(double distance) {
		
		sleepTime = 1000*(Double.valueOf(2*distance)).longValue();
	}

	public void run() {
		
		try {
			Thread.sleep(time*1000);
			rest.sems.acquire();
			startingDelivery();
			Thread.sleep(2*sleepTime);
			finishingDelivery();
			rest.sems.release();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
