package csci201.edu.usc;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class Util {
    private static final long startTime = System.currentTimeMillis();

    public static String getTimestamp() {
    	return new SimpleDateFormat("HH:mm:ss.SS").format(new Date()).substring(0, 11);
    }

    public static String getTimestampDiff() {
        long duration = System.currentTimeMillis() - startTime;
        String base = new SimpleDateFormat("HH:mm:ss.SS").format(duration).substring(0, 11);
        base = "00" + base.substring(2);
        return base;
    }
}