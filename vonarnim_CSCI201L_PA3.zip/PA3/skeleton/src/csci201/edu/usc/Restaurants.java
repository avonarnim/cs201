package csci201.edu.usc;

import java.io.IOException;
import java.util.ArrayList;
import com.google.gson.annotations.SerializedName;

public class Restaurants {
	@SerializedName("data")
	public ArrayList<RestaurantWrapper> restWrapper;	
	
	public Restaurants() throws IOException {
		restWrapper = new ArrayList<RestaurantWrapper>();
	}

}