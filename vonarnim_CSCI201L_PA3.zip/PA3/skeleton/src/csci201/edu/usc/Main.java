package csci201.edu.usc;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.google.gson.Gson;

public class Main {
		
	public static ArrayList<String> getOrders() throws IOException {

		ArrayList<String> orders = new ArrayList<String>();
		
		Scanner sc = new Scanner(System.in);
		try {
			System.out.print("\nWhat is the name of the file containing the schedule information? ");
			String filename = sc.nextLine();
			BufferedReader reader;
			try {
				reader = new BufferedReader(new FileReader(filename));
				String line = reader.readLine();
				while (line != null) {
					orders.add(line);
					line = reader.readLine();
				}
				reader.close();
			} catch (IOException e) {
				throw e;
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
			throw e;
		}
		return orders;
	}
	
	@SuppressWarnings("all")
	public static Restaurants getRestaurants() throws IOException {
		Restaurants rests = null;
		Scanner sc = new Scanner(System.in);
		
		try {
			System.out.print("What is the name of the file containing the restaurants? ");
			String filename = sc.next();
			
			Gson gson = new Gson();
			Reader reader = new FileReader(filename);
			rests = gson.fromJson(reader,  Restaurants.class);

		} catch (IOException e) {
			System.out.println("=== Data not accepted ===");
			e.getStackTrace();
		}

		return rests;
	}
	
	public static void main(String[] args) {
		
		Restaurants rests;
		try {
			rests = getRestaurants();
		} catch (IOException e) {
			System.out.println("=== Data not accepted ===");
			return;
		}

		ArrayList<String> schedule;
		try {
			schedule = getOrders();
		} catch (IOException e) {
			System.out.println("=== Data not accepted ===");
			return;
		}
		
		Scanner sc = new Scanner(System.in);
		double latitude = 0;
		double longitude = 0;
		try {
			System.out.print("\nWhat is the latitude? ");
			String latInput = sc.nextLine();
			latitude = Double.parseDouble(latInput);
			System.out.print("\nWhat is the longitude? ");
			String longInput = sc.nextLine();
			longitude = Double.parseDouble(longInput);
		} catch (Exception e) {
			System.out.println("=== Data not accepted ===");
			System.out.println(e.getMessage());
			return;
		}
		
		ArrayList<Restaurant> restArray = new ArrayList<Restaurant>();
		
		for (RestaurantWrapper restWrap : rests.restWrapper) {
			restArray.add(restWrap.convertToRestaurant());
		}

		HashMap<String, Restaurant> restNames = new HashMap<String, Restaurant>();
		for (Restaurant rest : restArray) {
			restNames.put(rest.getName(), rest);
		}
		
		System.out.println("\nStarting execution of program...");
		
		ArrayList<Order> orders = new ArrayList<Order>();

		for (int i = 0; i < schedule.size(); i++) {
			String line = schedule.get(i);
			String readyTimeString = line.substring(0, line.indexOf(", "));
			int readyTime = Integer.parseInt(readyTimeString);
			line = line.substring(line.indexOf(", ")+2);
			String loc = line.substring(0, line.indexOf(", "));
			line = line.substring(line.indexOf(", "));
			String item = line.substring(2);
			if (restNames.containsKey(loc)) {
				for (int j = 0; j < restNames.get(loc).menu.length; j++) {
					if (restNames.get(loc).menu[j].equals(item)) {
						orders.add(new Order(readyTime, loc, item, restNames.get(loc)));
						continue;
					}
				}
			}
		}
		
		ExecutorService executors = Executors.newCachedThreadPool();
		for (int i = 0; i < orders.size(); i++) {
			orders.get(i).setDriveTime(orders.get(i).rest.getDistance(latitude, longitude));
			executors.execute(orders.get(i));
		}
		executors.shutdown();
		while (!executors.isTerminated()) {
			Thread.yield();
		}
				
		System.out.println("All orders complete!");
		
		return;
	}
}
