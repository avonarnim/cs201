package csci201.edu.usc;

import java.util.ArrayList;
import java.util.concurrent.Semaphore;

public class Restaurant {
		private String name;
		private String address;
		private double latitude;
		private double longitude;
		private int drivers;
		public String[] menu;
		
//		public ArrayList<Order> ordersWaiting;
		public Semaphore sems;
		
		public double deliveryLatitude;
		public double deliveryLongitude;
		
		public Restaurant(String rName, String rAddy, double rLat, double rLong, int rDrive, String[] rMenu) {
			name = rName;
			address = rAddy;
			latitude = rLat;
			longitude = rLong;
			drivers = rDrive;
			menu = rMenu;
			
			sems = new Semaphore(drivers);
		}
		
		public String toString() {
			String basic = name + " " + address + "\n" + latitude + " " + longitude + " " + drivers + "\n";
			for (int i = 0; i < menu.length; i++) {
				basic += menu[i];
			}
			return basic;
		}
		
		public String getName() {
			return name;
		}
		
		public double getDistance(double lat, double lon) {
			double delta = lon - longitude;
			double dist = Math.sin(Math.toRadians(lat)) * Math.sin(Math.toRadians(latitude))
					+ Math.cos(Math.toRadians(lat)) * Math.cos(Math.toRadians(latitude)) * Math.cos(Math.toRadians(delta));
			dist = Math.acos(dist); 
			dist = 3963.0 * dist; 
			return dist;
		}
	}