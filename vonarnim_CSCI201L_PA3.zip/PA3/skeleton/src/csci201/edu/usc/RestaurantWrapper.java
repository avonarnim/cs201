package csci201.edu.usc;

public class RestaurantWrapper {

		public String name;
		public String address;
		public double latitude;
		public double longitude;
		public int drivers;
		public String[] menu;
		
		public double deliveryLatitude;
		public double deliveryLongitude;
		
		public RestaurantWrapper(String rName, String rAddy, double rLat, double rLong, int rDrive, String[] rMenu) {
			name = rName;
			address = rAddy;
			latitude = rLat;
			longitude = rLong;
			drivers = rDrive;
			menu = rMenu;
		}
		
		public Restaurant convertToRestaurant() {
			Restaurant rest = new Restaurant(name, address, latitude, longitude, drivers, menu);
			return rest;			
		}

}