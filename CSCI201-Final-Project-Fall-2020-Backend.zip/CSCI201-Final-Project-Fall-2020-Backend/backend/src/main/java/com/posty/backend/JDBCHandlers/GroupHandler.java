package com.posty.backend.JDBCHandlers;

import com.posty.backend.TemplateClasses.*;

import java.util.*;
import java.security.MessageDigest;
import java.math.BigInteger;
import org.springframework.stereotype.Component;

import java.sql.*;
import java.io.*;

@Component
public class GroupHandler {

	private Connection conn;
	private CallableStatement callst;
	private ResultSet rs;
	private Statement st;
	private String db;
	private String user;
	private String pwd;

	public GroupHandler() {
		DBInfo info = new DBInfo();
		this.db = info.db;
		this.user = info.user;
		this.pwd = info.password;
		try {
			this.conn = DriverManager.getConnection(db, user, pwd);
			this.st = conn.createStatement();
		} catch (SQLException e) {
			System.out.println("Failed to connect to database");
			System.out.println(e.getMessage());
		}
	}

	// SETTERS //
	// creates a new order group
	synchronized public void insertNewOrderGroup(boolean pub, String loc, String name, String description, String oTime, String store, String hostId,  int savedListId) {
		try {
			// gets hostName
			String sql = "SELECT name FROM Users WHERE id = '" + hostId + "'";
			rs = st.executeQuery(sql);
			rs.next();
			String hostName = rs.getString("name");
			// assigns group description and/or group name if not already assigned
			if (description.equals("")) {description = "From " + store + " at " + oTime;}
			if (name.equals("")) {name = hostName + "'s Group";}
			
			// inserts new group
			sql = "INSERT INTO OrderGroups (name, description, hostId, hostName, pickUpLocation, orderTime, store, public) VALUES(" + "'" + name + "'" + ", " + "'" + description + "'" + ", " + "'" + hostId + "'" + ", " + "'" + hostName + "'" + ", " + "'" + loc + "'" + ", " + "'" + oTime + "'" + ", " + "'" + store + "'" + ", " + pub + ")" + ";";
			
			st.executeUpdate(sql, Statement.RETURN_GENERATED_KEYS);
			rs = st.getGeneratedKeys();
			rs.next();
			int groupId = rs.getInt(1);
			
			// generating a unique, pseudorandom code
			int offset = 0;
			String code = generateCode(String.valueOf(groupId), offset);
			
			sql = "SELECT COUNT(*) FROM OrderGroups WHERE code = " + "'" + code + "'";
			rs = st.executeQuery(sql);
			rs.next();
			int occurrences = rs.getInt(1);
			while (occurrences != 0) {
				offset += 1;
				code = generateCode(String.valueOf(groupId), offset);
				sql = "SELECT COUNT(*) FROM OrderGroups WHERE code = " + "'" + code + "'";
				rs = st.executeQuery(sql);
				rs.next();
				occurrences = rs.getInt(1);				
			}
			
			sql = "UPDATE OrderGroups SET code = " + "'" + code + "'" + " WHERE id = " + groupId;
			// inserts host order
			OrderRequestHandler or = new OrderRequestHandler();
			or.insertHostOrder(hostId, groupId, savedListId);

		} catch (SQLException e) {
			System.out.println("insertNewOrderGroup SQLException: " + e.getMessage());
		}
		return;
	}

	// hashes the string version of the groupId
	// uses an offset to select a substring of the returned hash (in the event that a substring is already in use)
	private String generateCode(String seed, int offset) {
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			byte[] messageDigest = md.digest(seed.getBytes());
			BigInteger no = new BigInteger(1, messageDigest);
			String hashtext = no.toString(16);
			while(hashtext.length() < 32) {
				hashtext = "0" + hashtext;
			}
			
			String code = hashtext.substring(offset, offset+10);
			
			return code;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	// sets new group status (not placed, placed, ready for pickup, fully completed)
	// if the order has been placed, it also says that a host has paid for their own order
	// if the order is ready for pickup, it also says that a host has picked up their own order
	synchronized public void updateGroupStatus(int groupId, String newStatus) {
		try {
			String sql = "UPDATE OrderGroups SET groupStatus = '" + newStatus + "' WHERE id = " + groupId;
			st.executeUpdate(sql);
			
			if (newStatus.equals("placed")) {
				sql = "UPDATE Orders SET paidFor = TRUE WHERE Orders.userId = '" + getGroupHostId(groupId) + "'";
				st.executeUpdate(sql);
			}
			
			if (newStatus.equals("ready for pickup")) {
				sql = "UPDATE Orders SET pickUpStatus = TRUE WHERE Orders.userId = " + getGroupHostId(groupId) + "'";
				st.executeUpdate(sql);
			}
			
		} catch (SQLException e) {
			System.out.println("updateGroupStatus SQLException: " + e.getMessage());
		}
		return;
	}
	
	// goes through all group members and checks if they've both paid for and picked up their items
	// if everyone has done so, then the group is designated 'fully completed'
	synchronized public void updateIfAllDone(int groupId) {
		try {
			String sql = "SELECT pickUpStatus, paidFor from Orders\n" 
					+ "WHERE Orders.groupId = " + groupId;

			rs = st.executeQuery(sql);
			boolean done = true;
			while (rs.next() && done == true) {
				if (!rs.getBoolean("pickUpStatus") || !rs.getBoolean("paidFor")) {
					done = false;
				}
			}
			
			if (done) {
				updateGroupStatus(groupId, "fully completed");
			}
		} catch (SQLException e) {
			System.out.println("getGroupHostId SQLException: " + e.getMessage());
		}
	}

	// Getter to get group Id
	synchronized public String getGroupHostId(int id) {
		try {
			String sql = "SELECT hostId from OrderGroups\n" + "WHERE OrderGroups.id = " + id;

			rs = st.executeQuery(sql);
			rs.next();
			return rs.getString("hostId");
		} catch (SQLException e) {
			System.out.println("getGroupHostId SQLException: " + e.getMessage());
		}

		return "";
	}

	synchronized public String getGroupHostName(int id) {
		try {
			String sql = "SELECT hostName from OrderGroups\n" + "WHERE OrderGroups.id = " + id;

			rs = st.executeQuery(sql);
			rs.next();
			return rs.getString("hostName");
		} catch (SQLException e) {
			System.out.println("getGroupHostName SQLException: " + e.getMessage());
		}

		return "";
	}

	synchronized public String getGroupName(int id) {
		try {
			String sql = "SELECT name from OrderGroups\n" + "WHERE OrderGroups.id = " + id;

			rs = st.executeQuery(sql);
			rs.next();
			return rs.getString("name");
		} catch (SQLException e) {
			System.out.println("getGroupName SQLException: " + e.getMessage());
		}

		return "";
	}

	synchronized public String getGroupCode(int id) {
		try {
			String sql = "SELECT code from OrderGroups\n" + "WHERE OrderGroups.id = " + id;

			rs = st.executeQuery(sql);
			rs.next();
			return rs.getString("code");
		} catch (SQLException e) {
			System.out.println("getGroupCode SQLException: " + e.getMessage());
		}

		return "";
	}

	synchronized public String getGroupDescription(int id) {
		try {
			String sql = "SELECT description from OrderGroups\n" + "WHERE OrderGroups.id = " + id;

			rs = st.executeQuery(sql);
			rs.next();
			return rs.getString("description");
		} catch (SQLException e) {
			System.out.println("getGroupDescription SQLException: " + e.getMessage());
		}

		return "";
	}

	synchronized public String getGroupPickupLocation(int id) {
		try {
			String sql = "SELECT pickUpLocation from OrderGroups\n" + "WHERE OrderGroups.id = " + id;

			rs = st.executeQuery(sql);
			rs.next();
			return rs.getString("pickUpLocation");
		} catch (SQLException e) {
			System.out.println("getGroupPickupLocation SQLException: " + e.getMessage());
		}

		return "";
	}

	synchronized public String getGroupPickupTime(int id) {
		try {
			String sql = "SELECT pickUpTime from OrderGroups\n" + "WHERE OrderGroups.id = " + id;

			rs = st.executeQuery(sql);
			rs.next();
			return rs.getString("pickUpTime");
		} catch (SQLException e) {
			System.out.println("getGroupPickupTime SQLException: " + e.getMessage());
		}

		return "";
	}

	synchronized public String getGroupOrderTime(int id) {
		try {
			String sql = "SELECT orderTime from OrderGroups\n" + "WHERE OrderGroups.id = " + id;

			rs = st.executeQuery(sql);
			rs.next();
			return rs.getString("orderTime");
		} catch (SQLException e) {
			System.out.println("getGroupOrderTime SQLException: " + e.getMessage());
		}

		return "";
	}

	synchronized public String getGroupStore(int id) {
		try {
			String sql = "SELECT store from OrderGroups\n" + "WHERE OrderGroups.id = " + id;

			rs = st.executeQuery(sql);
			rs.next();
			return rs.getString("store");
		} catch (SQLException e) {
			System.out.println("getGroupStore SQLException: " + e.getMessage());
		}

		return "";
	}

	synchronized public boolean getGroupIsPublic(int id) {
		try {
			String sql = "SELECT public from OrderGroups\n" + "WHERE OrderGroups.id = " + id;

			rs = st.executeQuery(sql);
			rs.next();
			return rs.getBoolean("public");
		} catch (SQLException e) {
			System.out.println("getGroupIsPublic SQLException: " + e.getMessage());
		}

		return false;
	}

	synchronized public String getGroupStatus(int id) {
		try {
			String sql = "SELECT groupStatus from OrderGroups\n" + "WHERE OrderGroups.id = " + id;

			rs = st.executeQuery(sql);
			rs.next();
			return rs.getString("groupStatus");
		} catch (SQLException e) {
			System.out.println("getGroupStatus SQLException: " + e.getMessage());
		}

		return "";
	}

	synchronized public List<OrderRequest> getApprovedOrders(Integer groupId) {
		// First we want a sql statement to get all the order Ids
		List<Integer> orderIds = new ArrayList<Integer>();
		List<OrderRequest> toReturn = null;
		try {
			String command = "SELECT orderId FROM Orders\n" + "WHERE Orders.groupId = " + groupId + "\n"
					+ "AND Orders.approved = TRUE"; // Get the IDs for all the approved orders in the group
			rs = st.executeQuery(command);
			while (rs.next()) {
				orderIds.add(rs.getInt("orderId"));
			} // Now we want to convert these IDs into actual Order Requests

			OrderRequestHandler orh = new OrderRequestHandler();
			toReturn = orh.getOrderRequestsList(orderIds);
		} catch (Exception e) {
			System.out.println("getApprovedOrders SQLException: " + e.getMessage());
		}

		return toReturn;
	}

	synchronized public List<OrderRequest> getPendingOrders(Integer groupId) {
		// First we want a sql statement to get all the order Ids
		List<Integer> orderIds = new ArrayList<Integer>();
		List<OrderRequest> toReturn = null;
		try {
			String command = "SELECT orderId FROM Orders\n" + "WHERE Orders.groupId = " + groupId + "\n"
					+ "AND Orders.approved = FALSE"; // Get the IDs for all the approved orders in the group
			rs = st.executeQuery(command);
			while (rs.next()) {
				orderIds.add(rs.getInt("orderId"));
			} // Now we want to convert these IDs into actual Order Requests

			OrderRequestHandler orh = new OrderRequestHandler();
			toReturn = orh.getOrderRequestsList(orderIds);
		} catch (Exception e) {
			System.out.println("getPendingOrders SQLException: " + e.getMessage());
		}

		return toReturn;
	}

	synchronized public List<Group> getCurrentJoinedOrderGroups(String userId) {
		List<Integer> groupIds = new ArrayList<Integer>();

		try {
			String sql = "SELECT groupId from MemberAssociations, OrderGroups\n" + "WHERE MemberAssociations.userId = '"
					+ userId + "'\n" + "AND OrderGroups.groupStatus != 'fully completed'";

			rs = st.executeQuery(sql);

			while (rs.next())
				groupIds.add(rs.getInt("groupId"));
		} catch (SQLException e) {
			System.out.println("getCurrentJoinedOrderGroups SQLException: " + e.getMessage());
		}

		return getGroupsList(groupIds);
	}

	// Getter for all Group Ids that are currently active
	synchronized public List<Group> getCurrentHostedOrderGroups(String userId) {
		List<Integer> groupIds = new ArrayList<Integer>();
		try {
			String sql4 = "SELECT groupId FROM HostingAssociations, OrderGroups\n"
					+ "WHERE HostingAssociations.userId = '" + userId + "'\n"
					+ "AND OrderGroups.groupStatus != 'fully completed'";
			rs = st.executeQuery(sql4);
			// Getting all the group Id's and storing them in a list

			while (rs.next()) {
				groupIds.add(rs.getInt("groupId"));
			}

		} catch (Exception e) {
			System.out.println("getCurrentHostedOrders SQLException: " + e.getMessage());
		}
		return getGroupsList(groupIds);
	}

	synchronized public List<Group> getPreviousOrderGroups(String userId) {
		List<Integer> groupIds = new ArrayList<Integer>();
		try {
			String sql = "SELECT groupId FROM HostingAssociations, OrderGroups\n"
					+ "WHERE HostingAssociations.userId = '" + userId + "'\n"
					+ "AND OrderGroups.groupStatus = 'fully completed'\n" + "UNION\n"
					+ "SELECT groupId FROM MemberAssociations, OrderGroups\n" + "WHERE MemberAssociations.userId = '"
					+ userId + "'\n" + "AND OrderGroups.groupStatus = 'fully completed'";
			rs = st.executeQuery(sql);

			while (rs.next())
				groupIds.add(rs.getInt("groupId"));
		} catch (SQLException e) {
			System.out.println("getPreviousOrderGroups SQLException: " + e.getMessage());
		}

		return getGroupsList(groupIds);
	}

	synchronized public List<Group> getPublicGroups() {
		List<Integer> groupIds = new ArrayList<Integer>();
		try {
			String sql = "SELECT id FROM OrderGroups\n" + "WHERE OrderGroups.public\n"
					+ "AND OrderGroups.groupStatus != 'fully completed'";
			rs = st.executeQuery(sql);

			while (rs.next())
				groupIds.add(rs.getInt("id"));
		} catch (SQLException e) {
			System.out.println("getPublicGroups SQLException: " + e.getMessage());
		}

		return getGroupsList(groupIds);
	}

	synchronized public Group getPrivateGroup(String string) {
		Integer groupId = null;
		try {
			String sql = "SELECT id FROM OrderGroups\n" + "WHERE OrderGroups.code = '" + string + "'\n"
					+ "AND OrderGroups.groupStatus != 'fully completed'";
			rs = st.executeQuery(sql);
			rs.next();
			groupId = rs.getInt("id");
		} catch (SQLException e) {
			System.out.println("getPrivateGroup SQLException: " + e.getMessage());
		}
		
		if (groupId == null) {
			return null;
		}

		return getGroup(groupId);
	}

	synchronized public List<Group> getGroupsList(List<Integer> groupIds) {
		List<Group> toReturn = new ArrayList<Group>();
		for (Integer i : groupIds) {
			toReturn.add(getGroup(i));
		}
		return toReturn;
	}

	synchronized public Group getGroup(Integer groupId) {

		if (groupId == null) {
			throw new NullPointerException();
		}

		String groupName = this.getGroupName(groupId);
		Boolean isPublic = this.getGroupIsPublic(groupId);
		String pickUpLocation = this.getGroupPickupLocation(groupId);
		String status = this.getGroupStatus(groupId);
		List<OrderRequest> approvedOrders = this.getApprovedOrders(groupId);
		List<OrderRequest> pendingOrders = this.getPendingOrders(groupId);
		String pickUpTime = this.getGroupPickupTime(groupId);
		String hostId = this.getGroupHostId(groupId);
		String code = this.getGroupCode(groupId);
		String description = this.getGroupDescription(groupId);
		UserHandler uh = new UserHandler();
		String hostName = uh.getUserName(hostId);

		return new Group(groupId, groupName, isPublic, pickUpLocation, pickUpTime, hostId, code, hostName, description,
				status, approvedOrders, pendingOrders);
	}


}
