package com.posty.backend.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.posty.backend.JDBCHandlers.*;
import com.posty.backend.TemplateClasses.*;

@CrossOrigin("http://localhost:3000")
@RestController
public class GroupController {

	@Autowired
	private GroupHandler gh;
	
	@GetMapping("/insert-new-order-group")
	public void insertNewOrderGroup(@RequestParam("public") boolean pub, @RequestParam("location") String loc, @RequestParam("name") String name, @RequestParam("description") String description, @RequestParam("orderTime") String oTime, @RequestParam("store") String store, @RequestParam("hostId") String hostId, @RequestParam("savedList") int savedListId) {
		gh.insertNewOrderGroup(pub, loc, name, description, oTime, store, hostId, savedListId);
	}
	
	@GetMapping("/update-group-status")
	public void updateGroupStatus(@RequestParam("groupId") int groupId, @RequestParam("newStatus") String newStatus) {
		gh.updateGroupStatus(groupId, newStatus);
	}

	@GetMapping("/previous-groups")
	public List<Group> getPreviousGroups(@RequestParam("userId") String userId) {
		return gh.getPreviousOrderGroups(userId);
	}

	@GetMapping("/current-joined-groups")
	public List<Group> getCurrentJoinedGroups(@RequestParam("userId") String userId) {
		return gh.getCurrentJoinedOrderGroups(userId);
	}

	@GetMapping("/current-hosted-groups")
	public List<Group> getCurrentHostedGroups(@RequestParam("userId") String userId) {
		return gh.getCurrentHostedOrderGroups(userId);
	}

	@GetMapping("/group-pending-orders")
	public List<OrderRequest> getPendingOrders(@RequestParam("groupId") Integer groupId) {
		return gh.getPendingOrders(groupId);
	}

	@GetMapping("/group-approved-orders")
	public List<OrderRequest> getApprovedOrders(@RequestParam("groupId") Integer groupId) {
		return gh.getApprovedOrders(groupId);
	}

	@GetMapping("/get-group")
	public Group getGroup(@RequestParam("groupId") Integer groupId) {
		return gh.getGroup(groupId);
	}
	
	@GetMapping("/get-private-group")
	public Group getPrivateGroup(@RequestParam("code") String code) {
		return gh.getPrivateGroup(code);
	}
	
	@GetMapping("/get-public-groups")
	public List<Group> getPublicGroups() {
		return gh.getPublicGroups();
	}
}
