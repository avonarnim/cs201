package com.posty.backend.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.posty.backend.JDBCHandlers.*;
import com.posty.backend.TemplateClasses.*; 

@CrossOrigin("http://localhost:3000")
@RestController
public class InventoryController {

	@Autowired
	private InventoryHandler ih;

	@GetMapping("/inventory")
	public List<Inventory> getInventory() 
	{
		return ih.getInventory();
	}
	
	@PostMapping("/inventory")
	public void setInventory(@RequestParam("name") String name, @RequestParam("name") double price) {
		ih.setInventory(name, price);
	}
}
