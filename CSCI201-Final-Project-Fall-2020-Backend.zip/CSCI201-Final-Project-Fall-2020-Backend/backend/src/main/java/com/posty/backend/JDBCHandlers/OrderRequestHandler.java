package com.posty.backend.JDBCHandlers;

import com.posty.backend.TemplateClasses.*;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class OrderRequestHandler {

	private Connection conn;
	private CallableStatement callst;
	private ResultSet rs;
	private Statement st;
	private String db;
	private String user;
	private String pwd;

	public OrderRequestHandler() {
		DBInfo info = new DBInfo();
		this.db = info.db;
		this.user = info.user;
		this.pwd = info.password;
		try {
			this.conn = DriverManager.getConnection(db, user, pwd);
			this.st = conn.createStatement();
		} catch (SQLException e) {
			System.out.println("Failed to connect to database");
			System.out.println(e.getMessage());
		}
	}

	// SETTERS //
	synchronized public int insertNewMemberOrder(String userId, int maxCost, int groupId, int savedListId) {
		int orderId = -1;

		try {
			// determining how much the user is expected to pay
			double estimatedCost = (new SavedListHandler()).getEstimatedCost(savedListId);
			if (estimatedCost > maxCost) {
				estimatedCost = maxCost;
			}
			
			// creating order request
			// note: approval defaults to false
			String sql = "INSERT INTO Orders (userId, estimatedCost, groupId, savedListId) VALUES ('" + userId + "'," + estimatedCost + "," + groupId + "," + savedListId + ")";

			st.executeUpdate(sql, Statement.RETURN_GENERATED_KEYS);
			rs = st.getGeneratedKeys();
			rs.next();
			orderId = rs.getInt(1);
			
			// creating member association
			sql = "INSERT INTO MemberAssociations VALUES (('" + userId + "'," + groupId + "))";
			st.executeUpdate(sql);
			
		} catch (SQLException e) {
			System.out.println("insertMemberOrderRequest SQLException: " + e.getMessage());
		}
		return orderId;
	}

	// inserts host order into database
	// note: the estimatedCost field for the host's order is 0 because they handle that by themselves
	// note: host orders are pre-approved
	synchronized public int insertHostOrder(String userId, int groupId, int savedListId) {
		int orderId = -1;

		try {
			String sql = "INSERT INTO Orders (userId, estimatedCost, groupId, savedListId, approved) VALUES (" + "'" + userId + "'" + "," + 0 + "," + "'" + groupId + "'" + "," + "'" + savedListId + "'" + ", TRUE)";
			
			st.executeUpdate(sql, Statement.RETURN_GENERATED_KEYS);
			rs = st.getGeneratedKeys();
			rs.next();
			orderId = rs.getInt(1);
			// Needed in order to prevent a column mismatch
			String ignorePrimKey = null;
			sql = "INSERT INTO HostingAssociations VALUES (" + ignorePrimKey + "," + "'" + userId + "'" + "," + groupId + ")";
			st.executeUpdate(sql);

		} catch (SQLException e) {
			System.out.println("insertHostOrder SQLException: " + e.getMessage());
		}
		return orderId;
	}

		
	// should edit user's balance (add to it). can get user from Orders, get host from group
	synchronized public void updatePaidFor(int orderId, boolean paid) {
		try {
			String sql = "UPDATE Orders SET paidFor = " + paid + " WHERE orderId = " + orderId;
			st.executeUpdate(sql);
			
			// getting host id
			sql = "SELECT hostId, actualCost, estimatedCost FROM Orders, OrderGroups " +
					"WHERE Orders.orderId = " + orderId +
					" AND Orders.groupId = OrderGroups.id";
			st.executeQuery(sql);
			rs.next();
			String host = rs.getString("hostId");
			double actualCost = rs.getDouble("actualCost");
			double estimatedCost = rs.getDouble("estimatedCost");
			
			// evening balance
			UserHandler uh = new UserHandler();
			if (actualCost == 0) {
				uh.updateUserBalance(getUserId(orderId), host, estimatedCost);
				uh.updateUserBalance(host, getUserId(orderId), -1*estimatedCost);
			} else {
				uh.updateUserBalance(getUserId(orderId), host, actualCost);
				uh.updateUserBalance(host, getUserId(orderId), -1*actualCost);
			}
						
			(new GroupHandler()).updateIfAllDone(getGroupId(orderId));

		} catch (SQLException e) {
			System.out.println("updatePaidFor SQLException: " + e.getMessage());
		}
		return;
	}
	
	// accepts 'actualCost' if available and update user balances
	// amount is subtracted from balance
	// with updatePaidFor, calls checkIfAllDone()
	synchronized public void updatePickUpStatusAndActualCost(int orderId, boolean ready, double actualCost) {
		try {
			String sql = "UPDATE Orders SET pickUpStatus = " + ready + " WHERE orderId = " + orderId;
			st.executeUpdate(sql);
			
			if (actualCost != 0) {
				sql = "SELECT estimatedCost FROM Orders WHERE Orders.orderId = " + orderId;
				rs = st.executeQuery(sql);
				rs.next();
				double previouslyEstimatedCost = rs.getDouble("estimatedCost");
				
				// setting actual cost
				sql = "UPDATE Orders SET actualCost = " + actualCost + " WHERE orderId = " + orderId;
				st.executeUpdate(sql);
				
				// getting host id
				sql = "SELECT hostId FROM Orders, OrderGroups " +
						"WHERE Orders.orderId = " + orderId +
						" AND Orders.groupId = OrderGroups.id";
				st.executeQuery(sql);
				rs.next();
				String host = rs.getString("hostId");
				
				// replacing old estimated cost with new cost
				UserHandler uh = new UserHandler();
				uh.updateUserBalance(getUserId(orderId), host, previouslyEstimatedCost-actualCost);
				uh.updateUserBalance(host, getUserId(orderId), actualCost-previouslyEstimatedCost);
			}
			
			(new GroupHandler()).updateIfAllDone(getGroupId(orderId));
			
		} catch (SQLException e) {
			System.out.println("updatePickUpStatus SQLException: " + e.getMessage());
		}
		return;
	}
	
	// will make an order request approved or rejected
	// setting user balances preliminarily
	synchronized public void updateApproval(int orderId, boolean approval) {
		try {
			String sql = "UPDATE Orders SET approved = " + approval + " WHERE orderId = " + orderId;
			st.executeUpdate(sql);
			
			// temporarily setting user balances based off of expected cost of the order OR maxCost
			UserHandler uh = new UserHandler();
			// getting host ids
			sql = "SELECT hostId FROM Orders, OrderGroups " +
					"WHERE Orders.orderId = " + orderId +
					" AND Orders.groupId = OrderGroups.id";
			st.executeUpdate(sql);
			rs.next();
			String host = rs.getString("hostId");
			
			if (approval == true) {
				double estimatedCost = (new SavedListHandler()).getEstimatedCost(orderId);
				uh.updateUserBalance(getUserId(orderId), host, -1*estimatedCost);
				uh.updateUserBalance(host, getUserId(orderId), estimatedCost);
			}

		} catch (SQLException e) {
			System.out.println("updatePickUpStatus SQLException: " + e.getMessage());
		}
		return;
	}

	synchronized public List<OrderRequest> getCurrentOrderObjects(String userId) {
		List<Integer> currentOrderIds = new ArrayList<Integer>();
		List<OrderRequest> toReturn = null;
		try {
			String command = "SELECT orderId FROM Orders\n" + "WHERE Orders.userId = '" + userId + "'\n"
					+ "AND Orders.pickUpStatus = FALSE";
			rs = st.executeQuery(command);
			while (rs.next()) {
				currentOrderIds.add(rs.getInt("orderId"));
			}
			toReturn = getOrderRequestsList(currentOrderIds);
		} catch (Exception e) {
			System.out.println("getCurrentOrderObjects SQLException: " + e.getMessage());
		}
		return toReturn;
	}

	synchronized public List<OrderRequest> getOrderRequestsList(List<Integer> orderIds) {
		List<OrderRequest> toReturn = new ArrayList<OrderRequest>();
		for (Integer i : orderIds) {
			toReturn.add(constructOrderRequest(i));
		}
		return toReturn;
	}

	// PRIVATE HELPER FUNCTION TO CONSTRUCT INSTANCES OF THE ORDERREQUEST CLASS
//	Integer currentOrderId, String userId, Integer groupId, Double maxCost, 
//	Boolean paidFor, Boolean approved, Boolean pickUpStatus, List<OrderItem> actualOrder
	private OrderRequest constructOrderRequest(Integer currentOrderId) {

		Integer groupId = this.getGroupId(currentOrderId);
		Double estimatedCost = this.getEstimatedCost(currentOrderId);
		Boolean paidFor = this.getPaidFor(currentOrderId);
		Boolean approved = this.getApprovedStatus(currentOrderId);
		Boolean pickUpStatus = this.getPickUpStatus(currentOrderId);
		List<OrderItem> actualOrder = this.getOrderItems(currentOrderId);
		String userId = this.getUserId(currentOrderId);
		UserHandler uh = new UserHandler();
		String userName = uh.getUserName(userId);

		return new OrderRequest(currentOrderId, userId, userName, groupId, estimatedCost, pickUpStatus, paidFor, approved,
				actualOrder);

	}

	synchronized public Integer getGroupId(Integer orderId) {
		Integer id = 0;
		try {
			String command = "SELECT groupId FROM Orders\n" + "WHERE Orders.orderId = " + orderId + "\n";
			rs = st.executeQuery(command);

			rs.next();
			id = rs.getInt("groupId");
		} catch (Exception e) {
			System.out.println("getGroupId in ORH SQLException: " + e.getMessage());
		}
		return id;
	}

	synchronized public String getUserId(Integer orderId) {
		String id = "";
		try {
			String command = "SELECT userId FROM Orders\n" + "WHERE Orders.orderId = " + orderId + "\n";
			rs = st.executeQuery(command);

			rs.next();
			id = rs.getString("userId");
		} catch (Exception e) {
			System.out.println("getUserId in ORH SQLException: " + e.getMessage());

		}
		return id;
	}

	synchronized public Double getEstimatedCost(Integer orderId) {
		Double maxCost = 0.0;
		try {
			String command = "SELECT estimatedCost FROM Orders\n" + "WHERE Orders.orderId = " + orderId + "\n";
			rs = st.executeQuery(command);

			rs.next();
			maxCost = rs.getDouble("estimatedCost");
		} catch (Exception e) {
			System.out.println("getEstimatedCost SQLException: " + e.getMessage());
		}
		return maxCost;
	}

	synchronized public Boolean getPaidFor(Integer orderId) {
		Boolean paidFor = false;
		try {
			String command = "SELECT paidFor FROM Orders\n" + "WHERE Orders.orderId = " + orderId + "\n";
			rs = st.executeQuery(command);

			rs.next();
			paidFor = rs.getBoolean("paidFor");
		} catch (Exception e) {
			System.out.println("getPaidFor SQLException: " + e.getMessage());

		}
		return paidFor;
	}

	synchronized public Boolean getApprovedStatus(Integer orderId) {
		Boolean approved = false;
		try {
			String command = "SELECT approved FROM Orders\n" + "WHERE Orders.orderId = " + orderId + "\n";
			rs = st.executeQuery(command);

			rs.next();
			approved = rs.getBoolean("approved");
		} catch (Exception e) {
			System.out.println("getApprovedStatus SQLException: " + e.getMessage());

		}
		return approved;
	}

	synchronized public Boolean getPickUpStatus(Integer orderId) {
		Boolean pickUpStatus = false;
		try {
			String command = "SELECT pickUpStatus FROM Orders\n" + "WHERE Orders.orderId = " + orderId + "\n";
			rs = st.executeQuery(command);

			rs.next();
			pickUpStatus = rs.getBoolean("pickUpStatus");
		} catch (Exception e) {
			System.out.println("getPickUpStatus SQLException: " + e.getMessage());

		}
		return pickUpStatus;
	}

	synchronized public List<OrderItem> getOrderItems(Integer orderId) {
		List<OrderItem> orderItems = new ArrayList<OrderItem>();
		try {
			String command = "SELECT name, count FROM OrderItems\n" // Should get us multiple order Items
					+ "WHERE OrderItems.listId = " + orderId + "\n"; // Where the list id is the order id
			rs = st.executeQuery(command);

			while (rs.next()) {
				orderItems.add(new OrderItem(rs.getString("name"), rs.getInt("count")));
			}
		} catch (Exception e) {
			System.out.println("getOrderItems SQLException: " + e.getMessage());

		}
		return orderItems;
	}
	
	synchronized public int getSavedListId(Integer orderId) {
		int savedListId = -1;
		try {
			String command = "SELECT savedListId FROM Orders WHERE orderId = " + orderId;
			rs = st.executeQuery(command);
			rs.next();
			savedListId = rs.getInt("savedListId");
		} catch (Exception e) {
			System.out.println("getSavedListId SQLException " + e.getMessage());
		}
		return savedListId;
	}

}
