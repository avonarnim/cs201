package com.posty.backend.JDBCHandlers;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.posty.backend.TemplateClasses.*;

@Component
public class UserHandler {
	
	private Connection conn;
	private ResultSet rs;
	private Statement st;
	private String db;
	private String user;
	private String pwd;
	
	public UserHandler(){
		DBInfo info = new DBInfo(); 
		this.db = info.db;
		this.user = info.user;
		this.pwd = info.password; 
		try {
			this.conn = DriverManager.getConnection(db, user, pwd);
			this.st = conn.createStatement();
		}	
		catch(SQLException e) {
			System.out.println("Failed to connect to database");
			System.out.println(e.getMessage());
		}
	}
	
	
	synchronized public boolean checkUserExists(String email) 
	{
		String sql = "{? = CALL checkUserExists(?)}";
		try (CallableStatement stmt = conn.prepareCall(sql);) {
			stmt.registerOutParameter(1, Types.BOOLEAN);
			stmt.setString(2, email);
			
			stmt.executeUpdate();
			return stmt.getBoolean(1);
		} catch (SQLException e) {
			System.out.println ("checkUserExists SQLException: " + e.getMessage());
		
		}
		
		return false;
		
	}
	
	synchronized public boolean storeNewUser(String id, String name, String email) {
		String sql = "{? = CALL storeNewUser(?, ?, ?)}";
		
		try (Connection conn = DriverManager.getConnection(db, user, pwd);
				CallableStatement stmt = conn.prepareCall(sql);) {
			
			if(checkUserExists(email)) {
				return false;
			}
			
			stmt.registerOutParameter(1, Types.BOOLEAN);
			stmt.setString(2, id);
			stmt.setString(3, name);
			stmt.setString(4, email);
			
			stmt.executeUpdate();
			return stmt.getBoolean(1);
		} catch (SQLException e) {
			System.out.println ("storeNewUser SQLException: " + e.getMessage());
		}
		
		
		return false;
		
	}
	
	// updates balance between two users
	synchronized public void updateUserBalance(String keyUser, String otherUser, double amount) {
		try {
			String sql = "SELECT balance FROM Balances WHERE person1 = " + keyUser + "\n"
					+ " AND person2 = " + otherUser;
			rs = st.executeQuery(sql);
			rs.next();
			double newBalance = rs.getDouble("balance") + amount;
			
			sql = "UPDATE Balances SET balance = " + amount + " WHERE person1 = " + keyUser + "\n"
					+ " AND person2 = " + otherUser;
			st.executeUpdate(sql);
			

		} catch (SQLException e) {
			System.out.println("updatePickUpStatus SQLException: " + e.getMessage());
		}
		return;
	}
	
	synchronized public String getUserName(String id) {
		try {	
			String sql = "SELECT name from Users\n"
					+ "WHERE Users.id = '" + id + "'";
			
			rs = st.executeQuery(sql);
			
			rs.next();
			return rs.getString("name");
		} catch (SQLException e) {
			System.out.println ("getUserName SQLException: " + e.getMessage());
		}
		
		return "";
	}
	
//	synchronized public void setUserName(String id, String name)
//	{
//		try {	
//			String sql = "UPDATE Users SET name = " + name + "WHERE Users.id = '" + id + "'";
//			
//			rs = st.executeQuery(sql);
//		}
//		catch (SQLException e) {
//			System.out.println ("setUserName SQLException: " + e.getMessage());
//		}
//	}
	
	synchronized public String getUserEmail(String id) {
		try {	
			String sql = "SELECT email from Users\n"
					+ "WHERE Users.id = '" + id + "'";
			
			rs = st.executeQuery(sql);
			
			rs.next();
			return rs.getString("email");
		} catch (SQLException e) {
			System.out.println ("getUserEmail SQLException: " + e.getMessage());
		}
		
		return "";
	}
	
	synchronized public String getUserId(String email) {
		try {
			String sql = "SELECT id from Users\n"
					+ "WHERE Users.email = " + email;
			
			rs = st.executeQuery(sql);
			rs.next();
			return rs.getString("id");
		} catch (SQLException e) {
			System.out.println("getUserId SQLException: " + e.getMessage());
		}
		return "";
	}
	
//	synchronized public void setUserEmail(String id, String email)
//	{
//		try {	
//			String sql = "UPDATE Users SET email = " + email + "WHERE Users.id = '" + id + "'";
//			
//			rs = st.executeQuery(sql);
//		}
//		catch (SQLException e) {
//			System.out.println ("setUserName SQLException: " + e.getMessage());
//		}
//	}
	
	
	
//	// needs to be getting prices of items from inventory table
//	synchronized public void setSavedList(int listId, String name, int count) {
//		List<OrderItem> savedList = new ArrayList<OrderItem>();
//		try 
//		{	
//			String sql = "UPDATE OrderItems SET name = " + name + "," + " count = " + count
//					+ " WHERE OrderItems.listId = " + listId;
//			
//			rs = st.executeQuery(sql);
//
//		} catch (SQLException e) 
//		{
//			System.out.println ("getSavedList SQLException: " + e.getMessage());
//		}
//	}
	
	// needs to be getting prices of items from inventory table
		synchronized public List<OrderItem> getSavedList(int listId) {
			List<OrderItem> savedList = new ArrayList<OrderItem>();
			try {	
				String sql = "SELECT name, count from OrderItems\n"
						+ "WHERE OrderItems.listId = " + listId;
				
				rs = st.executeQuery(sql);
				
				while (rs.next())
					savedList.add(new OrderItem(rs.getString("name"), rs.getInt("count")));
							
			} catch (SQLException e) {
				System.out.println ("getSavedList SQLException: " + e.getMessage());
			}
			return savedList;
		}
	
	synchronized public List<List<OrderItem>> getAllSavedLists(String userId) {
		List<List<OrderItem>> allSavedLists = new ArrayList<List<OrderItem>>();
		List<Integer> listIds = new ArrayList<Integer>();

		try {	
			String sql = "SELECT id from SavedLists\n"
					+ "WHERE SavedLists.userId = '" + userId + "'";
			
			rs = st.executeQuery(sql);
			
			while (rs.next())
				listIds.add(rs.getInt("id"));						
		} catch (SQLException e) {
			System.out.println ("getAllSavedLists SQLException: " + e.getMessage());
		}
		
		for (Integer id : listIds) {
			allSavedLists.add(getSavedList(id));
		}
		
		return allSavedLists;
	}
	
	synchronized public Map<Integer, String> getSavedListsNamesIds(String userId) {
		Map<Integer, String> names = new HashMap<Integer, String>();
		try {	
			String sql = "SELECT id, listName from SavedLists\n"
					+ "WHERE SavedLists.userId = '" + userId + "'";
			
			rs = st.executeQuery(sql);
			
			while (rs.next())
				names.put(rs.getInt("id"), rs.getString("listName"));						
		} catch (SQLException e) {
			System.out.println ("getSavedListsNamesId SQLException: " + e.getMessage());
		}
		
		return names;
	}
	
	synchronized public Map<String, Double> getBalances(String id) {
		Map<String, Double> balances = new HashMap<String, Double>();
		try {	
			String sql = "SELECT person2, balance from Balances\n"
					+ "WHERE Balances.person1 = '" + id + "'";
			
			rs = st.executeQuery(sql);
			
			while (rs.next())
				balances.put(rs.getString("person2"), rs.getDouble("balance"));
						
		} catch (SQLException e) {
			System.out.println ("getBalances SQLException: " + e.getMessage());
		}
		return balances;
	}
	
	synchronized public Map<String, Double> getBalancesSummary(String id) {
		Map<String, Double> balances = getBalances(id);
		Map<String, Double> balancesSummary = new HashMap<String, Double>();
		balancesSummary.put("Owed", 0.0);
		balancesSummary.put("Owe", 0.0);
		balancesSummary.put("Total", 0.0);
		
		for (Double b : balances.values()) {
			if (b > 0.0) {
				Double currOwed = balancesSummary.get("Owed");
				balancesSummary.replace("Owed", currOwed + b);
			} else {
				Double currOwe = balancesSummary.get("Owe");
				balancesSummary.replace("Owe", currOwe + b);
			}
			
			Double currTotal = balancesSummary.get("Total");
			balancesSummary.replace("Total", currTotal + b);
		}
		
		return balancesSummary;
	}
}
