package com.posty.backend.TemplateClasses;

import java.util.*;


public class SavedList
{
    private Integer id; //My own unique Id 
    private String userId; //The user that made me 
    private String listName;
    
    public SavedList(Integer id_, String userId_, String listName_) {
    	this.id = id_; 
    	this.userId = userId_; 
    	this.listName = listName_; 
    }

	@Override
	public String toString() {
		return "SavedList [id=" + id + ", userId=" + userId + ", listName=" + listName + "]";
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getListName() {
		return listName;
	}

	public void setListName(String listName) {
		this.listName = listName;
	}
    
    

}



