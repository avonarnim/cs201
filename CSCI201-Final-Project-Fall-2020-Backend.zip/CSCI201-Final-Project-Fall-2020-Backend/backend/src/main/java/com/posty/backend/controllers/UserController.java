package com.posty.backend.controllers;

import org.springframework.web.bind.annotation.RestController;

import com.posty.backend.JDBCHandlers.UserHandler;
import com.posty.backend.TemplateClasses.OrderItem;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@CrossOrigin("http://localhost:3000")
@RestController
public class UserController {

	// Make API Calls to balances and saved lists

	@Autowired
	private UserHandler uh;

	@GetMapping("/user-name")
	public String getUserName(@RequestParam("userId") String userId) {
		return uh.getUserName(userId);
	}
	
	@GetMapping("/user-id")
	public String getUserId(@RequestParam("email") String email) {
		return uh.getUserId(email);
	}
	
	@PostMapping("/storeNewUser")
	public boolean storeNewUser(@RequestParam("userId") String userId, @RequestParam("name") String name, @RequestParam("email") String email) 
	{
		uh.storeNewUser(userId, name, email);
		return true;
	}
	
	@GetMapping("/user-email")
	public String getUserEmail(@RequestParam("userId") String userId) {
		return uh.getUserEmail(userId);
	}
	@GetMapping("/storeNewUser")
	public boolean setUserEmail(@RequestParam("userId") String userId, @RequestParam("name") String name, @RequestParam("email") String email) 
	{
		uh.storeNewUser(userId, name, email);
		return true;
	}

	@GetMapping("/all-balances")
	public Map<String, Double> getBalances(@RequestParam("userId") String userId) 
	{
		return uh.getBalances(userId);
	}
	@PostMapping("/updateUserBalance")
	public void setBalances(@RequestParam("keyUser") String keyUser, @RequestParam("otherUser") String otherUser, @RequestParam("amount") double amount)
	{
		 uh.updateUserBalance(keyUser, otherUser, amount);
	}

	
	
	@GetMapping("/balances-summary")
	public Map<String, Double> getBalancesSummary(@RequestParam("userId") String userId) 
	{
		return uh.getBalancesSummary(userId);
	}

	@GetMapping("/user-saved-lists-names-ids") // Gets the names and ids of all saved lists
	public Map<Integer, String> getAllSavedListsNamesIds(@RequestParam("userId") String userId) {
		return uh.getSavedListsNamesIds(userId);
	}

	@GetMapping("/user-saved-list") // Gets a specific saved list
	public List<OrderItem> getUserSavedList(@RequestParam("listId") int listId) {
		return uh.getSavedList(listId);
	}

}
