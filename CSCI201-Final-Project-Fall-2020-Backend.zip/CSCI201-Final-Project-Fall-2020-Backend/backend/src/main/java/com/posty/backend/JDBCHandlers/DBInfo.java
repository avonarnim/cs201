package com.posty.backend.JDBCHandlers;

public class DBInfo {
	public String db = "jdbc:mysql://localhost:3306/data"; 
	public String user = "root"; 
	public String password = "root";  //CHANGE THESE WHENEVER YOU ARE RUNNING A DATABASE
}
