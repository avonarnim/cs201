package com.posty.backend.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.posty.backend.JDBCHandlers.*;
import com.posty.backend.TemplateClasses.*; 

@CrossOrigin("http://localhost:3000")
@RestController
public class OrderRequestController {

	@Autowired
	private OrderRequestHandler orh;
	
	@PostMapping("/insert-new-member-order")
	public int insertNewMemberOrder(@RequestParam("userId") String userId, @RequestParam("maxCost") int maxCost, @RequestParam("groupId") int groupId, @RequestParam("savedListId") int savedListId) {
		return orh.insertNewMemberOrder(userId, maxCost, groupId, savedListId);
	}
	
	@PostMapping("/insert-host-order")
	public int insertHostOrder(@RequestParam("userId") String userId, @RequestParam("groupId") int groupId, @RequestParam("savedListId") int savedListId) {
		return orh.insertHostOrder(userId, groupId, savedListId);
	}
	
	@PostMapping("/update-paid-for")
	public void updatePaidFor(@RequestParam("orderId") int orderId, @RequestParam("paid") boolean paid) {
		orh.updatePaidFor(orderId, paid);
	}
	
	@PostMapping("/update-pickup-stats-and-actual-cost")
	public void updatePickUpStatusAndActualCost(@RequestParam("orderId") int orderId, @RequestParam("ready") boolean ready, @RequestParam("actualCost") double actualCost) {
		orh.updatePickUpStatusAndActualCost(orderId, ready, actualCost);
	}
	
	@PostMapping("/update-approval")
	public void updateApproval(@RequestParam("orderId") int orderId, @RequestParam("approval") boolean approval) {
		orh.updateApproval(orderId, approval);
	}

	@GetMapping("/user-current-orders")
	public List<OrderRequest> getCurrentOrders(@RequestParam("userId") String userId) {
		return orh.getCurrentOrderObjects(userId);
	}
	
	@GetMapping("/get-order-request-list")
	public List<OrderRequest> getOrderRequestsList(@RequestParam("orderIds") List<Integer> orderIds) {
		return orh.getOrderRequestsList(orderIds);
	}
	
	@GetMapping("/get-group-id")
	public Integer getGroupId(@RequestParam("orderId") Integer orderId) {
		return orh.getGroupId(orderId);
	}
	
	@GetMapping("/get-user-id")
	public String getUserId(@RequestParam("orderId") Integer orderId) {
		return orh.getUserId(orderId);
	}
	
	@GetMapping("/get-paid-for")
	public Boolean getPaidFor(@RequestParam("orderId") Integer orderId) {
		return orh.getPaidFor(orderId);
	}
	
	@GetMapping("/get-approved-status")
	public Boolean getApprovedStatus(@RequestParam("orderId") Integer orderId) {
		return orh.getApprovedStatus(orderId);
	}
	
	@GetMapping("/get-pickup-status")
	public Boolean getPickUpStatus(@RequestParam("orderId") Integer orderId) {
		return orh.getPickUpStatus(orderId);
	}
	
	@GetMapping("/get-order-items")
	public List<OrderItem> getOrderItems(@RequestParam("orderId") Integer orderId) {
		return orh.getOrderItems(orderId);
	}
	
	@GetMapping("/get-saved-list-id")
	public int getSavedListId(@RequestParam("orderId") Integer orderId) {
		return orh.getSavedListId(orderId);
	}
	
	@GetMapping("/get-estimated-cost")
	public Double getEstimatedCost(@RequestParam("orderId") Integer orderId) {
		return orh.getEstimatedCost(orderId);
	}


}