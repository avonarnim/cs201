package com.posty.backend.JDBCHandlers;

import com.posty.backend.TemplateClasses.*;
import java.util.*;

import org.springframework.stereotype.Component;

import java.sql.*;
import java.io.*;

@Component
public class OrderItemHandler {

	private Connection conn;
	private CallableStatement callst;
	private ResultSet rs;
	private Statement st;
	private String db; 
	private String user; 
	private String pwd; 

	public OrderItemHandler() {
		DBInfo info = new DBInfo();
		this.db = info.db;
		this.user = info.user;
		this.pwd = info.password;
		try {
			this.conn = DriverManager.getConnection(db, user, pwd);
			this.st = conn.createStatement();
		}	
		catch(SQLException e) {
			System.out.println("Failed to connect to database");
			System.out.println(e.getMessage());
		}
	}
	
	// inserts all of the items with corresponding to a saved list
	synchronized public void insertOrderItems(List<OrderItem> items, int savedListId) {
		try {
			
			String sql = "SET FOREIGN_KEY_CHECKS=0\n";
			st.executeUpdate(sql);
			sql = "INSERT INTO OrderItems (listId, name, count) VALUES ";
			for (int i = 0; i < items.size()-1; i++) {
				sql += "(" + savedListId + ", '" + items.get(i).name + "'," + items.get(i).quantity + "),\n";
			}
			sql += "(" + savedListId + ", '" + items.get(items.size()-1).name + "'," + items.get(items.size()-1).quantity + ")";

			st.executeUpdate(sql);

		} catch (SQLException e) {
			System.out.println("insertOrderItems SQLException: " + e.getMessage());
		}
		return;
	}

	// gets saved list ids for a user
	public List<Integer> getSavedListIds(int userId) {
		List<Integer> slids = new ArrayList<Integer>();
		try {
			String sql = "SELECT id FROM SavedLists WHERE userId = " + userId;

			rs = st.executeQuery(sql);
			
			while (rs.next()) {
				slids.add(rs.getInt("id"));
			}
			
			return slids;
		} catch (SQLException e) {
			System.out.println("getSavedListIds SQLException: " + e.getMessage());
		}

		return null;
	}
  
	// Gets items from a specific saved list
	synchronized public List<OrderItem> getOrderItems(int orderId) {
		try {
			String sql = "SELECT name, count FROM OrderItems WHERE listId = " + orderId;

			rs = st.executeQuery(sql);
			List<OrderItem> ois = new ArrayList<OrderItem>();
			
			while (rs.next()) {
				ois.add(new OrderItem(rs.getString("name"), rs.getInt("count")));
			} // Now we want to convert these IDs into actual Order Requests
			
			return ois;
		} catch (SQLException e) {
			System.out.println("getOrderItem SQLException: " + e.getMessage());
		}

		return null;
	}
	

}
