package com.posty.backend;

import java.util.*;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

import com.posty.backend.JDBCHandlers.*;
import com.posty.backend.TemplateClasses.*;

@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class })
public class PostyApplication {
	

	public static void main(String[] args) {
		UserHandler uh = new UserHandler();
		uh.storeNewUser("f", "Fayez", "floan@usc.edu");
		uh.storeNewUser("a", "Ayushi", "ayushimi@usc.edu");
//		System.out.println("fayez email: " + uh.getUserEmail("f"));
//		System.out.println("fayez name: " + uh.getUserName("f"));
//		System.out.println("ayushi email: " + uh.getUserEmail("a"));
//		System.out.println("ayushi name: " + uh.getUserName("a"));
//		System.out.println("jkashfd");
//		
		SavedListHandler slh = new SavedListHandler();
		OrderItem a = new OrderItem("milk", 1);
		List<OrderItem> alist = new ArrayList<OrderItem>();
		alist.add(a);
		slh.insertNewSavedList("a", "ayushi list", alist);
//		System.out.println("all of ayushi's lists: " + uh.getSavedListsNamesIds("a"));
	
		OrderItem b = new OrderItem("garlic", 3);
		alist.add(b);
		slh.insertNewSavedList("f", "fayez list", alist);
//		System.out.println("all of fayez's lists (names/ids): " + uh.getSavedListsNamesIds("f"));
//		System.out.println("all of fayez's lists: " + uh.getAllSavedLists("f"));
//		System.out.println("fayez's list: " + uh.getSavedList(2));
//		
		GroupHandler gh = new GroupHandler();
		OrderRequestHandler orh = new OrderRequestHandler();
//		System.out.println("group 1: " + gh.getGroup(1).toString());
//		System.out.println("approved 1: " + gh.getApprovedOrders(1));
//		System.out.println("pending 1: " + gh.getPendingOrders(1));
//		System.out.println("fayez current joined: " + gh.getCurrentJoinedOrderGroups("f"));
//		System.out.println("ayushi current hosted: " + gh.getCurrentHostedOrderGroups("a"));
//		System.out.println("ayushi current joined: " + gh.getCurrentJoinedOrderGroups("a"));
//		
		// gh.insertNewOrderGroup(true, "USC", "11:00 PM Tuesday", "Target", "a", 20);

//		System.out.println("public groups: " + gh.getPublicGroups());
//		System.out.println("private group 1: " + gh.getPrivateGroup("acode"));
//		System.out.println("ayushi previous: " + gh.getPreviousOrderGroups("a"));
//		System.out.println("fayez previous: " + gh.getPreviousOrderGroups("f"));
//		System.out.println("fayez current joined: " + gh.getCurrentJoinedOrderGroups("f"));
//		System.out.println("ayushi current hosted: " + gh.getCurrentHostedOrderGroups("a"));
//		System.out.println("ayushi current joined: " + gh.getCurrentJoinedOrderGroups("a"));

		SpringApplication.run(PostyApplication.class, args);
	}

}
