package com.posty.backend.TemplateClasses;
import java.io.IOException;
import java.util.*;

import org.springframework.stereotype.Component;

public class Group{
	// Initializing all data members
	
	private String groupName; 
	private Integer groupId; 
	private Boolean isPublic;  //True if group is public, false if group is private
	private String pickUpLocation; //Where everyone can pick up items, can be changed 
	private String status; //Can only be one of the options in the array statusES
	private List<OrderRequest> approvedOrders; 
	private List<OrderRequest> pendingOrders; 
	private String pickUpTime; 
	private String hostName; 
	private String hostId; 
	private String description; 
	private String code;
	
	
	
	/*
	 * Parameters: None
	 * Return: void
	 * Class Constructor
	 */
//	public Group(String groupName_, Boolean isPublic_, String pickUpLocation_, String pickUpTime_, 
//			String host_, String description_, OrderRequest hostOrder_) {
//		this.groupName = groupName_; 
//		this.isPublic = isPublic_; 
//		this.pickUpLocation = pickUpLocation_; 
//		this.pickUpTime = pickUpTime_; 
//		this.host = host_; 
//		this.description = description_; 
//		
//		this.members = new ArrayList<String>(); 
//		this.status = "Accepting Orders"; //By Default every group should be accepting orders
//		this.approvedOrders = new ArrayList<OrderRequest>(); 
//		this.approvedOrders.add(hostOrder_);
//		this.pendingOrders = new ArrayList<OrderRequest>(); 
//		
//	}
//	
	public Group(Integer groupId_, String groupName_, Boolean isPublic_, String pickUpLocation_, String pickUpTime_, 
			String hostId_, String code_, String hostName_, String description_, String status_,
			List<OrderRequest> approvedOrders_, List<OrderRequest> pendingOrders_) {
		
		this.groupId = groupId_; 
		this.groupName = groupName_; 
		this.isPublic = isPublic_; 
		this.pickUpLocation = pickUpLocation_; 
		this.pickUpTime = pickUpTime_; 
		this.hostId = hostId_; 
		this.code = code_; 
		this.description = description_; 
		this.status = status_; 
		this.approvedOrders = approvedOrders_; 
		this.pendingOrders = pendingOrders_;  
		this.hostName = hostName_; 
		
	}


	@Override
	public String toString() {
		return "Group [groupName=" + groupName + ", groupId=" + groupId + ", isPublic=" + isPublic + ", pickUpLocation="
				+ pickUpLocation + ", status=" + status + ", approvedOrders=" + approvedOrders + ", pendingOrders="
				+ pendingOrders + ", pickUpTime=" + pickUpTime + ", hostName=" + hostName + ", hostId=" + hostId
				+ ", description=" + description + ", code=" + code + "]";
	}


	public String getGroupName() {
		return groupName;
	}



	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}



	public Integer getGroupId() {
		return groupId;
	}



	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}



	public Boolean getIsPublic() {
		return isPublic;
	}



	public void setIsPublic(Boolean isPublic) {
		this.isPublic = isPublic;
	}



	public String getPickUpLocation() {
		return pickUpLocation;
	}



	public void setPickUpLocation(String pickUpLocation) {
		this.pickUpLocation = pickUpLocation;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public List<OrderRequest> getApprovedOrders() {
		return approvedOrders;
	}



	public void setApprovedOrders(List<OrderRequest> approvedOrders) {
		this.approvedOrders = approvedOrders;
	}



	public List<OrderRequest> getPendingOrders() {
		return pendingOrders;
	}



	public void setPendingOrders(List<OrderRequest> pendingOrders) {
		this.pendingOrders = pendingOrders;
	}



	public String getPickUpTime() {
		return pickUpTime;
	}



	public void setPickUpTime(String pickUpTime) {
		this.pickUpTime = pickUpTime;
	}



	public String getHostName() {
		return hostName;
	}



	public void setHostName(String hostName) {
		this.hostName = hostName;
	}



	public String getHostId() {
		return hostId;
	}



	public void setHostId(String hostId) {
		this.hostId = hostId;
	}



	public String getDescription() {
		return description;
	}



	public void setDescription(String description) {
		this.description = description;
	}



	public String getCode() {
		return code;
	}



	public void setCode(String code) {
		this.code = code;
	}
	
	
}

