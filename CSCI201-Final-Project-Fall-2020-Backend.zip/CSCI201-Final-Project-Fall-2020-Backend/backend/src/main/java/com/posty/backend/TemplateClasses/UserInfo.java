package com.posty.backend.TemplateClasses;
//package com.posty.backend.TemplateClasses;
//
//import java.util.*;
//
//public class User {
//	
//	private String userName;
//	private String userEmail;
//	private Integer userID;
//	
//	private List<String> allGroups;
//	private List<String> hostingGroups;
//	private List<OrderRequest> pendingRequests;
//	private Map<Integer, Double> transactions; // key: person's userID, value: amount they owe / are owed
//
//	private List<GroceryItem> currentGroceryList; // grocery list currently being edited
//	private String currentGroceryListName;
//	private Map<String, List<GroceryItem>> savedGroceryLists; // key: grocery list name, value: grocery list
//	private List<OrderRequest> orderHistory; // TODO: add methods to update this?
//
//	private Double rating; // implement later
//	private String defaultLocation;
//	private Double balance;
//	
//	/* 
//	 * Parameters: String userName_, String userEmail_, Integer userID_, String defaultLocation_
//	 * Class Constructor
//	 */
//	public User(String userName_, String userEmail_, Integer userID_, String defaultLocation_) {
//		userName = userName_;
//		userEmail = userEmail_;
//		userID = userID_; // TODO: figure out how to generate random unique user IDs; ID shouldn't be parameter
//		
//		allGroups = new ArrayList<String>();
//		hostingGroups = new ArrayList<String>();
//		pendingRequests = new ArrayList<OrderRequest>();
//		transactions = new HashMap<Integer, Double>();
//		
//		currentGroceryList = new ArrayList<GroceryItem>();
//		currentGroceryListName = "";
//		savedGroceryLists = new HashMap<String, List<GroceryItem>>();
//		orderHistory = new ArrayList<OrderRequest>();
//		
//		rating = 0.0;
//		defaultLocation = defaultLocation_;
//		balance = 0.0;
//	}
//	
//	/*
//	 * Parameters: None
//	 * Return: void
//	 * Adds current grocery list to saved grocery lists
//	 */
//	public void AddGroceryList() {
//		savedGroceryLists.put(currentGroceryListName, currentGroceryList);
//	}
//	
//	/*
//	 * Parameters: GroceryItem
//	 * Return: void
//	 * Adds item to current grocery list
//	 */
//	public void AddGroceryItem(GroceryItem toAdd) {
//		currentGroceryList.add(toAdd);
//	}
//	
//	/*
//	 * Parameters: GroceryItem
//	 * Return: void
//	 * Removes item from current grocery list
//	 */
//	public void RemoveGroceryItem(GroceryItem toRemove) {
//		currentGroceryList.remove(toRemove);
//	}
//	
//	/*
//	 * Parameters: String updatedName, List<GroceryItem> updatedList
//	 * Return: void
//	 * Updates what the current grocery list is
//	 */
//	public void UpdateCurrentGroceryList(String updatedName, List<GroceryItem> updatedList) {
//		currentGroceryListName = updatedName;
//		currentGroceryList = updatedList;
//	}
//	
//	/*
//	 * Parameters: String groceryListName, String groupID
//	 * Return: OrderRequest
//	 * Submits order request to group and adds to list of pending requests
//	 */
//	public OrderRequest SubmitOrder(String groceryListName, String groupID) {
//		List<GroceryItem> groceryList = savedGroceryLists.get(groceryListName);
//		OrderRequest submittedOrder = new OrderRequest(groceryList, this); // TODO: is this through constructor or separate method?
//		boolean submitted = Group.SearchForGroup(groupID).AddPendingOrder(submittedOrder); // TODO: no search method yet
//		if (submitted) {
//			pendingRequests.add(submittedOrder);
//			return submittedOrder;
//		} else { // order went over the limit
//			return null;
//		}
//	}
//	
//	/*
//	 * Parameters: String groupName, Boolean isPrivate, String pickUpLocation, String pickUpTime,
//					Double maxPayablePerPerson, String groceryListName
//	 * Return: void
//	 * Creates new group with provided grocery list
//	 */
//	public void CreateGroup(String groupName, Boolean isPrivate, String pickUpLocation, String pickUpTime,
//								Double maxPayablePerPerson, String groceryListName) {
//		List<GroceryItem> groceryList = savedGroceryLists.get(groceryListName);
//		OrderRequest preApprovedOrder = new OrderRequest(groceryList, this);
//		Group newGroup = new Group(groupName, isPrivate, pickUpLocation, pickUpTime, this.userID,
//									maxPayablePerPerson, preApprovedOrder);		
//		// TODO: check fayez's group constructor again and update as necessary
//		hostingGroups.add(newGroup.GetGroupID());
//	}
//	
//	/*
//	 * Parameters: User otherUser (the user that's owed / owes money), Double cost
//	 * Return: void
//	 * Updates transaction history and balance after new group order
//	 */
//	public void UpdateTransaction(User otherUser, Double cost) {
//		balance += cost;
//		Double newAmount = cost;
//		
//		if (transactions.containsKey(otherUser.GetUserID())) {
//			newAmount += transactions.get(otherUser.GetUserID());
//		}
//
//		transactions.put(otherUser.GetUserID(), newAmount);
//	}
//	
//	/*
//	 * Parameters: Boolean approved, OrderRequest pendingOrder, String groupID
//	 * Return: void
//	 * Removes order from pending requests list and, if order approved, adds group
//	 */
//	public void UpdatePendingOrderStatus(Boolean approved, OrderRequest pendingOrder, String groupID) {
//		pendingRequests.remove(pendingOrder);
//		if (approved) {
//			allGroups.add(groupID);
//		}
//	}
//	
//	/**********GETTERS**********/
//
//	public String GetUserName() {
//		return userName;
//	}
//	
//	public Integer GetUserID() {
//		return userID;
//	}
//	
//	public String GetUserEmail() {
//		return userEmail;
//	}
//	
//	public List<String> GetAllGroups() {
//		return allGroups;
//	}
//
//	public List<String> GetHostingGroups() {
//		return hostingGroups;
//	}
//
//	public List<OrderRequest> GetPendingRequests() {
//		return pendingRequests;
//	}
//	
//	public Map<Integer, Double> GetTransactions() {
//		return transactions;
//	}
//
//	public List<GroceryItem> GetCurrentGroceryList() {
//		return currentGroceryList;
//	}
//
//	public String GetCurrentGroceryListName() {
//		return currentGroceryListName;
//	}
//	
//	public Map<String, List<GroceryItem>> GetSavedGroceryLists() {
//		return savedGroceryLists;
//	}
//	
//	public List<OrderRequest> GetOrderHistory() {
//		return orderHistory;
//	}
//
//	public Double GetRating() {
//		return rating;
//	}
//
//	public String GetDefaultLocation() {
//		return defaultLocation;
//	}
//
//	public Double GetBalance() {
//		return balance;
//	}
//
//	/**********END OF GETTERS**********/
//
//
//}

public class UserInfo{
	public String id;
	public String name;
	public String email;
	UserInfo(String id, String name, String email){
		this.id = id;
		this.name = name;
		this.email = email;
	}
}
