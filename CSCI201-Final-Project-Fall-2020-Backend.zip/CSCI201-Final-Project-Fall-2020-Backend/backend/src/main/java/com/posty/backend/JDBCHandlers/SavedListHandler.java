package com.posty.backend.JDBCHandlers;

import com.posty.backend.TemplateClasses.*;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class SavedListHandler {

	private Connection conn;
	private CallableStatement callst;
	private ResultSet rs;
	private Statement st;
	private String db; 
	private String user; 
	private String pwd; 

	public SavedListHandler() {
		DBInfo info = new DBInfo();
		this.db = info.db;
		this.user = info.user;
		this.pwd = info.password;
		try {
			this.conn = DriverManager.getConnection(db, user, pwd);
			this.st = conn.createStatement();
		}	
		catch(SQLException e) {
			System.out.println("Failed to connect to database");
			System.out.println(e.getMessage());
		}
	}
	
	synchronized public int insertNewSavedList(String userId, String listName, List<OrderItem> items) {
		try {
			if (listName == "") {
				listName = items.get(0).name + ", " + items.get(1).name + ", " + items.get(2).name + "...";
			}
			String sql = "INSERT INTO savedLists (listName, userId) VALUES ('" + listName + "' , '" + userId + "')";
			st.executeUpdate(sql, Statement.RETURN_GENERATED_KEYS);
			rs = st.getGeneratedKeys();
			rs.next();
			int orderId = rs.getInt(1);
			
			(new OrderItemHandler()).insertOrderItems(items, orderId);
			
			return orderId;

		} catch (SQLException e) {
			System.out.println("insertNewSavedList SQLException: " + e.getMessage());
		}
		return 0;
	}
	
	// Already implemented and tested in UserHandler - no need for it here
	synchronized public List<OrderItem> getSavedListItems(Integer orderId) {
		List<OrderItem> orderItems = new ArrayList<OrderItem>();
		try {
			String command = "SELECT name, count FROM OrderItems\n" // Should get us multiple order Items
					+ "WHERE OrderItems.listId = " + orderId + "\n"; // That have the same order Ids
			rs = st.executeQuery(command);

			while (rs.next()) {
				orderItems.add(new OrderItem(rs.getString("name"), rs.getInt("count")));
			}
		} catch (Exception e) {
			System.out.println("getSavedListItems SQLException: " + e.getMessage());
		}
		return orderItems;
	}
	
	// gets estimated cost of a list
	synchronized public double getEstimatedCost (Integer orderId) {
		double estimatedCost = 0;
		
		try {
			String sql = "SELECT OrderItems.count, Inventory.price FROM OrderItems, Inventory\n" // Should get us multiple order Items
					+ "WHERE OrderItems.listId = " + orderId + "\n"
					+ "AND OrderItems.name = Inventory.name"; // That have the same order Ids
			rs = st.executeQuery(sql);
			while (rs.next()) {
				estimatedCost += rs.getInt("count") * rs.getDouble("price");
			}

		} catch (Exception e) {
			System.out.println("getEstimatedCost SQLException: " + e.getMessage());
		}
		
		return estimatedCost;
	}

}
