package com.posty.backend.JDBCHandlers;

import com.posty.backend.TemplateClasses.*;
import java.util.*;

import org.springframework.stereotype.Component;

import java.sql.*;
import java.io.*;

@Component
public class InventoryHandler {

	private Connection conn;
	private CallableStatement callst;
	private ResultSet rs;
	private Statement st;
	private String db; 
	private String user; 
	private String pwd; 

	public InventoryHandler() {
		DBInfo info = new DBInfo();
		this.db = info.db;
		this.user = info.user;
		this.pwd = info.password;
		try {
			this.conn = DriverManager.getConnection(db, user, pwd);
			this.st = conn.createStatement();
		}	
		catch(SQLException e) {
			System.out.println("Failed to connect to database");
			System.out.println(e.getMessage());
		}
	}
	
	synchronized public List<Inventory> getInventory() {
		List<Inventory> inventory = new ArrayList<Inventory>();
		try {
			String command = "SELECT * FROM Inventory\n";
			rs = st.executeQuery(command);

			while (rs.next()) {
				inventory.add(new Inventory(rs.getString("name"), rs.getDouble("price")));
			}
		} catch (Exception e) {
			System.out.println("getInventory SQLException: " + e.getMessage());
		}
		
		return inventory;
	}
	
	// Is set supposed to update the inventory or add a new item to it?
	synchronized public void setInventory(String name, double price)
	{
		try 
		{
			String command = "INSERT INTO Inventory (name, price) VALUES(('"+ name + "," + price + "'))";
			rs = st.executeQuery(command);
		} catch (Exception e) {
			System.out.println("setInventory SQLException: " + e.getMessage());
		}
	}
	
}
