package com.posty.backend.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.posty.backend.JDBCHandlers.*;
import com.posty.backend.TemplateClasses.*;

@RestController
public class OrderItemController {

	@Autowired
	private OrderItemHandler oih;

//	@GetMapping("/get-order-items")
//	public List<OrderItem> getOrderItems(@RequestParam("orderId") int orderId) {
//		return oih.getOrderItems(orderId);
//	}
	
	@PostMapping("/insert-order-items")
	public void insertOrderItems(@RequestParam("items") List<OrderItem> items, @RequestParam("savedListId") int savedListId) {
		oih.insertOrderItems(items, savedListId);
	}
	
	@GetMapping("/get-savedList-ids")
	public List<Integer> getSavedListIds(@RequestParam("userId") int userId) {
		return oih.getSavedListIds(userId);
	}
	
}
