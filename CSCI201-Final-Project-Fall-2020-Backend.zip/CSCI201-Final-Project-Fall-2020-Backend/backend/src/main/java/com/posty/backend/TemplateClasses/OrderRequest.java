package com.posty.backend.TemplateClasses;

import java.util.*;


public class OrderRequest
{
    private Integer id; //My own unique Id 
    private String userId; //The user that made me 
    private Integer groupId; //What group I am submitted to 
    private Double estimatedCost; //Max my user will pay for me or estimated cost if lower
    private Boolean pickUpStatus; //Have I been picked up or not 
    private Boolean paidFor; //Has the group host been paid for me 
    private Boolean approved; //Am I approved in the group
    private List<OrderItem> orders; //Actual orders
    private String userName; 
    
    public OrderRequest(Integer id_, String userId_, String userName_, Integer groupId_, Double estimatedCost_, Boolean pickUpStatus_,
    		Boolean paidFor_, Boolean approved_, List<OrderItem> orders_) {
    	this.id = id_; 
    	this.userId = userId_; 
    	this.groupId = groupId_; 
    	this.estimatedCost = estimatedCost_; 
    	this.pickUpStatus = pickUpStatus_; 
    	this.paidFor = paidFor_; 
    	this.approved = approved_; 
    	this.orders = orders_;
    	this.userName = userName_; 
    }

	@Override
	public String toString() {
		return "OrderRequest [id=" + id + ", userId=" + userId + ", groupId=" + groupId + ", estimatedCost=" + estimatedCost
				+ ", pickUpStatus=" + pickUpStatus + ", paidFor=" + paidFor + ", approved=" + approved + ", orders="
				+ orders + ", userName=" + userName + "]";
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

	public Double getEstimatedCost() {
		return estimatedCost;
	}

	public void setEstimatedCost(Double estimatedCost) {
		this.estimatedCost = estimatedCost;
	}

	public Boolean getPickUpStatus() {
		return pickUpStatus;
	}

	public void setPickUpStatus(Boolean pickUpStatus) {
		this.pickUpStatus = pickUpStatus;
	}

	public Boolean getPaidFor() {
		return paidFor;
	}

	public void setPaidFor(Boolean paidFor) {
		this.paidFor = paidFor;
	}

	public Boolean getApproved() {
		return approved;
	}

	public void setApproved(Boolean approved) {
		this.approved = approved;
	}

	public List<OrderItem> getOrders() {
		return orders;
	}

	public void setOrders(List<OrderItem> orders) {
		this.orders = orders;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	
    
}