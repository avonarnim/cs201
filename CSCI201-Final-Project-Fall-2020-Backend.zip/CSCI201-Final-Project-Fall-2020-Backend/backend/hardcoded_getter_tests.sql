INSERT INTO data.ordergroups VALUES 
	(1, "agroup", "adescription", "a", "ayushi",
    "acode", "usc", "11:00pm", "target", TRUE, "not placed");
INSERT INTO data.orders VALUES
	(1, "a", 1, 1, 18, 20, FALSE, FALSE, TRUE);
INSERT INTO data.orders VALUES
	(2, "f", 1, 2, 12, 10, FALSE, FALSE, FALSE);
INSERT INTO data.hostingassociations (userId, groupId) VALUES
	("a", 1);
INSERT INTO data.memberassociations (userId, groupId) VALUES
	("f", 1);
    
-- UPDATE data.ordergroups SET groupstatus = 'fully completed' WHERE id = 1;

INSERT INTO data.balances VALUES
	("a", 10, "f"),
    ("f", -10, "a");