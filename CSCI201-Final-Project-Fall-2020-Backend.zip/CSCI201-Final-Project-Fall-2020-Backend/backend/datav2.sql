DROP DATABASE IF EXISTS data;
CREATE DATABASE data;
USE data;

CREATE TABLE Users (
	id VARCHAR(50) PRIMARY KEY,
	name VARCHAR(50) NOT NULL,
	email VARCHAR(320) NOT NULL
);

CREATE TABLE Inventory (
	name VARCHAR(50) PRIMARY KEY,
	price DOUBLE NOT NULL
);

CREATE TABLE SavedLists (
	id INT PRIMARY KEY AUTO_INCREMENT,
    listName VARCHAR(50) NOT NULL,
	userId VARCHAR(50) NOT NULL,
    FOREIGN KEY (userId) REFERENCES Users(id)
);

CREATE TABLE OrderItems (
	id INT PRIMARY KEY AUTO_INCREMENT,
    listId INT NOT NULL,
	name VARCHAR(50) NOT NULL,
	count INT NOT NULL,
    FOREIGN KEY (name) REFERENCES Inventory(name),
    FOREIGN KEY (listId) REFERENCES SavedLists(id)
);

CREATE TABLE OrderGroups (
	id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50),
    description VARCHAR(160),
    hostId VARCHAR(50) NOT NULL,
    hostName VARCHAR(50) NOT NULL,
	code VARCHAR(10) NOT NULL DEFAULT 0,
	pickUpLocation VARCHAR(50) NOT NULL,
	orderTime VARCHAR(50) NOT NULL,
--     pickUpTime VARCHAR(50),
	store VARCHAR(50) NOT NULL,
	public BOOLEAN NOT NULL,
    groupStatus ENUM ('not placed', 'placed', 'ready for pickup', 'fully completed') DEFAULT 'not placed',
    FOREIGN KEY (hostId) REFERENCES Users(id)
);

CREATE TABLE MemberAssociations (
	id INT PRIMARY KEY AUTO_INCREMENT,
	userId VARCHAR(50) NOT NULL,
	groupId INT NOT NULL,
	FOREIGN KEY (userId) REFERENCES Users(id),
    FOREIGN KEY (groupId) REFERENCES OrderGroups(id)
);

CREATE TABLE HostingAssociations (
	id INT PRIMARY KEY AUTO_INCREMENT,
	userId VARCHAR(50) NOT NULL,
	groupId INT NOT NULL,
	FOREIGN KEY (userId) REFERENCES Users(id),
    FOREIGN KEY (groupId) REFERENCES OrderGroups(id)
);

CREATE TABLE Orders (
	orderId INT PRIMARY KEY AUTO_INCREMENT,
	userId VARCHAR(50) NOT NULL,
	groupId INT NOT NULL,
	savedListId INT NOT NULL,
	actualCost DOUBLE DEFAULT 0,
	estimatedCost DOUBLE NOT NULL,
	pickUpStatus BOOLEAN NOT NULL DEFAULT FALSE,
	paidFor BOOLEAN NOT NULL DEFAULT FALSE,
	approved BOOLEAN NOT NULL DEFAULT FALSE,
    FOREIGN KEY (userId) REFERENCES Users(id),
	FOREIGN KEY (groupId) REFERENCES OrderGroups(id),
	FOREIGN KEY (savedListId) REFERENCES SavedLists(id)
);

/*
This will have two entries for every pair of users i,j
Assuming i owes j money, entries (i, -k, j) and (j, +k, i) will be inserted, where k is a positive value
*/
CREATE TABLE Balances (
	person1 VARCHAR(50) PRIMARY KEY,
    balance DOUBLE NOT NULL,
    person2 VARCHAR(50) NOT NULL,
    FOREIGN KEY (person1) REFERENCES Users(id),
    FOREIGN KEY (person2) REFERENCES Users(id)
);

INSERT INTO Inventory VALUES 
	('Liver Sausage', 2.00),
    ('Plantain', 1.00),
    ('Lemon', 1.00),
    ('Pastrami', 5.00),
    ('Yogurt', 4.00),
    ('Garem Masala', 3.00),
    ('Sauerkraut', 1.00),
    ('Couscous', 1.00),
    ('Chicken Liver', 5.00),
    ('Peach', 1.00),
    ('Banana', 0.79),
    ('Garlic', 1.50),
    ('Grits', 2.50),
    ('Cucumber', 1.00),
    ('Bacon', 6.00),
    ('Pomegranate', 3.00),
    ('Chicken Stock', 1.50),
    ('Apple', 1.00),
    ('Milk', 3.00),
    ('Onion', 1.00),
    ('Toast', 2.60),
    ('Pork Chops', 3.50),
    ('Kombucha', 2.80),
    ('Red Cherries', 3.00),
    ('Bratwurst', 4.00),
    ('Sweet Potato', 1.00),
    ('Tomato Sauce', 2.00);

    
# creates a group and assigns the group's id to groupId (parameter)
drop procedure if exists createNewOrderGroup;
DELIMITER $$
CREATE PROCEDURE createNewOrderGroup(IN pub BOOLEAN, IN location VARCHAR(50), IN otime VARCHAR(10), IN storeChoice VARCHAR(50), IN hid INT, OUT groupId INT)
BEGIN
	INSERT INTO OrderGroups (hostId, public, pickUpLocation, orderTime, store) VALUES (
		(hid, pub, location, otime, storeChoice)
    );
    SET groupId = LAST_INSERT_ID();
END $$
DELIMITER ;

# inserts order under a specified groupId (given by createNewOrderGroup)
# assigns the order's id to oid (parameter)
drop procedure if exists insertMemberOrder;
DELIMITER $$ 
CREATE PROCEDURE insertMemberOrder(IN uid INT, IN cost INT, IN gid INT, OUT oid INT)
BEGIN
	INSERT INTO Orders(userId, maxCost, groupId) VALUES (
		(uid, cost, gid)
    );
    SET oid = LAST_INSERT_ID();
    INSERT INTO MemberAssociations (userId, groupId) VALUES (
		(uid, gid)
    );
END $$
DELIMITER ;

# inserts order under a specified groupId (given by createNewOrderGroup)
# assigns the order's id to oid (parameter)
drop procedure if exists insertHostOrder;
DELIMITER $$ 
CREATE PROCEDURE insertHostOrder(IN uid INT, IN cost INT, IN gid INT, OUT oid INT)
BEGIN
	INSERT INTO Orders(userId, maxCost, groupId, approved) VALUES (
		(uid, cost, gid, TRUE)
    );
    SET oid = LAST_INSERT_ID();
    INSERT INTO HostingAssociations (userId, groupId) VALUES (
		(uid, gid)
    );
END $$
DELIMITER ;

# inserts an individual order item under a specified orderId (given by insertOrder)
drop procedure if exists insertItem;
DELIMITER $$
CREATE PROCEDURE insertItem(IN itemName varchar(50), IN quantity INT, IN oid INT)
BEGIN
	INSERT INTO OrderItems (name, count, id) VALUES (
		(itemName, quantity, oid)
    );
END $$
DELIMITER ;

# checks to see if there are any occurances of a submitted email
drop function if exists checkUserExists;
DELIMITER $$
CREATE FUNCTION checkUserExists(checkEmail varchar(50))
RETURNS BOOLEAN DETERMINISTIC
BEGIN
	DECLARE count INT;
    SELECT COUNT(*) INTO count FROM Users u
		WHERE u.email=checkEmail;
    RETURN count >= 1;
END $$
DELIMITER ;

# adds a user with specified inputs
# id, name, and email attributes are taken from google
drop function if exists storeNewUser;
DELIMITER $$
CREATE FUNCTION storeNewUser(id varchar(50), userName varchar(50), userEmail varchar(320))
RETURNS BOOLEAN DETERMINISTIC
BEGIN
    IF checkUserExists(userEmail) = False
		THEN INSERT INTO Users
			VALUES (id, userName, userEmail);
		RETURN TRUE;
	ELSE
		RETURN FALSE;
	END IF;
END $$
DELIMITER ;
