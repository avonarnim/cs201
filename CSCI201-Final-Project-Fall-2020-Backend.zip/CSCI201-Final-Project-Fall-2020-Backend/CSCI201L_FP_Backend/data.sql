DROP DATABASE IF EXISTS data;
CREATE DATABASE data;
USE data;

CREATE TABLE Users (
	id VARCHAR(50) PRIMARY KEY,
	name VARCHAR(50) NOT NULL,
	email VARCHAR(320) NOT NULL
);

CREATE TABLE OrderGroups (
	id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50),
    description VARCHAR(160),
    hostId VARCHAR(50) NOT NULL,
    hostName VARCHAR(50) NOT NULL,
	code VARCHAR(50) NOT NULL,
	pickUpLocation VARCHAR(50) NOT NULL,
	orderTime VARCHAR(50) NOT NULL,
    pickUpTime VARCHAR(50),
	store VARCHAR(50) NOT NULL,
	public BOOLEAN NOT NULL,
    current BOOLEAN NOT NULL DEFAULT TRUE,
    groupStatus ENUM ('not placed', 'placed', 'ready for pickup', 'fully completed') DEFAULT 'not placed',
    FOREIGN KEY (hostId) REFERENCES Users(id)
);

CREATE TABLE MemberAssociations (
	id INT PRIMARY KEY AUTO_INCREMENT,
	userId VARCHAR(50) NOT NULL,
	groupId INT NOT NULL,
	FOREIGN KEY (userId) REFERENCES Users(id),
    FOREIGN KEY (groupId) REFERENCES OrderGroups(id)
);

CREATE TABLE HostingAssociations (
	id INT PRIMARY KEY AUTO_INCREMENT,
	userId VARCHAR(50) NOT NULL,
	groupId INT NOT NULL,
	FOREIGN KEY (userId) REFERENCES Users(id),
    FOREIGN KEY (groupId) REFERENCES OrderGroups(id)
);

CREATE TABLE OrderItems (
	id INT PRIMARY KEY AUTO_INCREMENT,
    listId INT NOT NULL,
	name VARCHAR(50) NOT NULL,
	count INT NOT NULL,
    FOREIGN KEY (listId) REFERENCES Orders(orderId),
    FOREIGN KEY (listId) REFERENCES savedLists(id),
    FOREIGN KEY (name) REFERENCES Inventory(name)
);

CREATE TABLE Orders (
	orderId INT PRIMARY KEY AUTO_INCREMENT,
	userId VARCHAR(50) NOT NULL,
	groupId INT NOT NULL,
	maxCost DOUBLE NOT NULL,
    actualCost DOUBLE,
	pickUpStatus BOOLEAN NOT NULL DEFAULT FALSE,
	paidFor BOOLEAN NOT NULL DEFAULT FALSE,
	approved BOOLEAN NOT NULL DEFAULT FALSE,
    FOREIGN KEY (orderId) REFERENCES OrderItems(listId),
    FOREIGN KEY (userId) REFERENCES Users(id),
	FOREIGN KEY (groupId) REFERENCES OrderGroups(id)
);

CREATE TABLE SavedLists (
	id INT PRIMARY KEY AUTO_INCREMENT,
    listName VARCHAR(50) NOT NULL,
	userId VARCHAR(50) NOT NULL,
    FOREIGN KEY (id) REFERENCES OrderItems(listId),
    FOREIGN KEY (userId) REFERENCES Users(id)
);

/*
This will have two entries for every pair of users i,j
Assuming i owes j money, entries (i, -k, j) and (j, +k, i) will be inserted, where k is a positive value
*/
CREATE TABLE Balances (
	person1 VARCHAR(50) PRIMARY KEY,
    balance DOUBLE NOT NULL,
    person2 VARCHAR(50) NOT NULL,
    FOREIGN KEY (person1) REFERENCES Users(id),
    FOREIGN KEY (person2) REFERENCES Users(id)
);

CREATE TABLE Inventory (
	name VARCHAR(50) PRIMARY KEY,
	price DOUBLE NOT NULL
);

INSERT INTO Inventory (name, price) VALUES (
	('Liver Sausage', 2),
    ('Plantain', 1),
    ('Lemon', 1),
    ('Pastrami', 5),
    ('Yogurt', 4),
    ('Garem Masala', 3),
    ('Sauerkraut', 1),
    ('Couscous', 1),
    ('Chicken Liver', 5),
    ('Peach', 1),
    ('Banana', .79),
    ('Garlic', 1.50),
    ('Grits', 2.50),
    ('Cucumber', 1),
    ('Bacon', 6),
    ('Pomegranate', 3),
    ('Chicken Stock', 1.50),
    ('Apple', 1),
    ('Milk', 3),
    ('Onion', 1),
    ('Toast', 2.60),
    ('Pork Chops', 3.50),
    ('Kombucha', 2.80),
    ('Red Cherries', 3),
    ('Bratwurst', 4),
    ('Sweet Potato', 1),
    ('Tomato Sauce', 2)
);
    
# creates a group and assigns the group's id to groupId (parameter)
drop procedure if exists createNewOrderGroup;
DELIMITER $$
CREATE PROCEDURE createNewOrderGroup(IN pub BOOLEAN, IN location VARCHAR(50), IN otime VARCHAR(10), IN storeChoice VARCHAR(50), IN hid INT, OUT groupId INT)
BEGIN
	INSERT INTO OrderGroups (hostId, public, pickUpLocation, orderTime, store) VALUES (
		(hid, pub, location, otime, storeChoice)
    );
    SET groupId = LAST_INSERT_ID();
END $$
DELIMITER ;

# inserts order under a specified groupId (given by createNewOrderGroup)
# assigns the order's id to oid (parameter)
drop procedure if exists insertMemberOrder;
DELIMITER $$ 
CREATE PROCEDURE insertMemberOrder(IN uid INT, IN cost INT, IN gid INT, OUT oid INT)
BEGIN
	INSERT INTO Orders(userId, maxCost, groupId) VALUES (
		(uid, cost, gid)
    );
    SET oid = LAST_INSERT_ID();
    INSERT INTO MemberAssociations (userId, groupId) VALUES (
		(uid, gid)
    );
END $$
DELIMITER ;

# inserts order under a specified groupId (given by createNewOrderGroup)
# assigns the order's id to oid (parameter)
drop procedure if exists insertHostOrder;
DELIMITER $$ 
CREATE PROCEDURE insertHostOrder(IN uid INT, IN cost INT, IN gid INT, OUT oid INT)
BEGIN
	INSERT INTO Orders(userId, maxCost, groupId, approved) VALUES (
		(uid, cost, gid, TRUE)
    );
    SET oid = LAST_INSERT_ID();
    INSERT INTO HostingAssociations (userId, groupId) VALUES (
		(uid, gid)
    );
END $$
DELIMITER ;

# inserts an individual order item under a specified orderId (given by insertOrder)
drop procedure if exists insertItem;
DELIMITER $$
CREATE PROCEDURE insertItem(IN itemName varchar(50), IN quantity INT, IN oid INT)
BEGIN
	INSERT INTO OrderItems (name, count, id) VALUES (
		(itemName, quantity, oid)
    );
END $$
DELIMITER ;

# checks to see if there are any occurances of a submitted email
drop function if exists checkUserExists;
DELIMITER $$
CREATE FUNCTION checkUserExists(checkEmail varchar(50))
RETURNS BOOLEAN DETERMINISTIC
BEGIN
	DECLARE count INT;
    SELECT COUNT(*) INTO count FROM Users u
		WHERE u.email=checkEmail;
    RETURN count >= 1;
END $$
DELIMITER ;

# adds a user with specified inputs
# id, name, and email attributes are taken from google
drop function if exists storeNewUser;
DELIMITER $$
CREATE FUNCTION storeNewUser(userId INT, userName varchar(50), userEmail varchar(320))
RETURNS BOOLEAN DETERMINISTIC
BEGIN
	SET alreadyPresent = checkUserExists(userEmail);
    IF checkUserExists(userEmail) = True
		THEN INSERT INTO Users (id, name, email)
			VALUES ( (userId, userName, userEmail));
		RETURN TRUE;
	ELSE
		RETURN FALSE;
	END IF;
END $$
DELIMITER ;

# returns all current group ids that a user is in
drop function if exists getCurrentJoinedOrderGroups;
DELIMITER $$
CREATE FUNCTION getCurrentJoinedOrderGroups(userId INT)
RETURNS VARCHAR(1000) DETERMINISTIC
BEGIN
	SET groupIds = (SELECT groupId FROM MemberAssociations, OrderGroups
		WHERE MemberAssociations.userId = userId
        AND OrderGroups.id = groupId
        AND OrderGroups.groupStatus != 'fully completed');
	RETURN groupIds;
END $$
DELIMITER ;

# returns all current group ids that a user is hosting
drop function if exists getCurrentHostedOrderGroups;
DELIMITER $$
CREATE FUNCTION getCurrentHostedOrderGroups(userId INT)
RETURNS VARCHAR(1000) DETERMINISTIC
BEGIN
	SET groupIds = (SELECT groupId FROM HostingAssociations, OrderGroups
		WHERE HostingAssociations.userId = userId
        AND OrderGroups.id = groupId
        AND OrderGroups.groupStatus != 'fully completed');
	RETURN groupIds;
END $$
DELIMITER ;

# returns all previous group ids that a user was in
drop function if exists getPreviousOrderGroups;
DELIMITER $$
CREATE FUNCTION getPreviousOrderGroups(userId INT)
RETURNS VARCHAR(1000) DETERMINISTIC
BEGIN
	SET groupIds = (SELECT groupId FROM HostingAssociations, OrderGroups
		WHERE HostingAssociations.userId = userId
        AND OrderGroups.id = groupId
        AND OrderGroups.groupStatus = 'fully completed'
		UNION
        SELECT groupId FROM MemberAssociations, OrderGroups
		WHERE MemberAssociations.userId = userId
        AND OrderGroups.id = groupId
        AND OrderGroups.groupStatus = 'fully completed');
	RETURN groupIds;
END $$
DELIMITER ;

# returns if someone is the host of a group...
drop function if exists getOrderGroups;
DELIMITER $$
CREATE FUNCTION getOrderGroups(userId INT, gid INT)
RETURNS BOOLEAN DETERMINISTIC
BEGIN
	SET isHost = (SELECT hostId FROM OrderGroups
		WHERE OrderGroups.groupId = gid);
	IF isHost = userId
		THEN RETURN TRUE;
	ELSE
		RETURN FALSE;
	END IF;
END $$
DELIMITER ;
